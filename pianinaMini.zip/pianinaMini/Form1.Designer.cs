﻿namespace pianinaMini
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tasta25 = new pianinaMini.tasta();
            this.tasta26 = new pianinaMini.tasta();
            this.tasta27 = new pianinaMini.tasta();
            this.tasta28 = new pianinaMini.tasta();
            this.tasta29 = new pianinaMini.tasta();
            this.tasta30 = new pianinaMini.tasta();
            this.tasta31 = new pianinaMini.tasta();
            this.tasta32 = new pianinaMini.tasta();
            this.tasta33 = new pianinaMini.tasta();
            this.tasta34 = new pianinaMini.tasta();
            this.tasta35 = new pianinaMini.tasta();
            this.tasta36 = new pianinaMini.tasta();
            this.tasta37 = new pianinaMini.tasta();
            this.tasta38 = new pianinaMini.tasta();
            this.tasta39 = new pianinaMini.tasta();
            this.tasta40 = new pianinaMini.tasta();
            this.tasta41 = new pianinaMini.tasta();
            this.tasta42 = new pianinaMini.tasta();
            this.tasta43 = new pianinaMini.tasta();
            this.tasta44 = new pianinaMini.tasta();
            this.tasta45 = new pianinaMini.tasta();
            this.tasta46 = new pianinaMini.tasta();
            this.tasta47 = new pianinaMini.tasta();
            this.tasta48 = new pianinaMini.tasta();
            this.tasta13 = new pianinaMini.tasta();
            this.tasta14 = new pianinaMini.tasta();
            this.tasta15 = new pianinaMini.tasta();
            this.tasta16 = new pianinaMini.tasta();
            this.tasta17 = new pianinaMini.tasta();
            this.tasta18 = new pianinaMini.tasta();
            this.tasta19 = new pianinaMini.tasta();
            this.tasta20 = new pianinaMini.tasta();
            this.tasta21 = new pianinaMini.tasta();
            this.tasta22 = new pianinaMini.tasta();
            this.tasta23 = new pianinaMini.tasta();
            this.tasta24 = new pianinaMini.tasta();
            this.tasta7 = new pianinaMini.tasta();
            this.tasta8 = new pianinaMini.tasta();
            this.tasta9 = new pianinaMini.tasta();
            this.tasta10 = new pianinaMini.tasta();
            this.tasta11 = new pianinaMini.tasta();
            this.tasta12 = new pianinaMini.tasta();
            this.tasta4 = new pianinaMini.tasta();
            this.tasta5 = new pianinaMini.tasta();
            this.tasta6 = new pianinaMini.tasta();
            this.tasta3 = new pianinaMini.tasta();
            this.tasta2 = new pianinaMini.tasta();
            this.tasta1 = new pianinaMini.tasta();
            this.tasta49 = new pianinaMini.tasta();
            this.tasta50 = new pianinaMini.tasta();
            this.tasta51 = new pianinaMini.tasta();
            this.tasta52 = new pianinaMini.tasta();
            this.tasta53 = new pianinaMini.tasta();
            this.tasta54 = new pianinaMini.tasta();
            this.tasta55 = new pianinaMini.tasta();
            this.tasta56 = new pianinaMini.tasta();
            this.tasta57 = new pianinaMini.tasta();
            this.tasta58 = new pianinaMini.tasta();
            this.tasta59 = new pianinaMini.tasta();
            this.tasta60 = new pianinaMini.tasta();
            this.tasta61 = new pianinaMini.tasta();
            this.tasta62 = new pianinaMini.tasta();
            this.tasta63 = new pianinaMini.tasta();
            this.tasta64 = new pianinaMini.tasta();
            this.tasta65 = new pianinaMini.tasta();
            this.tasta66 = new pianinaMini.tasta();
            this.tasta67 = new pianinaMini.tasta();
            this.tasta68 = new pianinaMini.tasta();
            this.tasta69 = new pianinaMini.tasta();
            this.tasta70 = new pianinaMini.tasta();
            this.tasta71 = new pianinaMini.tasta();
            this.tasta72 = new pianinaMini.tasta();
            this.tasta73 = new pianinaMini.tasta();
            this.tasta74 = new pianinaMini.tasta();
            this.tasta75 = new pianinaMini.tasta();
            this.tasta76 = new pianinaMini.tasta();
            this.tasta77 = new pianinaMini.tasta();
            this.tasta78 = new pianinaMini.tasta();
            this.tasta79 = new pianinaMini.tasta();
            this.tasta80 = new pianinaMini.tasta();
            this.tasta81 = new pianinaMini.tasta();
            this.tasta82 = new pianinaMini.tasta();
            this.tasta83 = new pianinaMini.tasta();
            this.tasta84 = new pianinaMini.tasta();
            this.tasta85 = new pianinaMini.tasta();
            this.tasta86 = new pianinaMini.tasta();
            this.tasta87 = new pianinaMini.tasta();
            this.tasta88 = new pianinaMini.tasta();
            this.tasta89 = new pianinaMini.tasta();
            this.tasta90 = new pianinaMini.tasta();
            this.tasta91 = new pianinaMini.tasta();
            this.tasta92 = new pianinaMini.tasta();
            this.tasta93 = new pianinaMini.tasta();
            this.tasta94 = new pianinaMini.tasta();
            this.tasta95 = new pianinaMini.tasta();
            this.tasta96 = new pianinaMini.tasta();
            this.tasta97 = new pianinaMini.tasta();
            this.tasta98 = new pianinaMini.tasta();
            this.tasta99 = new pianinaMini.tasta();
            this.tasta100 = new pianinaMini.tasta();
            this.tasta101 = new pianinaMini.tasta();
            this.tasta102 = new pianinaMini.tasta();
            this.tasta103 = new pianinaMini.tasta();
            this.tasta104 = new pianinaMini.tasta();
            this.tasta105 = new pianinaMini.tasta();
            this.tasta106 = new pianinaMini.tasta();
            this.tasta107 = new pianinaMini.tasta();
            this.tasta108 = new pianinaMini.tasta();
            this.tasta109 = new pianinaMini.tasta();
            this.tasta110 = new pianinaMini.tasta();
            this.tasta111 = new pianinaMini.tasta();
            this.tasta112 = new pianinaMini.tasta();
            this.tasta113 = new pianinaMini.tasta();
            this.tasta114 = new pianinaMini.tasta();
            this.tasta115 = new pianinaMini.tasta();
            this.tasta116 = new pianinaMini.tasta();
            this.tasta117 = new pianinaMini.tasta();
            this.tasta118 = new pianinaMini.tasta();
            this.tasta119 = new pianinaMini.tasta();
            this.tasta120 = new pianinaMini.tasta();
            this.tasta121 = new pianinaMini.tasta();
            this.tasta122 = new pianinaMini.tasta();
            this.tasta123 = new pianinaMini.tasta();
            this.tasta124 = new pianinaMini.tasta();
            this.tasta125 = new pianinaMini.tasta();
            this.tasta126 = new pianinaMini.tasta();
            this.tasta127 = new pianinaMini.tasta();
            this.tasta128 = new pianinaMini.tasta();
            this.tasta129 = new pianinaMini.tasta();
            this.tasta130 = new pianinaMini.tasta();
            this.tasta131 = new pianinaMini.tasta();
            this.tasta132 = new pianinaMini.tasta();
            this.tasta133 = new pianinaMini.tasta();
            this.tasta134 = new pianinaMini.tasta();
            this.tasta135 = new pianinaMini.tasta();
            this.tasta136 = new pianinaMini.tasta();
            this.tasta137 = new pianinaMini.tasta();
            this.tasta138 = new pianinaMini.tasta();
            this.tasta139 = new pianinaMini.tasta();
            this.tasta140 = new pianinaMini.tasta();
            this.tasta141 = new pianinaMini.tasta();
            this.tasta142 = new pianinaMini.tasta();
            this.tasta143 = new pianinaMini.tasta();
            this.tasta144 = new pianinaMini.tasta();
            this.tasta145 = new pianinaMini.tasta();
            this.tasta146 = new pianinaMini.tasta();
            this.tasta147 = new pianinaMini.tasta();
            this.tasta148 = new pianinaMini.tasta();
            this.tasta149 = new pianinaMini.tasta();
            this.tasta150 = new pianinaMini.tasta();
            this.tasta151 = new pianinaMini.tasta();
            this.tasta152 = new pianinaMini.tasta();
            this.tasta153 = new pianinaMini.tasta();
            this.tasta154 = new pianinaMini.tasta();
            this.tasta155 = new pianinaMini.tasta();
            this.tasta156 = new pianinaMini.tasta();
            this.tasta157 = new pianinaMini.tasta();
            this.tasta158 = new pianinaMini.tasta();
            this.tasta159 = new pianinaMini.tasta();
            this.tasta160 = new pianinaMini.tasta();
            this.tasta161 = new pianinaMini.tasta();
            this.tasta162 = new pianinaMini.tasta();
            this.tasta163 = new pianinaMini.tasta();
            this.tasta164 = new pianinaMini.tasta();
            this.tasta165 = new pianinaMini.tasta();
            this.tasta166 = new pianinaMini.tasta();
            this.tasta167 = new pianinaMini.tasta();
            this.tasta168 = new pianinaMini.tasta();
            this.tasta169 = new pianinaMini.tasta();
            this.tasta170 = new pianinaMini.tasta();
            this.tasta171 = new pianinaMini.tasta();
            this.tasta172 = new pianinaMini.tasta();
            this.tasta173 = new pianinaMini.tasta();
            this.tasta174 = new pianinaMini.tasta();
            this.tasta175 = new pianinaMini.tasta();
            this.tasta176 = new pianinaMini.tasta();
            this.tasta177 = new pianinaMini.tasta();
            this.tasta178 = new pianinaMini.tasta();
            this.tasta179 = new pianinaMini.tasta();
            this.tasta180 = new pianinaMini.tasta();
            this.tasta181 = new pianinaMini.tasta();
            this.tasta182 = new pianinaMini.tasta();
            this.tasta183 = new pianinaMini.tasta();
            this.tasta184 = new pianinaMini.tasta();
            this.tasta185 = new pianinaMini.tasta();
            this.tasta186 = new pianinaMini.tasta();
            this.tasta187 = new pianinaMini.tasta();
            this.tasta188 = new pianinaMini.tasta();
            this.tasta189 = new pianinaMini.tasta();
            this.tasta190 = new pianinaMini.tasta();
            this.tasta191 = new pianinaMini.tasta();
            this.tasta192 = new pianinaMini.tasta();
            this.tasta193 = new pianinaMini.tasta();
            this.tasta194 = new pianinaMini.tasta();
            this.tasta195 = new pianinaMini.tasta();
            this.tasta196 = new pianinaMini.tasta();
            this.tasta197 = new pianinaMini.tasta();
            this.tasta198 = new pianinaMini.tasta();
            this.tasta199 = new pianinaMini.tasta();
            this.tasta200 = new pianinaMini.tasta();
            this.tasta201 = new pianinaMini.tasta();
            this.tasta202 = new pianinaMini.tasta();
            this.tasta203 = new pianinaMini.tasta();
            this.tasta204 = new pianinaMini.tasta();
            this.tasta205 = new pianinaMini.tasta();
            this.tasta206 = new pianinaMini.tasta();
            this.tasta207 = new pianinaMini.tasta();
            this.tasta208 = new pianinaMini.tasta();
            this.tasta209 = new pianinaMini.tasta();
            this.tasta210 = new pianinaMini.tasta();
            this.tasta211 = new pianinaMini.tasta();
            this.tasta212 = new pianinaMini.tasta();
            this.tasta213 = new pianinaMini.tasta();
            this.tasta214 = new pianinaMini.tasta();
            this.tasta215 = new pianinaMini.tasta();
            this.tasta216 = new pianinaMini.tasta();
            this.tasta217 = new pianinaMini.tasta();
            this.tasta218 = new pianinaMini.tasta();
            this.tasta219 = new pianinaMini.tasta();
            this.tasta220 = new pianinaMini.tasta();
            this.tasta221 = new pianinaMini.tasta();
            this.tasta222 = new pianinaMini.tasta();
            this.tasta223 = new pianinaMini.tasta();
            this.tasta224 = new pianinaMini.tasta();
            this.tasta225 = new pianinaMini.tasta();
            this.tasta226 = new pianinaMini.tasta();
            this.tasta227 = new pianinaMini.tasta();
            this.tasta228 = new pianinaMini.tasta();
            this.tasta229 = new pianinaMini.tasta();
            this.tasta230 = new pianinaMini.tasta();
            this.tasta231 = new pianinaMini.tasta();
            this.tasta232 = new pianinaMini.tasta();
            this.tasta233 = new pianinaMini.tasta();
            this.tasta234 = new pianinaMini.tasta();
            this.tasta235 = new pianinaMini.tasta();
            this.tasta236 = new pianinaMini.tasta();
            this.tasta237 = new pianinaMini.tasta();
            this.tasta238 = new pianinaMini.tasta();
            this.tasta239 = new pianinaMini.tasta();
            this.tasta240 = new pianinaMini.tasta();
            this.tasta241 = new pianinaMini.tasta();
            this.tasta242 = new pianinaMini.tasta();
            this.tasta243 = new pianinaMini.tasta();
            this.tasta244 = new pianinaMini.tasta();
            this.tasta245 = new pianinaMini.tasta();
            this.tasta246 = new pianinaMini.tasta();
            this.tasta247 = new pianinaMini.tasta();
            this.tasta248 = new pianinaMini.tasta();
            this.tasta249 = new pianinaMini.tasta();
            this.tasta250 = new pianinaMini.tasta();
            this.tasta251 = new pianinaMini.tasta();
            this.tasta252 = new pianinaMini.tasta();
            this.tasta253 = new pianinaMini.tasta();
            this.tasta254 = new pianinaMini.tasta();
            this.tasta255 = new pianinaMini.tasta();
            this.tasta256 = new pianinaMini.tasta();
            this.tasta257 = new pianinaMini.tasta();
            this.tasta258 = new pianinaMini.tasta();
            this.tasta259 = new pianinaMini.tasta();
            this.tasta260 = new pianinaMini.tasta();
            this.tasta261 = new pianinaMini.tasta();
            this.tasta262 = new pianinaMini.tasta();
            this.tasta263 = new pianinaMini.tasta();
            this.tasta264 = new pianinaMini.tasta();
            this.tasta265 = new pianinaMini.tasta();
            this.tasta266 = new pianinaMini.tasta();
            this.tasta267 = new pianinaMini.tasta();
            this.tasta268 = new pianinaMini.tasta();
            this.tasta269 = new pianinaMini.tasta();
            this.tasta270 = new pianinaMini.tasta();
            this.tasta271 = new pianinaMini.tasta();
            this.tasta272 = new pianinaMini.tasta();
            this.tasta273 = new pianinaMini.tasta();
            this.tasta274 = new pianinaMini.tasta();
            this.tasta275 = new pianinaMini.tasta();
            this.tasta276 = new pianinaMini.tasta();
            this.tasta277 = new pianinaMini.tasta();
            this.tasta278 = new pianinaMini.tasta();
            this.tasta279 = new pianinaMini.tasta();
            this.tasta280 = new pianinaMini.tasta();
            this.tasta281 = new pianinaMini.tasta();
            this.tasta282 = new pianinaMini.tasta();
            this.tasta283 = new pianinaMini.tasta();
            this.tasta284 = new pianinaMini.tasta();
            this.tasta285 = new pianinaMini.tasta();
            this.tasta286 = new pianinaMini.tasta();
            this.tasta287 = new pianinaMini.tasta();
            this.tasta288 = new pianinaMini.tasta();
            this.tasta289 = new pianinaMini.tasta();
            this.tasta290 = new pianinaMini.tasta();
            this.tasta291 = new pianinaMini.tasta();
            this.tasta292 = new pianinaMini.tasta();
            this.tasta293 = new pianinaMini.tasta();
            this.tasta294 = new pianinaMini.tasta();
            this.tasta295 = new pianinaMini.tasta();
            this.tasta296 = new pianinaMini.tasta();
            this.tasta297 = new pianinaMini.tasta();
            this.tasta298 = new pianinaMini.tasta();
            this.tasta299 = new pianinaMini.tasta();
            this.tasta300 = new pianinaMini.tasta();
            this.tasta301 = new pianinaMini.tasta();
            this.tasta302 = new pianinaMini.tasta();
            this.tasta303 = new pianinaMini.tasta();
            this.tasta304 = new pianinaMini.tasta();
            this.tasta305 = new pianinaMini.tasta();
            this.tasta306 = new pianinaMini.tasta();
            this.tasta307 = new pianinaMini.tasta();
            this.tasta308 = new pianinaMini.tasta();
            this.tasta309 = new pianinaMini.tasta();
            this.tasta310 = new pianinaMini.tasta();
            this.tasta311 = new pianinaMini.tasta();
            this.tasta312 = new pianinaMini.tasta();
            this.tasta313 = new pianinaMini.tasta();
            this.tasta314 = new pianinaMini.tasta();
            this.tasta315 = new pianinaMini.tasta();
            this.tasta316 = new pianinaMini.tasta();
            this.tasta317 = new pianinaMini.tasta();
            this.tasta318 = new pianinaMini.tasta();
            this.tasta319 = new pianinaMini.tasta();
            this.tasta320 = new pianinaMini.tasta();
            this.tasta321 = new pianinaMini.tasta();
            this.tasta322 = new pianinaMini.tasta();
            this.tasta323 = new pianinaMini.tasta();
            this.tasta324 = new pianinaMini.tasta();
            this.tasta325 = new pianinaMini.tasta();
            this.tasta326 = new pianinaMini.tasta();
            this.tasta327 = new pianinaMini.tasta();
            this.tasta328 = new pianinaMini.tasta();
            this.tasta329 = new pianinaMini.tasta();
            this.tasta330 = new pianinaMini.tasta();
            this.tasta331 = new pianinaMini.tasta();
            this.tasta332 = new pianinaMini.tasta();
            this.tasta333 = new pianinaMini.tasta();
            this.tasta334 = new pianinaMini.tasta();
            this.tasta335 = new pianinaMini.tasta();
            this.tasta336 = new pianinaMini.tasta();
            this.tasta337 = new pianinaMini.tasta();
            this.tasta338 = new pianinaMini.tasta();
            this.tasta339 = new pianinaMini.tasta();
            this.tasta340 = new pianinaMini.tasta();
            this.tasta341 = new pianinaMini.tasta();
            this.tasta342 = new pianinaMini.tasta();
            this.tasta343 = new pianinaMini.tasta();
            this.tasta344 = new pianinaMini.tasta();
            this.tasta345 = new pianinaMini.tasta();
            this.tasta346 = new pianinaMini.tasta();
            this.tasta347 = new pianinaMini.tasta();
            this.tasta348 = new pianinaMini.tasta();
            this.tasta349 = new pianinaMini.tasta();
            this.tasta350 = new pianinaMini.tasta();
            this.tasta351 = new pianinaMini.tasta();
            this.tasta352 = new pianinaMini.tasta();
            this.tasta353 = new pianinaMini.tasta();
            this.tasta354 = new pianinaMini.tasta();
            this.tasta355 = new pianinaMini.tasta();
            this.tasta356 = new pianinaMini.tasta();
            this.tasta357 = new pianinaMini.tasta();
            this.tasta358 = new pianinaMini.tasta();
            this.tasta359 = new pianinaMini.tasta();
            this.tasta360 = new pianinaMini.tasta();
            this.tasta361 = new pianinaMini.tasta();
            this.tasta362 = new pianinaMini.tasta();
            this.tasta363 = new pianinaMini.tasta();
            this.tasta364 = new pianinaMini.tasta();
            this.tasta365 = new pianinaMini.tasta();
            this.tasta366 = new pianinaMini.tasta();
            this.tasta367 = new pianinaMini.tasta();
            this.tasta368 = new pianinaMini.tasta();
            this.tasta369 = new pianinaMini.tasta();
            this.tasta370 = new pianinaMini.tasta();
            this.tasta371 = new pianinaMini.tasta();
            this.tasta372 = new pianinaMini.tasta();
            this.tasta373 = new pianinaMini.tasta();
            this.tasta374 = new pianinaMini.tasta();
            this.tasta375 = new pianinaMini.tasta();
            this.tasta376 = new pianinaMini.tasta();
            this.tasta377 = new pianinaMini.tasta();
            this.tasta378 = new pianinaMini.tasta();
            this.tasta379 = new pianinaMini.tasta();
            this.tasta380 = new pianinaMini.tasta();
            this.tasta381 = new pianinaMini.tasta();
            this.tasta382 = new pianinaMini.tasta();
            this.tasta383 = new pianinaMini.tasta();
            this.tasta384 = new pianinaMini.tasta();
            this.tasta385 = new pianinaMini.tasta();
            this.tasta386 = new pianinaMini.tasta();
            this.tasta387 = new pianinaMini.tasta();
            this.tasta388 = new pianinaMini.tasta();
            this.tasta389 = new pianinaMini.tasta();
            this.tasta390 = new pianinaMini.tasta();
            this.tasta391 = new pianinaMini.tasta();
            this.tasta392 = new pianinaMini.tasta();
            this.tasta393 = new pianinaMini.tasta();
            this.tasta394 = new pianinaMini.tasta();
            this.tasta395 = new pianinaMini.tasta();
            this.tasta396 = new pianinaMini.tasta();
            this.tasta397 = new pianinaMini.tasta();
            this.tasta398 = new pianinaMini.tasta();
            this.tasta399 = new pianinaMini.tasta();
            this.tasta400 = new pianinaMini.tasta();
            this.tasta401 = new pianinaMini.tasta();
            this.tasta402 = new pianinaMini.tasta();
            this.tasta403 = new pianinaMini.tasta();
            this.tasta404 = new pianinaMini.tasta();
            this.tasta405 = new pianinaMini.tasta();
            this.tasta406 = new pianinaMini.tasta();
            this.tasta407 = new pianinaMini.tasta();
            this.tasta408 = new pianinaMini.tasta();
            this.tasta409 = new pianinaMini.tasta();
            this.tasta410 = new pianinaMini.tasta();
            this.tasta411 = new pianinaMini.tasta();
            this.tasta412 = new pianinaMini.tasta();
            this.tasta413 = new pianinaMini.tasta();
            this.tasta414 = new pianinaMini.tasta();
            this.tasta415 = new pianinaMini.tasta();
            this.tasta416 = new pianinaMini.tasta();
            this.tasta417 = new pianinaMini.tasta();
            this.tasta418 = new pianinaMini.tasta();
            this.tasta419 = new pianinaMini.tasta();
            this.tasta420 = new pianinaMini.tasta();
            this.tasta421 = new pianinaMini.tasta();
            this.tasta422 = new pianinaMini.tasta();
            this.tasta423 = new pianinaMini.tasta();
            this.tasta424 = new pianinaMini.tasta();
            this.tasta425 = new pianinaMini.tasta();
            this.tasta426 = new pianinaMini.tasta();
            this.tasta427 = new pianinaMini.tasta();
            this.tasta428 = new pianinaMini.tasta();
            this.tasta429 = new pianinaMini.tasta();
            this.tasta430 = new pianinaMini.tasta();
            this.tasta431 = new pianinaMini.tasta();
            this.tasta432 = new pianinaMini.tasta();
            this.tasta433 = new pianinaMini.tasta();
            this.tasta434 = new pianinaMini.tasta();
            this.tasta435 = new pianinaMini.tasta();
            this.tasta436 = new pianinaMini.tasta();
            this.tasta437 = new pianinaMini.tasta();
            this.tasta438 = new pianinaMini.tasta();
            this.tasta439 = new pianinaMini.tasta();
            this.tasta440 = new pianinaMini.tasta();
            this.tasta441 = new pianinaMini.tasta();
            this.tasta442 = new pianinaMini.tasta();
            this.tasta443 = new pianinaMini.tasta();
            this.tasta444 = new pianinaMini.tasta();
            this.tasta445 = new pianinaMini.tasta();
            this.tasta446 = new pianinaMini.tasta();
            this.tasta447 = new pianinaMini.tasta();
            this.tasta448 = new pianinaMini.tasta();
            this.tasta449 = new pianinaMini.tasta();
            this.tasta450 = new pianinaMini.tasta();
            this.tasta451 = new pianinaMini.tasta();
            this.tasta452 = new pianinaMini.tasta();
            this.tasta453 = new pianinaMini.tasta();
            this.tasta454 = new pianinaMini.tasta();
            this.tasta455 = new pianinaMini.tasta();
            this.tasta456 = new pianinaMini.tasta();
            this.tasta457 = new pianinaMini.tasta();
            this.tasta458 = new pianinaMini.tasta();
            this.tasta459 = new pianinaMini.tasta();
            this.tasta460 = new pianinaMini.tasta();
            this.tasta461 = new pianinaMini.tasta();
            this.tasta462 = new pianinaMini.tasta();
            this.tasta463 = new pianinaMini.tasta();
            this.tasta464 = new pianinaMini.tasta();
            this.tasta465 = new pianinaMini.tasta();
            this.tasta466 = new pianinaMini.tasta();
            this.tasta467 = new pianinaMini.tasta();
            this.tasta468 = new pianinaMini.tasta();
            this.tasta469 = new pianinaMini.tasta();
            this.tasta470 = new pianinaMini.tasta();
            this.tasta471 = new pianinaMini.tasta();
            this.tasta472 = new pianinaMini.tasta();
            this.tasta473 = new pianinaMini.tasta();
            this.tasta474 = new pianinaMini.tasta();
            this.tasta475 = new pianinaMini.tasta();
            this.tasta476 = new pianinaMini.tasta();
            this.tasta477 = new pianinaMini.tasta();
            this.tasta478 = new pianinaMini.tasta();
            this.tasta479 = new pianinaMini.tasta();
            this.tasta480 = new pianinaMini.tasta();
            this.tasta481 = new pianinaMini.tasta();
            this.tasta482 = new pianinaMini.tasta();
            this.tasta483 = new pianinaMini.tasta();
            this.tasta484 = new pianinaMini.tasta();
            this.tasta485 = new pianinaMini.tasta();
            this.tasta486 = new pianinaMini.tasta();
            this.tasta487 = new pianinaMini.tasta();
            this.tasta488 = new pianinaMini.tasta();
            this.tasta489 = new pianinaMini.tasta();
            this.tasta490 = new pianinaMini.tasta();
            this.tasta491 = new pianinaMini.tasta();
            this.tasta492 = new pianinaMini.tasta();
            this.tasta493 = new pianinaMini.tasta();
            this.tasta494 = new pianinaMini.tasta();
            this.tasta495 = new pianinaMini.tasta();
            this.tasta496 = new pianinaMini.tasta();
            this.tasta497 = new pianinaMini.tasta();
            this.tasta498 = new pianinaMini.tasta();
            this.tasta499 = new pianinaMini.tasta();
            this.tasta500 = new pianinaMini.tasta();
            this.tasta501 = new pianinaMini.tasta();
            this.tasta502 = new pianinaMini.tasta();
            this.tasta503 = new pianinaMini.tasta();
            this.tasta504 = new pianinaMini.tasta();
            this.tasta505 = new pianinaMini.tasta();
            this.tasta506 = new pianinaMini.tasta();
            this.tasta507 = new pianinaMini.tasta();
            this.tasta508 = new pianinaMini.tasta();
            this.tasta509 = new pianinaMini.tasta();
            this.tasta510 = new pianinaMini.tasta();
            this.tasta511 = new pianinaMini.tasta();
            this.tasta512 = new pianinaMini.tasta();
            this.tasta513 = new pianinaMini.tasta();
            this.tasta514 = new pianinaMini.tasta();
            this.tasta515 = new pianinaMini.tasta();
            this.tasta516 = new pianinaMini.tasta();
            this.tasta517 = new pianinaMini.tasta();
            this.tasta518 = new pianinaMini.tasta();
            this.tasta519 = new pianinaMini.tasta();
            this.tasta520 = new pianinaMini.tasta();
            this.tasta521 = new pianinaMini.tasta();
            this.tasta522 = new pianinaMini.tasta();
            this.tasta523 = new pianinaMini.tasta();
            this.tasta524 = new pianinaMini.tasta();
            this.tasta525 = new pianinaMini.tasta();
            this.tasta526 = new pianinaMini.tasta();
            this.tasta527 = new pianinaMini.tasta();
            this.tasta528 = new pianinaMini.tasta();
            this.tasta529 = new pianinaMini.tasta();
            this.tasta530 = new pianinaMini.tasta();
            this.tasta531 = new pianinaMini.tasta();
            this.tasta532 = new pianinaMini.tasta();
            this.tasta533 = new pianinaMini.tasta();
            this.tasta534 = new pianinaMini.tasta();
            this.tasta535 = new pianinaMini.tasta();
            this.tasta536 = new pianinaMini.tasta();
            this.tasta537 = new pianinaMini.tasta();
            this.tasta538 = new pianinaMini.tasta();
            this.tasta539 = new pianinaMini.tasta();
            this.tasta540 = new pianinaMini.tasta();
            this.tasta541 = new pianinaMini.tasta();
            this.tasta542 = new pianinaMini.tasta();
            this.tasta543 = new pianinaMini.tasta();
            this.tasta544 = new pianinaMini.tasta();
            this.tasta545 = new pianinaMini.tasta();
            this.tasta546 = new pianinaMini.tasta();
            this.tasta547 = new pianinaMini.tasta();
            this.tasta548 = new pianinaMini.tasta();
            this.tasta549 = new pianinaMini.tasta();
            this.tasta550 = new pianinaMini.tasta();
            this.tasta551 = new pianinaMini.tasta();
            this.tasta552 = new pianinaMini.tasta();
            this.tasta553 = new pianinaMini.tasta();
            this.tasta554 = new pianinaMini.tasta();
            this.tasta555 = new pianinaMini.tasta();
            this.tasta556 = new pianinaMini.tasta();
            this.tasta557 = new pianinaMini.tasta();
            this.tasta558 = new pianinaMini.tasta();
            this.tasta559 = new pianinaMini.tasta();
            this.tasta560 = new pianinaMini.tasta();
            this.tasta561 = new pianinaMini.tasta();
            this.tasta562 = new pianinaMini.tasta();
            this.tasta563 = new pianinaMini.tasta();
            this.tasta564 = new pianinaMini.tasta();
            this.tasta565 = new pianinaMini.tasta();
            this.tasta566 = new pianinaMini.tasta();
            this.tasta567 = new pianinaMini.tasta();
            this.tasta568 = new pianinaMini.tasta();
            this.tasta569 = new pianinaMini.tasta();
            this.tasta570 = new pianinaMini.tasta();
            this.tasta571 = new pianinaMini.tasta();
            this.tasta572 = new pianinaMini.tasta();
            this.tasta573 = new pianinaMini.tasta();
            this.tasta574 = new pianinaMini.tasta();
            this.tasta575 = new pianinaMini.tasta();
            this.tasta576 = new pianinaMini.tasta();
            this.tasta577 = new pianinaMini.tasta();
            this.tasta578 = new pianinaMini.tasta();
            this.tasta579 = new pianinaMini.tasta();
            this.tasta580 = new pianinaMini.tasta();
            this.tasta581 = new pianinaMini.tasta();
            this.tasta582 = new pianinaMini.tasta();
            this.tasta583 = new pianinaMini.tasta();
            this.tasta584 = new pianinaMini.tasta();
            this.tasta585 = new pianinaMini.tasta();
            this.tasta586 = new pianinaMini.tasta();
            this.tasta587 = new pianinaMini.tasta();
            this.tasta588 = new pianinaMini.tasta();
            this.tasta589 = new pianinaMini.tasta();
            this.tasta590 = new pianinaMini.tasta();
            this.tasta591 = new pianinaMini.tasta();
            this.tasta592 = new pianinaMini.tasta();
            this.tasta593 = new pianinaMini.tasta();
            this.tasta594 = new pianinaMini.tasta();
            this.tasta595 = new pianinaMini.tasta();
            this.tasta596 = new pianinaMini.tasta();
            this.tasta597 = new pianinaMini.tasta();
            this.tasta598 = new pianinaMini.tasta();
            this.tasta599 = new pianinaMini.tasta();
            this.tasta600 = new pianinaMini.tasta();
            this.tasta601 = new pianinaMini.tasta();
            this.tasta602 = new pianinaMini.tasta();
            this.tasta603 = new pianinaMini.tasta();
            this.tasta604 = new pianinaMini.tasta();
            this.tasta605 = new pianinaMini.tasta();
            this.tasta606 = new pianinaMini.tasta();
            this.tasta607 = new pianinaMini.tasta();
            this.tasta608 = new pianinaMini.tasta();
            this.tasta609 = new pianinaMini.tasta();
            this.tasta610 = new pianinaMini.tasta();
            this.tasta611 = new pianinaMini.tasta();
            this.tasta612 = new pianinaMini.tasta();
            this.tasta613 = new pianinaMini.tasta();
            this.tasta614 = new pianinaMini.tasta();
            this.tasta615 = new pianinaMini.tasta();
            this.tasta616 = new pianinaMini.tasta();
            this.tasta617 = new pianinaMini.tasta();
            this.tasta618 = new pianinaMini.tasta();
            this.tasta619 = new pianinaMini.tasta();
            this.tasta620 = new pianinaMini.tasta();
            this.tasta621 = new pianinaMini.tasta();
            this.tasta622 = new pianinaMini.tasta();
            this.tasta623 = new pianinaMini.tasta();
            this.tasta624 = new pianinaMini.tasta();
            this.tasta625 = new pianinaMini.tasta();
            this.tasta626 = new pianinaMini.tasta();
            this.tasta627 = new pianinaMini.tasta();
            this.tasta628 = new pianinaMini.tasta();
            this.tasta629 = new pianinaMini.tasta();
            this.tasta630 = new pianinaMini.tasta();
            this.tasta631 = new pianinaMini.tasta();
            this.tasta632 = new pianinaMini.tasta();
            this.tasta633 = new pianinaMini.tasta();
            this.tasta634 = new pianinaMini.tasta();
            this.tasta635 = new pianinaMini.tasta();
            this.tasta636 = new pianinaMini.tasta();
            this.tasta637 = new pianinaMini.tasta();
            this.tasta638 = new pianinaMini.tasta();
            this.tasta639 = new pianinaMini.tasta();
            this.tasta640 = new pianinaMini.tasta();
            this.tasta641 = new pianinaMini.tasta();
            this.tasta642 = new pianinaMini.tasta();
            this.tasta643 = new pianinaMini.tasta();
            this.tasta644 = new pianinaMini.tasta();
            this.tasta645 = new pianinaMini.tasta();
            this.tasta646 = new pianinaMini.tasta();
            this.tasta647 = new pianinaMini.tasta();
            this.tasta648 = new pianinaMini.tasta();
            this.tasta649 = new pianinaMini.tasta();
            this.tasta650 = new pianinaMini.tasta();
            this.tasta651 = new pianinaMini.tasta();
            this.tasta652 = new pianinaMini.tasta();
            this.tasta653 = new pianinaMini.tasta();
            this.tasta654 = new pianinaMini.tasta();
            this.tasta655 = new pianinaMini.tasta();
            this.tasta656 = new pianinaMini.tasta();
            this.tasta657 = new pianinaMini.tasta();
            this.tasta658 = new pianinaMini.tasta();
            this.tasta659 = new pianinaMini.tasta();
            this.tasta660 = new pianinaMini.tasta();
            this.tasta661 = new pianinaMini.tasta();
            this.tasta662 = new pianinaMini.tasta();
            this.tasta663 = new pianinaMini.tasta();
            this.tasta664 = new pianinaMini.tasta();
            this.tasta665 = new pianinaMini.tasta();
            this.tasta666 = new pianinaMini.tasta();
            this.tasta667 = new pianinaMini.tasta();
            this.tasta668 = new pianinaMini.tasta();
            this.tasta669 = new pianinaMini.tasta();
            this.tasta670 = new pianinaMini.tasta();
            this.tasta671 = new pianinaMini.tasta();
            this.tasta672 = new pianinaMini.tasta();
            this.tasta673 = new pianinaMini.tasta();
            this.tasta674 = new pianinaMini.tasta();
            this.tasta675 = new pianinaMini.tasta();
            this.tasta676 = new pianinaMini.tasta();
            this.tasta677 = new pianinaMini.tasta();
            this.tasta678 = new pianinaMini.tasta();
            this.tasta679 = new pianinaMini.tasta();
            this.tasta680 = new pianinaMini.tasta();
            this.tasta681 = new pianinaMini.tasta();
            this.tasta682 = new pianinaMini.tasta();
            this.tasta683 = new pianinaMini.tasta();
            this.tasta684 = new pianinaMini.tasta();
            this.tasta685 = new pianinaMini.tasta();
            this.tasta686 = new pianinaMini.tasta();
            this.tasta687 = new pianinaMini.tasta();
            this.tasta688 = new pianinaMini.tasta();
            this.tasta689 = new pianinaMini.tasta();
            this.tasta690 = new pianinaMini.tasta();
            this.tasta691 = new pianinaMini.tasta();
            this.tasta692 = new pianinaMini.tasta();
            this.tasta693 = new pianinaMini.tasta();
            this.tasta694 = new pianinaMini.tasta();
            this.tasta695 = new pianinaMini.tasta();
            this.tasta696 = new pianinaMini.tasta();
            this.tasta697 = new pianinaMini.tasta();
            this.tasta698 = new pianinaMini.tasta();
            this.tasta699 = new pianinaMini.tasta();
            this.tasta700 = new pianinaMini.tasta();
            this.tasta701 = new pianinaMini.tasta();
            this.tasta702 = new pianinaMini.tasta();
            this.tasta703 = new pianinaMini.tasta();
            this.tasta704 = new pianinaMini.tasta();
            this.tasta705 = new pianinaMini.tasta();
            this.tasta706 = new pianinaMini.tasta();
            this.tasta707 = new pianinaMini.tasta();
            this.tasta708 = new pianinaMini.tasta();
            this.tasta709 = new pianinaMini.tasta();
            this.tasta710 = new pianinaMini.tasta();
            this.tasta711 = new pianinaMini.tasta();
            this.tasta712 = new pianinaMini.tasta();
            this.tasta713 = new pianinaMini.tasta();
            this.tasta714 = new pianinaMini.tasta();
            this.tasta715 = new pianinaMini.tasta();
            this.tasta716 = new pianinaMini.tasta();
            this.tasta717 = new pianinaMini.tasta();
            this.tasta718 = new pianinaMini.tasta();
            this.tasta719 = new pianinaMini.tasta();
            this.tasta720 = new pianinaMini.tasta();
            this.tasta721 = new pianinaMini.tasta();
            this.tasta722 = new pianinaMini.tasta();
            this.tasta723 = new pianinaMini.tasta();
            this.tasta724 = new pianinaMini.tasta();
            this.tasta725 = new pianinaMini.tasta();
            this.tasta726 = new pianinaMini.tasta();
            this.tasta727 = new pianinaMini.tasta();
            this.tasta728 = new pianinaMini.tasta();
            this.tasta729 = new pianinaMini.tasta();
            this.tasta730 = new pianinaMini.tasta();
            this.tasta731 = new pianinaMini.tasta();
            this.tasta732 = new pianinaMini.tasta();
            this.tasta733 = new pianinaMini.tasta();
            this.tasta734 = new pianinaMini.tasta();
            this.tasta735 = new pianinaMini.tasta();
            this.tasta736 = new pianinaMini.tasta();
            this.tasta737 = new pianinaMini.tasta();
            this.tasta738 = new pianinaMini.tasta();
            this.tasta739 = new pianinaMini.tasta();
            this.tasta740 = new pianinaMini.tasta();
            this.tasta741 = new pianinaMini.tasta();
            this.tasta742 = new pianinaMini.tasta();
            this.tasta743 = new pianinaMini.tasta();
            this.tasta744 = new pianinaMini.tasta();
            this.tasta745 = new pianinaMini.tasta();
            this.tasta746 = new pianinaMini.tasta();
            this.tasta747 = new pianinaMini.tasta();
            this.tasta748 = new pianinaMini.tasta();
            this.tasta749 = new pianinaMini.tasta();
            this.tasta750 = new pianinaMini.tasta();
            this.tasta751 = new pianinaMini.tasta();
            this.tasta752 = new pianinaMini.tasta();
            this.tasta753 = new pianinaMini.tasta();
            this.tasta754 = new pianinaMini.tasta();
            this.tasta755 = new pianinaMini.tasta();
            this.tasta756 = new pianinaMini.tasta();
            this.tasta757 = new pianinaMini.tasta();
            this.tasta758 = new pianinaMini.tasta();
            this.tasta759 = new pianinaMini.tasta();
            this.tasta760 = new pianinaMini.tasta();
            this.tasta761 = new pianinaMini.tasta();
            this.tasta762 = new pianinaMini.tasta();
            this.tasta763 = new pianinaMini.tasta();
            this.tasta764 = new pianinaMini.tasta();
            this.tasta765 = new pianinaMini.tasta();
            this.tasta766 = new pianinaMini.tasta();
            this.tasta767 = new pianinaMini.tasta();
            this.tasta768 = new pianinaMini.tasta();
            this.tasta769 = new pianinaMini.tasta();
            this.tasta770 = new pianinaMini.tasta();
            this.tasta771 = new pianinaMini.tasta();
            this.tasta772 = new pianinaMini.tasta();
            this.tasta773 = new pianinaMini.tasta();
            this.tasta774 = new pianinaMini.tasta();
            this.tasta775 = new pianinaMini.tasta();
            this.tasta776 = new pianinaMini.tasta();
            this.tasta777 = new pianinaMini.tasta();
            this.tasta778 = new pianinaMini.tasta();
            this.tasta779 = new pianinaMini.tasta();
            this.tasta780 = new pianinaMini.tasta();
            this.tasta781 = new pianinaMini.tasta();
            this.tasta782 = new pianinaMini.tasta();
            this.tasta783 = new pianinaMini.tasta();
            this.tasta784 = new pianinaMini.tasta();
            this.tasta785 = new pianinaMini.tasta();
            this.tasta786 = new pianinaMini.tasta();
            this.tasta787 = new pianinaMini.tasta();
            this.tasta788 = new pianinaMini.tasta();
            this.tasta789 = new pianinaMini.tasta();
            this.tasta790 = new pianinaMini.tasta();
            this.tasta791 = new pianinaMini.tasta();
            this.tasta792 = new pianinaMini.tasta();
            this.tasta793 = new pianinaMini.tasta();
            this.tasta794 = new pianinaMini.tasta();
            this.tasta795 = new pianinaMini.tasta();
            this.tasta796 = new pianinaMini.tasta();
            this.tasta797 = new pianinaMini.tasta();
            this.tasta798 = new pianinaMini.tasta();
            this.tasta799 = new pianinaMini.tasta();
            this.tasta800 = new pianinaMini.tasta();
            this.tasta801 = new pianinaMini.tasta();
            this.tasta802 = new pianinaMini.tasta();
            this.tasta803 = new pianinaMini.tasta();
            this.tasta804 = new pianinaMini.tasta();
            this.tasta805 = new pianinaMini.tasta();
            this.tasta806 = new pianinaMini.tasta();
            this.tasta807 = new pianinaMini.tasta();
            this.tasta808 = new pianinaMini.tasta();
            this.tasta809 = new pianinaMini.tasta();
            this.tasta810 = new pianinaMini.tasta();
            this.tasta811 = new pianinaMini.tasta();
            this.tasta812 = new pianinaMini.tasta();
            this.tasta813 = new pianinaMini.tasta();
            this.tasta814 = new pianinaMini.tasta();
            this.tasta815 = new pianinaMini.tasta();
            this.tasta816 = new pianinaMini.tasta();
            this.tasta817 = new pianinaMini.tasta();
            this.tasta818 = new pianinaMini.tasta();
            this.tasta819 = new pianinaMini.tasta();
            this.tasta820 = new pianinaMini.tasta();
            this.tasta821 = new pianinaMini.tasta();
            this.tasta822 = new pianinaMini.tasta();
            this.tasta823 = new pianinaMini.tasta();
            this.tasta824 = new pianinaMini.tasta();
            this.tasta825 = new pianinaMini.tasta();
            this.tasta826 = new pianinaMini.tasta();
            this.tasta827 = new pianinaMini.tasta();
            this.tasta828 = new pianinaMini.tasta();
            this.tasta829 = new pianinaMini.tasta();
            this.tasta830 = new pianinaMini.tasta();
            this.tasta831 = new pianinaMini.tasta();
            this.tasta832 = new pianinaMini.tasta();
            this.tasta833 = new pianinaMini.tasta();
            this.tasta834 = new pianinaMini.tasta();
            this.tasta835 = new pianinaMini.tasta();
            this.tasta836 = new pianinaMini.tasta();
            this.tasta837 = new pianinaMini.tasta();
            this.tasta838 = new pianinaMini.tasta();
            this.tasta839 = new pianinaMini.tasta();
            this.tasta840 = new pianinaMini.tasta();
            this.tasta841 = new pianinaMini.tasta();
            this.tasta842 = new pianinaMini.tasta();
            this.tasta843 = new pianinaMini.tasta();
            this.tasta844 = new pianinaMini.tasta();
            this.tasta845 = new pianinaMini.tasta();
            this.tasta846 = new pianinaMini.tasta();
            this.tasta847 = new pianinaMini.tasta();
            this.tasta848 = new pianinaMini.tasta();
            this.tasta849 = new pianinaMini.tasta();
            this.tasta850 = new pianinaMini.tasta();
            this.tasta851 = new pianinaMini.tasta();
            this.tasta852 = new pianinaMini.tasta();
            this.tasta853 = new pianinaMini.tasta();
            this.tasta854 = new pianinaMini.tasta();
            this.tasta855 = new pianinaMini.tasta();
            this.tasta856 = new pianinaMini.tasta();
            this.tasta857 = new pianinaMini.tasta();
            this.tasta858 = new pianinaMini.tasta();
            this.tasta859 = new pianinaMini.tasta();
            this.tasta860 = new pianinaMini.tasta();
            this.tasta861 = new pianinaMini.tasta();
            this.tasta862 = new pianinaMini.tasta();
            this.tasta863 = new pianinaMini.tasta();
            this.tasta864 = new pianinaMini.tasta();
            this.tasta865 = new pianinaMini.tasta();
            this.tasta866 = new pianinaMini.tasta();
            this.tasta867 = new pianinaMini.tasta();
            this.tasta868 = new pianinaMini.tasta();
            this.tasta869 = new pianinaMini.tasta();
            this.tasta870 = new pianinaMini.tasta();
            this.tasta871 = new pianinaMini.tasta();
            this.tasta872 = new pianinaMini.tasta();
            this.tasta873 = new pianinaMini.tasta();
            this.tasta874 = new pianinaMini.tasta();
            this.tasta875 = new pianinaMini.tasta();
            this.tasta876 = new pianinaMini.tasta();
            this.tasta877 = new pianinaMini.tasta();
            this.tasta878 = new pianinaMini.tasta();
            this.tasta879 = new pianinaMini.tasta();
            this.tasta880 = new pianinaMini.tasta();
            this.tasta881 = new pianinaMini.tasta();
            this.tasta882 = new pianinaMini.tasta();
            this.tasta883 = new pianinaMini.tasta();
            this.tasta884 = new pianinaMini.tasta();
            this.tasta885 = new pianinaMini.tasta();
            this.tasta886 = new pianinaMini.tasta();
            this.tasta887 = new pianinaMini.tasta();
            this.tasta888 = new pianinaMini.tasta();
            this.tasta889 = new pianinaMini.tasta();
            this.tasta890 = new pianinaMini.tasta();
            this.tasta891 = new pianinaMini.tasta();
            this.tasta892 = new pianinaMini.tasta();
            this.tasta893 = new pianinaMini.tasta();
            this.tasta894 = new pianinaMini.tasta();
            this.tasta895 = new pianinaMini.tasta();
            this.tasta896 = new pianinaMini.tasta();
            this.tasta897 = new pianinaMini.tasta();
            this.tasta898 = new pianinaMini.tasta();
            this.tasta899 = new pianinaMini.tasta();
            this.tasta900 = new pianinaMini.tasta();
            this.tasta901 = new pianinaMini.tasta();
            this.tasta902 = new pianinaMini.tasta();
            this.tasta903 = new pianinaMini.tasta();
            this.tasta904 = new pianinaMini.tasta();
            this.tasta905 = new pianinaMini.tasta();
            this.tasta906 = new pianinaMini.tasta();
            this.tasta907 = new pianinaMini.tasta();
            this.tasta908 = new pianinaMini.tasta();
            this.tasta909 = new pianinaMini.tasta();
            this.tasta910 = new pianinaMini.tasta();
            this.tasta911 = new pianinaMini.tasta();
            this.tasta912 = new pianinaMini.tasta();
            this.tasta913 = new pianinaMini.tasta();
            this.tasta914 = new pianinaMini.tasta();
            this.tasta915 = new pianinaMini.tasta();
            this.tasta916 = new pianinaMini.tasta();
            this.tasta917 = new pianinaMini.tasta();
            this.tasta918 = new pianinaMini.tasta();
            this.tasta919 = new pianinaMini.tasta();
            this.tasta920 = new pianinaMini.tasta();
            this.tasta921 = new pianinaMini.tasta();
            this.tasta922 = new pianinaMini.tasta();
            this.tasta923 = new pianinaMini.tasta();
            this.tasta924 = new pianinaMini.tasta();
            this.tasta925 = new pianinaMini.tasta();
            this.tasta926 = new pianinaMini.tasta();
            this.tasta927 = new pianinaMini.tasta();
            this.tasta928 = new pianinaMini.tasta();
            this.tasta929 = new pianinaMini.tasta();
            this.tasta930 = new pianinaMini.tasta();
            this.tasta931 = new pianinaMini.tasta();
            this.tasta932 = new pianinaMini.tasta();
            this.tasta933 = new pianinaMini.tasta();
            this.tasta934 = new pianinaMini.tasta();
            this.tasta935 = new pianinaMini.tasta();
            this.tasta936 = new pianinaMini.tasta();
            this.tasta937 = new pianinaMini.tasta();
            this.tasta938 = new pianinaMini.tasta();
            this.tasta939 = new pianinaMini.tasta();
            this.tasta940 = new pianinaMini.tasta();
            this.tasta941 = new pianinaMini.tasta();
            this.tasta942 = new pianinaMini.tasta();
            this.tasta943 = new pianinaMini.tasta();
            this.tasta944 = new pianinaMini.tasta();
            this.tasta945 = new pianinaMini.tasta();
            this.tasta946 = new pianinaMini.tasta();
            this.tasta947 = new pianinaMini.tasta();
            this.tasta948 = new pianinaMini.tasta();
            this.tasta949 = new pianinaMini.tasta();
            this.tasta950 = new pianinaMini.tasta();
            this.tasta951 = new pianinaMini.tasta();
            this.tasta952 = new pianinaMini.tasta();
            this.tasta953 = new pianinaMini.tasta();
            this.tasta954 = new pianinaMini.tasta();
            this.tasta955 = new pianinaMini.tasta();
            this.tasta956 = new pianinaMini.tasta();
            this.tasta957 = new pianinaMini.tasta();
            this.tasta958 = new pianinaMini.tasta();
            this.tasta959 = new pianinaMini.tasta();
            this.tasta960 = new pianinaMini.tasta();
            this.tasta961 = new pianinaMini.tasta();
            this.tasta962 = new pianinaMini.tasta();
            this.tasta963 = new pianinaMini.tasta();
            this.tasta964 = new pianinaMini.tasta();
            this.tasta965 = new pianinaMini.tasta();
            this.tasta966 = new pianinaMini.tasta();
            this.tasta967 = new pianinaMini.tasta();
            this.tasta968 = new pianinaMini.tasta();
            this.tasta969 = new pianinaMini.tasta();
            this.tasta970 = new pianinaMini.tasta();
            this.tasta971 = new pianinaMini.tasta();
            this.tasta972 = new pianinaMini.tasta();
            this.tasta973 = new pianinaMini.tasta();
            this.tasta974 = new pianinaMini.tasta();
            this.tasta975 = new pianinaMini.tasta();
            this.tasta976 = new pianinaMini.tasta();
            this.tasta977 = new pianinaMini.tasta();
            this.tasta978 = new pianinaMini.tasta();
            this.tasta979 = new pianinaMini.tasta();
            this.tasta980 = new pianinaMini.tasta();
            this.tasta981 = new pianinaMini.tasta();
            this.tasta982 = new pianinaMini.tasta();
            this.tasta983 = new pianinaMini.tasta();
            this.tasta984 = new pianinaMini.tasta();
            this.tasta985 = new pianinaMini.tasta();
            this.tasta986 = new pianinaMini.tasta();
            this.tasta987 = new pianinaMini.tasta();
            this.tasta988 = new pianinaMini.tasta();
            this.tasta989 = new pianinaMini.tasta();
            this.tasta990 = new pianinaMini.tasta();
            this.tasta991 = new pianinaMini.tasta();
            this.tasta992 = new pianinaMini.tasta();
            this.tasta993 = new pianinaMini.tasta();
            this.tasta994 = new pianinaMini.tasta();
            this.tasta995 = new pianinaMini.tasta();
            this.tasta996 = new pianinaMini.tasta();
            this.tasta997 = new pianinaMini.tasta();
            this.tasta998 = new pianinaMini.tasta();
            this.tasta999 = new pianinaMini.tasta();
            this.tasta1000 = new pianinaMini.tasta();
            this.tasta1001 = new pianinaMini.tasta();
            this.tasta1002 = new pianinaMini.tasta();
            this.tasta1003 = new pianinaMini.tasta();
            this.tasta1004 = new pianinaMini.tasta();
            this.tasta1005 = new pianinaMini.tasta();
            this.tasta1006 = new pianinaMini.tasta();
            this.tasta1007 = new pianinaMini.tasta();
            this.tasta1008 = new pianinaMini.tasta();
            this.tasta1009 = new pianinaMini.tasta();
            this.tasta1010 = new pianinaMini.tasta();
            this.tasta1011 = new pianinaMini.tasta();
            this.tasta1012 = new pianinaMini.tasta();
            this.tasta1013 = new pianinaMini.tasta();
            this.tasta1014 = new pianinaMini.tasta();
            this.tasta1015 = new pianinaMini.tasta();
            this.tasta1016 = new pianinaMini.tasta();
            this.tasta1017 = new pianinaMini.tasta();
            this.tasta1018 = new pianinaMini.tasta();
            this.tasta1019 = new pianinaMini.tasta();
            this.tasta1020 = new pianinaMini.tasta();
            this.tasta1021 = new pianinaMini.tasta();
            this.tasta1022 = new pianinaMini.tasta();
            this.tasta1023 = new pianinaMini.tasta();
            this.tasta1024 = new pianinaMini.tasta();
            this.tasta1025 = new pianinaMini.tasta();
            this.tasta1026 = new pianinaMini.tasta();
            this.tasta1027 = new pianinaMini.tasta();
            this.tasta1028 = new pianinaMini.tasta();
            this.tasta1029 = new pianinaMini.tasta();
            this.tasta1030 = new pianinaMini.tasta();
            this.tasta1031 = new pianinaMini.tasta();
            this.tasta1032 = new pianinaMini.tasta();
            this.tasta1033 = new pianinaMini.tasta();
            this.tasta1034 = new pianinaMini.tasta();
            this.tasta1035 = new pianinaMini.tasta();
            this.tasta1036 = new pianinaMini.tasta();
            this.tasta1037 = new pianinaMini.tasta();
            this.tasta1038 = new pianinaMini.tasta();
            this.tasta1039 = new pianinaMini.tasta();
            this.tasta1040 = new pianinaMini.tasta();
            this.tasta1041 = new pianinaMini.tasta();
            this.tasta1042 = new pianinaMini.tasta();
            this.tasta1043 = new pianinaMini.tasta();
            this.tasta1044 = new pianinaMini.tasta();
            this.tasta1045 = new pianinaMini.tasta();
            this.tasta1046 = new pianinaMini.tasta();
            this.tasta1047 = new pianinaMini.tasta();
            this.tasta1048 = new pianinaMini.tasta();
            this.tasta1049 = new pianinaMini.tasta();
            this.tasta1050 = new pianinaMini.tasta();
            this.tasta1051 = new pianinaMini.tasta();
            this.tasta1052 = new pianinaMini.tasta();
            this.tasta1053 = new pianinaMini.tasta();
            this.tasta1054 = new pianinaMini.tasta();
            this.tasta1055 = new pianinaMini.tasta();
            this.tasta1056 = new pianinaMini.tasta();
            this.tasta1057 = new pianinaMini.tasta();
            this.tasta1058 = new pianinaMini.tasta();
            this.tasta1059 = new pianinaMini.tasta();
            this.tasta1060 = new pianinaMini.tasta();
            this.tasta1061 = new pianinaMini.tasta();
            this.tasta1062 = new pianinaMini.tasta();
            this.tasta1063 = new pianinaMini.tasta();
            this.tasta1064 = new pianinaMini.tasta();
            this.tasta1065 = new pianinaMini.tasta();
            this.tasta1066 = new pianinaMini.tasta();
            this.tasta1067 = new pianinaMini.tasta();
            this.tasta1068 = new pianinaMini.tasta();
            this.tasta1069 = new pianinaMini.tasta();
            this.tasta1070 = new pianinaMini.tasta();
            this.tasta1071 = new pianinaMini.tasta();
            this.tasta1072 = new pianinaMini.tasta();
            this.tasta1073 = new pianinaMini.tasta();
            this.tasta1074 = new pianinaMini.tasta();
            this.tasta1075 = new pianinaMini.tasta();
            this.tasta1076 = new pianinaMini.tasta();
            this.tasta1077 = new pianinaMini.tasta();
            this.tasta1078 = new pianinaMini.tasta();
            this.tasta1079 = new pianinaMini.tasta();
            this.tasta1080 = new pianinaMini.tasta();
            this.tasta1081 = new pianinaMini.tasta();
            this.tasta1082 = new pianinaMini.tasta();
            this.tasta1083 = new pianinaMini.tasta();
            this.tasta1084 = new pianinaMini.tasta();
            this.tasta1085 = new pianinaMini.tasta();
            this.tasta1086 = new pianinaMini.tasta();
            this.tasta1087 = new pianinaMini.tasta();
            this.tasta1088 = new pianinaMini.tasta();
            this.tasta1089 = new pianinaMini.tasta();
            this.tasta1090 = new pianinaMini.tasta();
            this.tasta1091 = new pianinaMini.tasta();
            this.tasta1092 = new pianinaMini.tasta();
            this.tasta1093 = new pianinaMini.tasta();
            this.tasta1094 = new pianinaMini.tasta();
            this.tasta1095 = new pianinaMini.tasta();
            this.tasta1096 = new pianinaMini.tasta();
            this.tasta1097 = new pianinaMini.tasta();
            this.tasta1098 = new pianinaMini.tasta();
            this.tasta1099 = new pianinaMini.tasta();
            this.tasta1100 = new pianinaMini.tasta();
            this.tasta1101 = new pianinaMini.tasta();
            this.tasta1102 = new pianinaMini.tasta();
            this.tasta1103 = new pianinaMini.tasta();
            this.tasta1104 = new pianinaMini.tasta();
            this.tasta1105 = new pianinaMini.tasta();
            this.tasta1106 = new pianinaMini.tasta();
            this.tasta1107 = new pianinaMini.tasta();
            this.tasta1108 = new pianinaMini.tasta();
            this.tasta1109 = new pianinaMini.tasta();
            this.tasta1110 = new pianinaMini.tasta();
            this.tasta1111 = new pianinaMini.tasta();
            this.tasta1112 = new pianinaMini.tasta();
            this.tasta1113 = new pianinaMini.tasta();
            this.tasta1114 = new pianinaMini.tasta();
            this.tasta1115 = new pianinaMini.tasta();
            this.tasta1116 = new pianinaMini.tasta();
            this.tasta1117 = new pianinaMini.tasta();
            this.tasta1118 = new pianinaMini.tasta();
            this.tasta1119 = new pianinaMini.tasta();
            this.tasta1120 = new pianinaMini.tasta();
            this.tasta1121 = new pianinaMini.tasta();
            this.tasta1122 = new pianinaMini.tasta();
            this.tasta1123 = new pianinaMini.tasta();
            this.tasta1124 = new pianinaMini.tasta();
            this.tasta1125 = new pianinaMini.tasta();
            this.tasta1126 = new pianinaMini.tasta();
            this.tasta1127 = new pianinaMini.tasta();
            this.tasta1128 = new pianinaMini.tasta();
            this.tasta1129 = new pianinaMini.tasta();
            this.tasta1130 = new pianinaMini.tasta();
            this.tasta1131 = new pianinaMini.tasta();
            this.tasta1132 = new pianinaMini.tasta();
            this.tasta1133 = new pianinaMini.tasta();
            this.tasta1134 = new pianinaMini.tasta();
            this.tasta1135 = new pianinaMini.tasta();
            this.tasta1136 = new pianinaMini.tasta();
            this.tasta1137 = new pianinaMini.tasta();
            this.tasta1138 = new pianinaMini.tasta();
            this.tasta1139 = new pianinaMini.tasta();
            this.tasta1140 = new pianinaMini.tasta();
            this.tasta1141 = new pianinaMini.tasta();
            this.tasta1142 = new pianinaMini.tasta();
            this.tasta1143 = new pianinaMini.tasta();
            this.tasta1144 = new pianinaMini.tasta();
            this.tasta1145 = new pianinaMini.tasta();
            this.tasta1146 = new pianinaMini.tasta();
            this.tasta1147 = new pianinaMini.tasta();
            this.tasta1148 = new pianinaMini.tasta();
            this.tasta1149 = new pianinaMini.tasta();
            this.tasta1150 = new pianinaMini.tasta();
            this.tasta1151 = new pianinaMini.tasta();
            this.tasta1152 = new pianinaMini.tasta();
            this.tasta1153 = new pianinaMini.tasta();
            this.tasta1154 = new pianinaMini.tasta();
            this.tasta1155 = new pianinaMini.tasta();
            this.tasta1156 = new pianinaMini.tasta();
            this.tasta1157 = new pianinaMini.tasta();
            this.tasta1158 = new pianinaMini.tasta();
            this.tasta1159 = new pianinaMini.tasta();
            this.tasta1160 = new pianinaMini.tasta();
            this.tasta1161 = new pianinaMini.tasta();
            this.tasta1162 = new pianinaMini.tasta();
            this.tasta1163 = new pianinaMini.tasta();
            this.tasta1164 = new pianinaMini.tasta();
            this.tasta1165 = new pianinaMini.tasta();
            this.tasta1166 = new pianinaMini.tasta();
            this.tasta1167 = new pianinaMini.tasta();
            this.tasta1168 = new pianinaMini.tasta();
            this.tasta1169 = new pianinaMini.tasta();
            this.tasta1170 = new pianinaMini.tasta();
            this.tasta1171 = new pianinaMini.tasta();
            this.tasta1172 = new pianinaMini.tasta();
            this.tasta1173 = new pianinaMini.tasta();
            this.tasta1174 = new pianinaMini.tasta();
            this.tasta1175 = new pianinaMini.tasta();
            this.tasta1176 = new pianinaMini.tasta();
            this.tasta1177 = new pianinaMini.tasta();
            this.tasta1178 = new pianinaMini.tasta();
            this.tasta1179 = new pianinaMini.tasta();
            this.tasta1180 = new pianinaMini.tasta();
            this.tasta1181 = new pianinaMini.tasta();
            this.tasta1182 = new pianinaMini.tasta();
            this.tasta1183 = new pianinaMini.tasta();
            this.tasta1184 = new pianinaMini.tasta();
            this.tasta1185 = new pianinaMini.tasta();
            this.tasta1186 = new pianinaMini.tasta();
            this.tasta1187 = new pianinaMini.tasta();
            this.tasta1188 = new pianinaMini.tasta();
            this.tasta1189 = new pianinaMini.tasta();
            this.tasta1190 = new pianinaMini.tasta();
            this.tasta1191 = new pianinaMini.tasta();
            this.tasta1192 = new pianinaMini.tasta();
            this.tasta1193 = new pianinaMini.tasta();
            this.tasta1194 = new pianinaMini.tasta();
            this.tasta1195 = new pianinaMini.tasta();
            this.tasta1196 = new pianinaMini.tasta();
            this.tasta1197 = new pianinaMini.tasta();
            this.tasta1198 = new pianinaMini.tasta();
            this.tasta1199 = new pianinaMini.tasta();
            this.tasta1200 = new pianinaMini.tasta();
            this.tasta1201 = new pianinaMini.tasta();
            this.tasta1202 = new pianinaMini.tasta();
            this.tasta1203 = new pianinaMini.tasta();
            this.tasta1204 = new pianinaMini.tasta();
            this.tasta1205 = new pianinaMini.tasta();
            this.tasta1206 = new pianinaMini.tasta();
            this.tasta1207 = new pianinaMini.tasta();
            this.tasta1208 = new pianinaMini.tasta();
            this.tasta1209 = new pianinaMini.tasta();
            this.tasta1210 = new pianinaMini.tasta();
            this.tasta1211 = new pianinaMini.tasta();
            this.tasta1212 = new pianinaMini.tasta();
            this.tasta1213 = new pianinaMini.tasta();
            this.tasta1214 = new pianinaMini.tasta();
            this.tasta1215 = new pianinaMini.tasta();
            this.tasta1216 = new pianinaMini.tasta();
            this.tasta1217 = new pianinaMini.tasta();
            this.tasta1218 = new pianinaMini.tasta();
            this.tasta1219 = new pianinaMini.tasta();
            this.tasta1220 = new pianinaMini.tasta();
            this.tasta1221 = new pianinaMini.tasta();
            this.tasta1222 = new pianinaMini.tasta();
            this.tasta1223 = new pianinaMini.tasta();
            this.tasta1224 = new pianinaMini.tasta();
            this.tasta1225 = new pianinaMini.tasta();
            this.tasta1226 = new pianinaMini.tasta();
            this.tasta1227 = new pianinaMini.tasta();
            this.tasta1228 = new pianinaMini.tasta();
            this.tasta1229 = new pianinaMini.tasta();
            this.tasta1230 = new pianinaMini.tasta();
            this.tasta1231 = new pianinaMini.tasta();
            this.tasta1232 = new pianinaMini.tasta();
            this.tasta1233 = new pianinaMini.tasta();
            this.tasta1234 = new pianinaMini.tasta();
            this.tasta1235 = new pianinaMini.tasta();
            this.tasta1236 = new pianinaMini.tasta();
            this.tasta1237 = new pianinaMini.tasta();
            this.tasta1238 = new pianinaMini.tasta();
            this.tasta1239 = new pianinaMini.tasta();
            this.tasta1240 = new pianinaMini.tasta();
            this.tasta1241 = new pianinaMini.tasta();
            this.tasta1242 = new pianinaMini.tasta();
            this.tasta1243 = new pianinaMini.tasta();
            this.tasta1244 = new pianinaMini.tasta();
            this.tasta1245 = new pianinaMini.tasta();
            this.tasta1246 = new pianinaMini.tasta();
            this.tasta1247 = new pianinaMini.tasta();
            this.tasta1248 = new pianinaMini.tasta();
            this.tasta1249 = new pianinaMini.tasta();
            this.tasta1250 = new pianinaMini.tasta();
            this.tasta1251 = new pianinaMini.tasta();
            this.tasta1252 = new pianinaMini.tasta();
            this.tasta1253 = new pianinaMini.tasta();
            this.tasta1254 = new pianinaMini.tasta();
            this.tasta1255 = new pianinaMini.tasta();
            this.tasta1256 = new pianinaMini.tasta();
            this.tasta1257 = new pianinaMini.tasta();
            this.tasta1258 = new pianinaMini.tasta();
            this.tasta1259 = new pianinaMini.tasta();
            this.tasta1260 = new pianinaMini.tasta();
            this.tasta1261 = new pianinaMini.tasta();
            this.tasta1262 = new pianinaMini.tasta();
            this.tasta1263 = new pianinaMini.tasta();
            this.tasta1264 = new pianinaMini.tasta();
            this.tasta1265 = new pianinaMini.tasta();
            this.tasta1266 = new pianinaMini.tasta();
            this.tasta1267 = new pianinaMini.tasta();
            this.tasta1268 = new pianinaMini.tasta();
            this.tasta1269 = new pianinaMini.tasta();
            this.tasta1270 = new pianinaMini.tasta();
            this.tasta1271 = new pianinaMini.tasta();
            this.tasta1272 = new pianinaMini.tasta();
            this.SuspendLayout();
            // 
            // tasta25
            // 
            this.tasta25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta25.Location = new System.Drawing.Point(897, 6);
            this.tasta25.Name = "tasta25";
            this.tasta25.Size = new System.Drawing.Size(13, 21);
            this.tasta25.TabIndex = 47;
            // 
            // tasta26
            // 
            this.tasta26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta26.Location = new System.Drawing.Point(878, 6);
            this.tasta26.Name = "tasta26";
            this.tasta26.Size = new System.Drawing.Size(13, 21);
            this.tasta26.TabIndex = 46;
            // 
            // tasta27
            // 
            this.tasta27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta27.Location = new System.Drawing.Point(859, 6);
            this.tasta27.Name = "tasta27";
            this.tasta27.Size = new System.Drawing.Size(13, 21);
            this.tasta27.TabIndex = 45;
            // 
            // tasta28
            // 
            this.tasta28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta28.Location = new System.Drawing.Point(840, 6);
            this.tasta28.Name = "tasta28";
            this.tasta28.Size = new System.Drawing.Size(13, 21);
            this.tasta28.TabIndex = 44;
            // 
            // tasta29
            // 
            this.tasta29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta29.Location = new System.Drawing.Point(821, 6);
            this.tasta29.Name = "tasta29";
            this.tasta29.Size = new System.Drawing.Size(13, 21);
            this.tasta29.TabIndex = 43;
            // 
            // tasta30
            // 
            this.tasta30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta30.Location = new System.Drawing.Point(802, 6);
            this.tasta30.Name = "tasta30";
            this.tasta30.Size = new System.Drawing.Size(13, 21);
            this.tasta30.TabIndex = 42;
            // 
            // tasta31
            // 
            this.tasta31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta31.Location = new System.Drawing.Point(783, 6);
            this.tasta31.Name = "tasta31";
            this.tasta31.Size = new System.Drawing.Size(13, 21);
            this.tasta31.TabIndex = 41;
            // 
            // tasta32
            // 
            this.tasta32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta32.Location = new System.Drawing.Point(764, 6);
            this.tasta32.Name = "tasta32";
            this.tasta32.Size = new System.Drawing.Size(13, 21);
            this.tasta32.TabIndex = 40;
            // 
            // tasta33
            // 
            this.tasta33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta33.Location = new System.Drawing.Point(745, 6);
            this.tasta33.Name = "tasta33";
            this.tasta33.Size = new System.Drawing.Size(13, 21);
            this.tasta33.TabIndex = 39;
            // 
            // tasta34
            // 
            this.tasta34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta34.Location = new System.Drawing.Point(726, 6);
            this.tasta34.Name = "tasta34";
            this.tasta34.Size = new System.Drawing.Size(13, 21);
            this.tasta34.TabIndex = 38;
            // 
            // tasta35
            // 
            this.tasta35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta35.Location = new System.Drawing.Point(707, 6);
            this.tasta35.Name = "tasta35";
            this.tasta35.Size = new System.Drawing.Size(13, 21);
            this.tasta35.TabIndex = 37;
            // 
            // tasta36
            // 
            this.tasta36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta36.Location = new System.Drawing.Point(688, 6);
            this.tasta36.Name = "tasta36";
            this.tasta36.Size = new System.Drawing.Size(13, 21);
            this.tasta36.TabIndex = 36;
            // 
            // tasta37
            // 
            this.tasta37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta37.Location = new System.Drawing.Point(669, 6);
            this.tasta37.Name = "tasta37";
            this.tasta37.Size = new System.Drawing.Size(13, 21);
            this.tasta37.TabIndex = 35;
            // 
            // tasta38
            // 
            this.tasta38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta38.Location = new System.Drawing.Point(650, 6);
            this.tasta38.Name = "tasta38";
            this.tasta38.Size = new System.Drawing.Size(13, 21);
            this.tasta38.TabIndex = 34;
            // 
            // tasta39
            // 
            this.tasta39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta39.Location = new System.Drawing.Point(631, 6);
            this.tasta39.Name = "tasta39";
            this.tasta39.Size = new System.Drawing.Size(13, 21);
            this.tasta39.TabIndex = 33;
            // 
            // tasta40
            // 
            this.tasta40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta40.Location = new System.Drawing.Point(612, 6);
            this.tasta40.Name = "tasta40";
            this.tasta40.Size = new System.Drawing.Size(13, 21);
            this.tasta40.TabIndex = 32;
            // 
            // tasta41
            // 
            this.tasta41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta41.Location = new System.Drawing.Point(593, 6);
            this.tasta41.Name = "tasta41";
            this.tasta41.Size = new System.Drawing.Size(13, 21);
            this.tasta41.TabIndex = 31;
            // 
            // tasta42
            // 
            this.tasta42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta42.Location = new System.Drawing.Point(574, 6);
            this.tasta42.Name = "tasta42";
            this.tasta42.Size = new System.Drawing.Size(13, 21);
            this.tasta42.TabIndex = 30;
            // 
            // tasta43
            // 
            this.tasta43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta43.Location = new System.Drawing.Point(555, 6);
            this.tasta43.Name = "tasta43";
            this.tasta43.Size = new System.Drawing.Size(13, 21);
            this.tasta43.TabIndex = 29;
            // 
            // tasta44
            // 
            this.tasta44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta44.Location = new System.Drawing.Point(536, 6);
            this.tasta44.Name = "tasta44";
            this.tasta44.Size = new System.Drawing.Size(13, 21);
            this.tasta44.TabIndex = 28;
            // 
            // tasta45
            // 
            this.tasta45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta45.Location = new System.Drawing.Point(517, 6);
            this.tasta45.Name = "tasta45";
            this.tasta45.Size = new System.Drawing.Size(13, 21);
            this.tasta45.TabIndex = 27;
            // 
            // tasta46
            // 
            this.tasta46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta46.Location = new System.Drawing.Point(498, 6);
            this.tasta46.Name = "tasta46";
            this.tasta46.Size = new System.Drawing.Size(13, 21);
            this.tasta46.TabIndex = 26;
            // 
            // tasta47
            // 
            this.tasta47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta47.Location = new System.Drawing.Point(479, 6);
            this.tasta47.Name = "tasta47";
            this.tasta47.Size = new System.Drawing.Size(13, 21);
            this.tasta47.TabIndex = 25;
            // 
            // tasta48
            // 
            this.tasta48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta48.Location = new System.Drawing.Point(460, 6);
            this.tasta48.Name = "tasta48";
            this.tasta48.Size = new System.Drawing.Size(13, 21);
            this.tasta48.TabIndex = 24;
            // 
            // tasta13
            // 
            this.tasta13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta13.Location = new System.Drawing.Point(441, 6);
            this.tasta13.Name = "tasta13";
            this.tasta13.Size = new System.Drawing.Size(13, 21);
            this.tasta13.TabIndex = 23;
            // 
            // tasta14
            // 
            this.tasta14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta14.Location = new System.Drawing.Point(422, 6);
            this.tasta14.Name = "tasta14";
            this.tasta14.Size = new System.Drawing.Size(13, 21);
            this.tasta14.TabIndex = 22;
            // 
            // tasta15
            // 
            this.tasta15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta15.Location = new System.Drawing.Point(403, 6);
            this.tasta15.Name = "tasta15";
            this.tasta15.Size = new System.Drawing.Size(13, 21);
            this.tasta15.TabIndex = 21;
            // 
            // tasta16
            // 
            this.tasta16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta16.Location = new System.Drawing.Point(384, 6);
            this.tasta16.Name = "tasta16";
            this.tasta16.Size = new System.Drawing.Size(13, 21);
            this.tasta16.TabIndex = 20;
            // 
            // tasta17
            // 
            this.tasta17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta17.Location = new System.Drawing.Point(365, 6);
            this.tasta17.Name = "tasta17";
            this.tasta17.Size = new System.Drawing.Size(13, 21);
            this.tasta17.TabIndex = 19;
            // 
            // tasta18
            // 
            this.tasta18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta18.Location = new System.Drawing.Point(346, 6);
            this.tasta18.Name = "tasta18";
            this.tasta18.Size = new System.Drawing.Size(13, 21);
            this.tasta18.TabIndex = 18;
            // 
            // tasta19
            // 
            this.tasta19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta19.Location = new System.Drawing.Point(327, 6);
            this.tasta19.Name = "tasta19";
            this.tasta19.Size = new System.Drawing.Size(13, 21);
            this.tasta19.TabIndex = 17;
            // 
            // tasta20
            // 
            this.tasta20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta20.Location = new System.Drawing.Point(308, 6);
            this.tasta20.Name = "tasta20";
            this.tasta20.Size = new System.Drawing.Size(13, 21);
            this.tasta20.TabIndex = 16;
            // 
            // tasta21
            // 
            this.tasta21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta21.Location = new System.Drawing.Point(289, 6);
            this.tasta21.Name = "tasta21";
            this.tasta21.Size = new System.Drawing.Size(13, 21);
            this.tasta21.TabIndex = 15;
            // 
            // tasta22
            // 
            this.tasta22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta22.Location = new System.Drawing.Point(270, 6);
            this.tasta22.Name = "tasta22";
            this.tasta22.Size = new System.Drawing.Size(13, 21);
            this.tasta22.TabIndex = 14;
            // 
            // tasta23
            // 
            this.tasta23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta23.Location = new System.Drawing.Point(251, 6);
            this.tasta23.Name = "tasta23";
            this.tasta23.Size = new System.Drawing.Size(13, 21);
            this.tasta23.TabIndex = 13;
            // 
            // tasta24
            // 
            this.tasta24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta24.Location = new System.Drawing.Point(232, 6);
            this.tasta24.Name = "tasta24";
            this.tasta24.Size = new System.Drawing.Size(13, 21);
            this.tasta24.TabIndex = 12;
            // 
            // tasta7
            // 
            this.tasta7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta7.Location = new System.Drawing.Point(213, 6);
            this.tasta7.Name = "tasta7";
            this.tasta7.Size = new System.Drawing.Size(13, 21);
            this.tasta7.TabIndex = 11;
            // 
            // tasta8
            // 
            this.tasta8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta8.Location = new System.Drawing.Point(194, 6);
            this.tasta8.Name = "tasta8";
            this.tasta8.Size = new System.Drawing.Size(13, 21);
            this.tasta8.TabIndex = 10;
            // 
            // tasta9
            // 
            this.tasta9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta9.Location = new System.Drawing.Point(175, 6);
            this.tasta9.Name = "tasta9";
            this.tasta9.Size = new System.Drawing.Size(13, 21);
            this.tasta9.TabIndex = 9;
            // 
            // tasta10
            // 
            this.tasta10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta10.Location = new System.Drawing.Point(156, 6);
            this.tasta10.Name = "tasta10";
            this.tasta10.Size = new System.Drawing.Size(13, 21);
            this.tasta10.TabIndex = 8;
            // 
            // tasta11
            // 
            this.tasta11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta11.Location = new System.Drawing.Point(137, 6);
            this.tasta11.Name = "tasta11";
            this.tasta11.Size = new System.Drawing.Size(13, 21);
            this.tasta11.TabIndex = 7;
            // 
            // tasta12
            // 
            this.tasta12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta12.Location = new System.Drawing.Point(118, 6);
            this.tasta12.Name = "tasta12";
            this.tasta12.Size = new System.Drawing.Size(13, 21);
            this.tasta12.TabIndex = 6;
            // 
            // tasta4
            // 
            this.tasta4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta4.Location = new System.Drawing.Point(99, 6);
            this.tasta4.Name = "tasta4";
            this.tasta4.Size = new System.Drawing.Size(13, 21);
            this.tasta4.TabIndex = 5;
            // 
            // tasta5
            // 
            this.tasta5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta5.Location = new System.Drawing.Point(80, 6);
            this.tasta5.Name = "tasta5";
            this.tasta5.Size = new System.Drawing.Size(13, 21);
            this.tasta5.TabIndex = 4;
            // 
            // tasta6
            // 
            this.tasta6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta6.Location = new System.Drawing.Point(61, 6);
            this.tasta6.Name = "tasta6";
            this.tasta6.Size = new System.Drawing.Size(13, 21);
            this.tasta6.TabIndex = 3;
            // 
            // tasta3
            // 
            this.tasta3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta3.Location = new System.Drawing.Point(42, 6);
            this.tasta3.Name = "tasta3";
            this.tasta3.Size = new System.Drawing.Size(13, 21);
            this.tasta3.TabIndex = 2;
            // 
            // tasta2
            // 
            this.tasta2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta2.Location = new System.Drawing.Point(23, 6);
            this.tasta2.Name = "tasta2";
            this.tasta2.Size = new System.Drawing.Size(13, 21);
            this.tasta2.TabIndex = 1;
            // 
            // tasta1
            // 
            this.tasta1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1.Location = new System.Drawing.Point(4, 6);
            this.tasta1.Name = "tasta1";
            this.tasta1.Size = new System.Drawing.Size(13, 21);
            this.tasta1.TabIndex = 0;
            // 
            // tasta49
            // 
            this.tasta49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta49.Location = new System.Drawing.Point(993, 6);
            this.tasta49.Name = "tasta49";
            this.tasta49.Size = new System.Drawing.Size(13, 21);
            this.tasta49.TabIndex = 52;
            // 
            // tasta50
            // 
            this.tasta50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta50.Location = new System.Drawing.Point(974, 6);
            this.tasta50.Name = "tasta50";
            this.tasta50.Size = new System.Drawing.Size(13, 21);
            this.tasta50.TabIndex = 51;
            // 
            // tasta51
            // 
            this.tasta51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta51.Location = new System.Drawing.Point(955, 6);
            this.tasta51.Name = "tasta51";
            this.tasta51.Size = new System.Drawing.Size(13, 21);
            this.tasta51.TabIndex = 50;
            // 
            // tasta52
            // 
            this.tasta52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta52.Location = new System.Drawing.Point(936, 6);
            this.tasta52.Name = "tasta52";
            this.tasta52.Size = new System.Drawing.Size(13, 21);
            this.tasta52.TabIndex = 49;
            // 
            // tasta53
            // 
            this.tasta53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta53.Location = new System.Drawing.Point(917, 6);
            this.tasta53.Name = "tasta53";
            this.tasta53.Size = new System.Drawing.Size(13, 21);
            this.tasta53.TabIndex = 48;
            // 
            // tasta54
            // 
            this.tasta54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta54.Location = new System.Drawing.Point(993, 33);
            this.tasta54.Name = "tasta54";
            this.tasta54.Size = new System.Drawing.Size(13, 21);
            this.tasta54.TabIndex = 105;
            // 
            // tasta55
            // 
            this.tasta55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta55.Location = new System.Drawing.Point(974, 33);
            this.tasta55.Name = "tasta55";
            this.tasta55.Size = new System.Drawing.Size(13, 21);
            this.tasta55.TabIndex = 104;
            // 
            // tasta56
            // 
            this.tasta56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta56.Location = new System.Drawing.Point(955, 33);
            this.tasta56.Name = "tasta56";
            this.tasta56.Size = new System.Drawing.Size(13, 21);
            this.tasta56.TabIndex = 103;
            // 
            // tasta57
            // 
            this.tasta57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta57.Location = new System.Drawing.Point(936, 33);
            this.tasta57.Name = "tasta57";
            this.tasta57.Size = new System.Drawing.Size(13, 21);
            this.tasta57.TabIndex = 102;
            // 
            // tasta58
            // 
            this.tasta58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta58.Location = new System.Drawing.Point(917, 33);
            this.tasta58.Name = "tasta58";
            this.tasta58.Size = new System.Drawing.Size(13, 21);
            this.tasta58.TabIndex = 101;
            // 
            // tasta59
            // 
            this.tasta59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta59.Location = new System.Drawing.Point(897, 33);
            this.tasta59.Name = "tasta59";
            this.tasta59.Size = new System.Drawing.Size(13, 21);
            this.tasta59.TabIndex = 100;
            // 
            // tasta60
            // 
            this.tasta60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta60.Location = new System.Drawing.Point(878, 33);
            this.tasta60.Name = "tasta60";
            this.tasta60.Size = new System.Drawing.Size(13, 21);
            this.tasta60.TabIndex = 99;
            // 
            // tasta61
            // 
            this.tasta61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta61.Location = new System.Drawing.Point(859, 33);
            this.tasta61.Name = "tasta61";
            this.tasta61.Size = new System.Drawing.Size(13, 21);
            this.tasta61.TabIndex = 98;
            // 
            // tasta62
            // 
            this.tasta62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta62.Location = new System.Drawing.Point(840, 33);
            this.tasta62.Name = "tasta62";
            this.tasta62.Size = new System.Drawing.Size(13, 21);
            this.tasta62.TabIndex = 97;
            // 
            // tasta63
            // 
            this.tasta63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta63.Location = new System.Drawing.Point(821, 33);
            this.tasta63.Name = "tasta63";
            this.tasta63.Size = new System.Drawing.Size(13, 21);
            this.tasta63.TabIndex = 96;
            // 
            // tasta64
            // 
            this.tasta64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta64.Location = new System.Drawing.Point(802, 33);
            this.tasta64.Name = "tasta64";
            this.tasta64.Size = new System.Drawing.Size(13, 21);
            this.tasta64.TabIndex = 95;
            // 
            // tasta65
            // 
            this.tasta65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta65.Location = new System.Drawing.Point(783, 33);
            this.tasta65.Name = "tasta65";
            this.tasta65.Size = new System.Drawing.Size(13, 21);
            this.tasta65.TabIndex = 94;
            // 
            // tasta66
            // 
            this.tasta66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta66.Location = new System.Drawing.Point(764, 33);
            this.tasta66.Name = "tasta66";
            this.tasta66.Size = new System.Drawing.Size(13, 21);
            this.tasta66.TabIndex = 93;
            // 
            // tasta67
            // 
            this.tasta67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta67.Location = new System.Drawing.Point(745, 33);
            this.tasta67.Name = "tasta67";
            this.tasta67.Size = new System.Drawing.Size(13, 21);
            this.tasta67.TabIndex = 92;
            // 
            // tasta68
            // 
            this.tasta68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta68.Location = new System.Drawing.Point(726, 33);
            this.tasta68.Name = "tasta68";
            this.tasta68.Size = new System.Drawing.Size(13, 21);
            this.tasta68.TabIndex = 91;
            // 
            // tasta69
            // 
            this.tasta69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta69.Location = new System.Drawing.Point(707, 33);
            this.tasta69.Name = "tasta69";
            this.tasta69.Size = new System.Drawing.Size(13, 21);
            this.tasta69.TabIndex = 90;
            // 
            // tasta70
            // 
            this.tasta70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta70.Location = new System.Drawing.Point(688, 33);
            this.tasta70.Name = "tasta70";
            this.tasta70.Size = new System.Drawing.Size(13, 21);
            this.tasta70.TabIndex = 89;
            // 
            // tasta71
            // 
            this.tasta71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta71.Location = new System.Drawing.Point(669, 33);
            this.tasta71.Name = "tasta71";
            this.tasta71.Size = new System.Drawing.Size(13, 21);
            this.tasta71.TabIndex = 88;
            // 
            // tasta72
            // 
            this.tasta72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta72.Location = new System.Drawing.Point(650, 33);
            this.tasta72.Name = "tasta72";
            this.tasta72.Size = new System.Drawing.Size(13, 21);
            this.tasta72.TabIndex = 87;
            // 
            // tasta73
            // 
            this.tasta73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta73.Location = new System.Drawing.Point(631, 33);
            this.tasta73.Name = "tasta73";
            this.tasta73.Size = new System.Drawing.Size(13, 21);
            this.tasta73.TabIndex = 86;
            // 
            // tasta74
            // 
            this.tasta74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta74.Location = new System.Drawing.Point(612, 33);
            this.tasta74.Name = "tasta74";
            this.tasta74.Size = new System.Drawing.Size(13, 21);
            this.tasta74.TabIndex = 85;
            // 
            // tasta75
            // 
            this.tasta75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta75.Location = new System.Drawing.Point(593, 33);
            this.tasta75.Name = "tasta75";
            this.tasta75.Size = new System.Drawing.Size(13, 21);
            this.tasta75.TabIndex = 84;
            // 
            // tasta76
            // 
            this.tasta76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta76.Location = new System.Drawing.Point(574, 33);
            this.tasta76.Name = "tasta76";
            this.tasta76.Size = new System.Drawing.Size(13, 21);
            this.tasta76.TabIndex = 83;
            // 
            // tasta77
            // 
            this.tasta77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta77.Location = new System.Drawing.Point(555, 33);
            this.tasta77.Name = "tasta77";
            this.tasta77.Size = new System.Drawing.Size(13, 21);
            this.tasta77.TabIndex = 82;
            // 
            // tasta78
            // 
            this.tasta78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta78.Location = new System.Drawing.Point(536, 33);
            this.tasta78.Name = "tasta78";
            this.tasta78.Size = new System.Drawing.Size(13, 21);
            this.tasta78.TabIndex = 81;
            // 
            // tasta79
            // 
            this.tasta79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta79.Location = new System.Drawing.Point(517, 33);
            this.tasta79.Name = "tasta79";
            this.tasta79.Size = new System.Drawing.Size(13, 21);
            this.tasta79.TabIndex = 80;
            // 
            // tasta80
            // 
            this.tasta80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta80.Location = new System.Drawing.Point(498, 33);
            this.tasta80.Name = "tasta80";
            this.tasta80.Size = new System.Drawing.Size(13, 21);
            this.tasta80.TabIndex = 79;
            // 
            // tasta81
            // 
            this.tasta81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta81.Location = new System.Drawing.Point(479, 33);
            this.tasta81.Name = "tasta81";
            this.tasta81.Size = new System.Drawing.Size(13, 21);
            this.tasta81.TabIndex = 78;
            // 
            // tasta82
            // 
            this.tasta82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta82.Location = new System.Drawing.Point(460, 33);
            this.tasta82.Name = "tasta82";
            this.tasta82.Size = new System.Drawing.Size(13, 21);
            this.tasta82.TabIndex = 77;
            // 
            // tasta83
            // 
            this.tasta83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta83.Location = new System.Drawing.Point(441, 33);
            this.tasta83.Name = "tasta83";
            this.tasta83.Size = new System.Drawing.Size(13, 21);
            this.tasta83.TabIndex = 76;
            // 
            // tasta84
            // 
            this.tasta84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta84.Location = new System.Drawing.Point(422, 33);
            this.tasta84.Name = "tasta84";
            this.tasta84.Size = new System.Drawing.Size(13, 21);
            this.tasta84.TabIndex = 75;
            // 
            // tasta85
            // 
            this.tasta85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta85.Location = new System.Drawing.Point(403, 33);
            this.tasta85.Name = "tasta85";
            this.tasta85.Size = new System.Drawing.Size(13, 21);
            this.tasta85.TabIndex = 74;
            // 
            // tasta86
            // 
            this.tasta86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta86.Location = new System.Drawing.Point(384, 33);
            this.tasta86.Name = "tasta86";
            this.tasta86.Size = new System.Drawing.Size(13, 21);
            this.tasta86.TabIndex = 73;
            // 
            // tasta87
            // 
            this.tasta87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta87.Location = new System.Drawing.Point(365, 33);
            this.tasta87.Name = "tasta87";
            this.tasta87.Size = new System.Drawing.Size(13, 21);
            this.tasta87.TabIndex = 72;
            // 
            // tasta88
            // 
            this.tasta88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta88.Location = new System.Drawing.Point(346, 33);
            this.tasta88.Name = "tasta88";
            this.tasta88.Size = new System.Drawing.Size(13, 21);
            this.tasta88.TabIndex = 71;
            // 
            // tasta89
            // 
            this.tasta89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta89.Location = new System.Drawing.Point(327, 33);
            this.tasta89.Name = "tasta89";
            this.tasta89.Size = new System.Drawing.Size(13, 21);
            this.tasta89.TabIndex = 70;
            // 
            // tasta90
            // 
            this.tasta90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta90.Location = new System.Drawing.Point(308, 33);
            this.tasta90.Name = "tasta90";
            this.tasta90.Size = new System.Drawing.Size(13, 21);
            this.tasta90.TabIndex = 69;
            // 
            // tasta91
            // 
            this.tasta91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta91.Location = new System.Drawing.Point(289, 33);
            this.tasta91.Name = "tasta91";
            this.tasta91.Size = new System.Drawing.Size(13, 21);
            this.tasta91.TabIndex = 68;
            // 
            // tasta92
            // 
            this.tasta92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta92.Location = new System.Drawing.Point(270, 33);
            this.tasta92.Name = "tasta92";
            this.tasta92.Size = new System.Drawing.Size(13, 21);
            this.tasta92.TabIndex = 67;
            // 
            // tasta93
            // 
            this.tasta93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta93.Location = new System.Drawing.Point(251, 33);
            this.tasta93.Name = "tasta93";
            this.tasta93.Size = new System.Drawing.Size(13, 21);
            this.tasta93.TabIndex = 66;
            // 
            // tasta94
            // 
            this.tasta94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta94.Location = new System.Drawing.Point(232, 33);
            this.tasta94.Name = "tasta94";
            this.tasta94.Size = new System.Drawing.Size(13, 21);
            this.tasta94.TabIndex = 65;
            // 
            // tasta95
            // 
            this.tasta95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta95.Location = new System.Drawing.Point(213, 33);
            this.tasta95.Name = "tasta95";
            this.tasta95.Size = new System.Drawing.Size(13, 21);
            this.tasta95.TabIndex = 64;
            // 
            // tasta96
            // 
            this.tasta96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta96.Location = new System.Drawing.Point(194, 33);
            this.tasta96.Name = "tasta96";
            this.tasta96.Size = new System.Drawing.Size(13, 21);
            this.tasta96.TabIndex = 63;
            // 
            // tasta97
            // 
            this.tasta97.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta97.Location = new System.Drawing.Point(175, 33);
            this.tasta97.Name = "tasta97";
            this.tasta97.Size = new System.Drawing.Size(13, 21);
            this.tasta97.TabIndex = 62;
            // 
            // tasta98
            // 
            this.tasta98.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta98.Location = new System.Drawing.Point(156, 33);
            this.tasta98.Name = "tasta98";
            this.tasta98.Size = new System.Drawing.Size(13, 21);
            this.tasta98.TabIndex = 61;
            // 
            // tasta99
            // 
            this.tasta99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta99.Location = new System.Drawing.Point(137, 33);
            this.tasta99.Name = "tasta99";
            this.tasta99.Size = new System.Drawing.Size(13, 21);
            this.tasta99.TabIndex = 60;
            // 
            // tasta100
            // 
            this.tasta100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta100.Location = new System.Drawing.Point(118, 33);
            this.tasta100.Name = "tasta100";
            this.tasta100.Size = new System.Drawing.Size(13, 21);
            this.tasta100.TabIndex = 59;
            // 
            // tasta101
            // 
            this.tasta101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta101.Location = new System.Drawing.Point(99, 33);
            this.tasta101.Name = "tasta101";
            this.tasta101.Size = new System.Drawing.Size(13, 21);
            this.tasta101.TabIndex = 58;
            // 
            // tasta102
            // 
            this.tasta102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta102.Location = new System.Drawing.Point(80, 33);
            this.tasta102.Name = "tasta102";
            this.tasta102.Size = new System.Drawing.Size(13, 21);
            this.tasta102.TabIndex = 57;
            // 
            // tasta103
            // 
            this.tasta103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta103.Location = new System.Drawing.Point(61, 33);
            this.tasta103.Name = "tasta103";
            this.tasta103.Size = new System.Drawing.Size(13, 21);
            this.tasta103.TabIndex = 56;
            // 
            // tasta104
            // 
            this.tasta104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta104.Location = new System.Drawing.Point(42, 33);
            this.tasta104.Name = "tasta104";
            this.tasta104.Size = new System.Drawing.Size(13, 21);
            this.tasta104.TabIndex = 55;
            // 
            // tasta105
            // 
            this.tasta105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta105.Location = new System.Drawing.Point(23, 33);
            this.tasta105.Name = "tasta105";
            this.tasta105.Size = new System.Drawing.Size(13, 21);
            this.tasta105.TabIndex = 54;
            // 
            // tasta106
            // 
            this.tasta106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta106.Location = new System.Drawing.Point(4, 33);
            this.tasta106.Name = "tasta106";
            this.tasta106.Size = new System.Drawing.Size(13, 21);
            this.tasta106.TabIndex = 53;
            // 
            // tasta107
            // 
            this.tasta107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta107.Location = new System.Drawing.Point(993, 87);
            this.tasta107.Name = "tasta107";
            this.tasta107.Size = new System.Drawing.Size(13, 21);
            this.tasta107.TabIndex = 211;
            // 
            // tasta108
            // 
            this.tasta108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta108.Location = new System.Drawing.Point(974, 87);
            this.tasta108.Name = "tasta108";
            this.tasta108.Size = new System.Drawing.Size(13, 21);
            this.tasta108.TabIndex = 210;
            // 
            // tasta109
            // 
            this.tasta109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta109.Location = new System.Drawing.Point(955, 87);
            this.tasta109.Name = "tasta109";
            this.tasta109.Size = new System.Drawing.Size(13, 21);
            this.tasta109.TabIndex = 209;
            // 
            // tasta110
            // 
            this.tasta110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta110.Location = new System.Drawing.Point(936, 87);
            this.tasta110.Name = "tasta110";
            this.tasta110.Size = new System.Drawing.Size(13, 21);
            this.tasta110.TabIndex = 208;
            // 
            // tasta111
            // 
            this.tasta111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta111.Location = new System.Drawing.Point(917, 87);
            this.tasta111.Name = "tasta111";
            this.tasta111.Size = new System.Drawing.Size(13, 21);
            this.tasta111.TabIndex = 207;
            // 
            // tasta112
            // 
            this.tasta112.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta112.Location = new System.Drawing.Point(897, 87);
            this.tasta112.Name = "tasta112";
            this.tasta112.Size = new System.Drawing.Size(13, 21);
            this.tasta112.TabIndex = 206;
            // 
            // tasta113
            // 
            this.tasta113.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta113.Location = new System.Drawing.Point(878, 87);
            this.tasta113.Name = "tasta113";
            this.tasta113.Size = new System.Drawing.Size(13, 21);
            this.tasta113.TabIndex = 205;
            // 
            // tasta114
            // 
            this.tasta114.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta114.Location = new System.Drawing.Point(859, 87);
            this.tasta114.Name = "tasta114";
            this.tasta114.Size = new System.Drawing.Size(13, 21);
            this.tasta114.TabIndex = 204;
            // 
            // tasta115
            // 
            this.tasta115.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta115.Location = new System.Drawing.Point(840, 87);
            this.tasta115.Name = "tasta115";
            this.tasta115.Size = new System.Drawing.Size(13, 21);
            this.tasta115.TabIndex = 203;
            // 
            // tasta116
            // 
            this.tasta116.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta116.Location = new System.Drawing.Point(821, 87);
            this.tasta116.Name = "tasta116";
            this.tasta116.Size = new System.Drawing.Size(13, 21);
            this.tasta116.TabIndex = 202;
            // 
            // tasta117
            // 
            this.tasta117.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta117.Location = new System.Drawing.Point(802, 87);
            this.tasta117.Name = "tasta117";
            this.tasta117.Size = new System.Drawing.Size(13, 21);
            this.tasta117.TabIndex = 201;
            // 
            // tasta118
            // 
            this.tasta118.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta118.Location = new System.Drawing.Point(783, 87);
            this.tasta118.Name = "tasta118";
            this.tasta118.Size = new System.Drawing.Size(13, 21);
            this.tasta118.TabIndex = 200;
            // 
            // tasta119
            // 
            this.tasta119.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta119.Location = new System.Drawing.Point(764, 87);
            this.tasta119.Name = "tasta119";
            this.tasta119.Size = new System.Drawing.Size(13, 21);
            this.tasta119.TabIndex = 199;
            // 
            // tasta120
            // 
            this.tasta120.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta120.Location = new System.Drawing.Point(745, 87);
            this.tasta120.Name = "tasta120";
            this.tasta120.Size = new System.Drawing.Size(13, 21);
            this.tasta120.TabIndex = 198;
            // 
            // tasta121
            // 
            this.tasta121.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta121.Location = new System.Drawing.Point(726, 87);
            this.tasta121.Name = "tasta121";
            this.tasta121.Size = new System.Drawing.Size(13, 21);
            this.tasta121.TabIndex = 197;
            // 
            // tasta122
            // 
            this.tasta122.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta122.Location = new System.Drawing.Point(707, 87);
            this.tasta122.Name = "tasta122";
            this.tasta122.Size = new System.Drawing.Size(13, 21);
            this.tasta122.TabIndex = 196;
            // 
            // tasta123
            // 
            this.tasta123.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta123.Location = new System.Drawing.Point(688, 87);
            this.tasta123.Name = "tasta123";
            this.tasta123.Size = new System.Drawing.Size(13, 21);
            this.tasta123.TabIndex = 195;
            // 
            // tasta124
            // 
            this.tasta124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta124.Location = new System.Drawing.Point(669, 87);
            this.tasta124.Name = "tasta124";
            this.tasta124.Size = new System.Drawing.Size(13, 21);
            this.tasta124.TabIndex = 194;
            // 
            // tasta125
            // 
            this.tasta125.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta125.Location = new System.Drawing.Point(650, 87);
            this.tasta125.Name = "tasta125";
            this.tasta125.Size = new System.Drawing.Size(13, 21);
            this.tasta125.TabIndex = 193;
            // 
            // tasta126
            // 
            this.tasta126.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta126.Location = new System.Drawing.Point(631, 87);
            this.tasta126.Name = "tasta126";
            this.tasta126.Size = new System.Drawing.Size(13, 21);
            this.tasta126.TabIndex = 192;
            // 
            // tasta127
            // 
            this.tasta127.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta127.Location = new System.Drawing.Point(612, 87);
            this.tasta127.Name = "tasta127";
            this.tasta127.Size = new System.Drawing.Size(13, 21);
            this.tasta127.TabIndex = 191;
            // 
            // tasta128
            // 
            this.tasta128.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta128.Location = new System.Drawing.Point(593, 87);
            this.tasta128.Name = "tasta128";
            this.tasta128.Size = new System.Drawing.Size(13, 21);
            this.tasta128.TabIndex = 190;
            // 
            // tasta129
            // 
            this.tasta129.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta129.Location = new System.Drawing.Point(574, 87);
            this.tasta129.Name = "tasta129";
            this.tasta129.Size = new System.Drawing.Size(13, 21);
            this.tasta129.TabIndex = 189;
            // 
            // tasta130
            // 
            this.tasta130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta130.Location = new System.Drawing.Point(555, 87);
            this.tasta130.Name = "tasta130";
            this.tasta130.Size = new System.Drawing.Size(13, 21);
            this.tasta130.TabIndex = 188;
            // 
            // tasta131
            // 
            this.tasta131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta131.Location = new System.Drawing.Point(536, 87);
            this.tasta131.Name = "tasta131";
            this.tasta131.Size = new System.Drawing.Size(13, 21);
            this.tasta131.TabIndex = 187;
            // 
            // tasta132
            // 
            this.tasta132.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta132.Location = new System.Drawing.Point(517, 87);
            this.tasta132.Name = "tasta132";
            this.tasta132.Size = new System.Drawing.Size(13, 21);
            this.tasta132.TabIndex = 186;
            // 
            // tasta133
            // 
            this.tasta133.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta133.Location = new System.Drawing.Point(498, 87);
            this.tasta133.Name = "tasta133";
            this.tasta133.Size = new System.Drawing.Size(13, 21);
            this.tasta133.TabIndex = 185;
            // 
            // tasta134
            // 
            this.tasta134.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta134.Location = new System.Drawing.Point(479, 87);
            this.tasta134.Name = "tasta134";
            this.tasta134.Size = new System.Drawing.Size(13, 21);
            this.tasta134.TabIndex = 184;
            // 
            // tasta135
            // 
            this.tasta135.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta135.Location = new System.Drawing.Point(460, 87);
            this.tasta135.Name = "tasta135";
            this.tasta135.Size = new System.Drawing.Size(13, 21);
            this.tasta135.TabIndex = 183;
            // 
            // tasta136
            // 
            this.tasta136.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta136.Location = new System.Drawing.Point(441, 87);
            this.tasta136.Name = "tasta136";
            this.tasta136.Size = new System.Drawing.Size(13, 21);
            this.tasta136.TabIndex = 182;
            // 
            // tasta137
            // 
            this.tasta137.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta137.Location = new System.Drawing.Point(422, 87);
            this.tasta137.Name = "tasta137";
            this.tasta137.Size = new System.Drawing.Size(13, 21);
            this.tasta137.TabIndex = 181;
            // 
            // tasta138
            // 
            this.tasta138.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta138.Location = new System.Drawing.Point(403, 87);
            this.tasta138.Name = "tasta138";
            this.tasta138.Size = new System.Drawing.Size(13, 21);
            this.tasta138.TabIndex = 180;
            // 
            // tasta139
            // 
            this.tasta139.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta139.Location = new System.Drawing.Point(384, 87);
            this.tasta139.Name = "tasta139";
            this.tasta139.Size = new System.Drawing.Size(13, 21);
            this.tasta139.TabIndex = 179;
            // 
            // tasta140
            // 
            this.tasta140.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta140.Location = new System.Drawing.Point(365, 87);
            this.tasta140.Name = "tasta140";
            this.tasta140.Size = new System.Drawing.Size(13, 21);
            this.tasta140.TabIndex = 178;
            // 
            // tasta141
            // 
            this.tasta141.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta141.Location = new System.Drawing.Point(346, 87);
            this.tasta141.Name = "tasta141";
            this.tasta141.Size = new System.Drawing.Size(13, 21);
            this.tasta141.TabIndex = 177;
            // 
            // tasta142
            // 
            this.tasta142.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta142.Location = new System.Drawing.Point(327, 87);
            this.tasta142.Name = "tasta142";
            this.tasta142.Size = new System.Drawing.Size(13, 21);
            this.tasta142.TabIndex = 176;
            // 
            // tasta143
            // 
            this.tasta143.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta143.Location = new System.Drawing.Point(308, 87);
            this.tasta143.Name = "tasta143";
            this.tasta143.Size = new System.Drawing.Size(13, 21);
            this.tasta143.TabIndex = 175;
            // 
            // tasta144
            // 
            this.tasta144.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta144.Location = new System.Drawing.Point(289, 87);
            this.tasta144.Name = "tasta144";
            this.tasta144.Size = new System.Drawing.Size(13, 21);
            this.tasta144.TabIndex = 174;
            // 
            // tasta145
            // 
            this.tasta145.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta145.Location = new System.Drawing.Point(270, 87);
            this.tasta145.Name = "tasta145";
            this.tasta145.Size = new System.Drawing.Size(13, 21);
            this.tasta145.TabIndex = 173;
            // 
            // tasta146
            // 
            this.tasta146.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta146.Location = new System.Drawing.Point(251, 87);
            this.tasta146.Name = "tasta146";
            this.tasta146.Size = new System.Drawing.Size(13, 21);
            this.tasta146.TabIndex = 172;
            // 
            // tasta147
            // 
            this.tasta147.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta147.Location = new System.Drawing.Point(232, 87);
            this.tasta147.Name = "tasta147";
            this.tasta147.Size = new System.Drawing.Size(13, 21);
            this.tasta147.TabIndex = 171;
            // 
            // tasta148
            // 
            this.tasta148.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta148.Location = new System.Drawing.Point(213, 87);
            this.tasta148.Name = "tasta148";
            this.tasta148.Size = new System.Drawing.Size(13, 21);
            this.tasta148.TabIndex = 170;
            // 
            // tasta149
            // 
            this.tasta149.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta149.Location = new System.Drawing.Point(194, 87);
            this.tasta149.Name = "tasta149";
            this.tasta149.Size = new System.Drawing.Size(13, 21);
            this.tasta149.TabIndex = 169;
            // 
            // tasta150
            // 
            this.tasta150.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta150.Location = new System.Drawing.Point(175, 87);
            this.tasta150.Name = "tasta150";
            this.tasta150.Size = new System.Drawing.Size(13, 21);
            this.tasta150.TabIndex = 168;
            // 
            // tasta151
            // 
            this.tasta151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta151.Location = new System.Drawing.Point(156, 87);
            this.tasta151.Name = "tasta151";
            this.tasta151.Size = new System.Drawing.Size(13, 21);
            this.tasta151.TabIndex = 167;
            // 
            // tasta152
            // 
            this.tasta152.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta152.Location = new System.Drawing.Point(137, 87);
            this.tasta152.Name = "tasta152";
            this.tasta152.Size = new System.Drawing.Size(13, 21);
            this.tasta152.TabIndex = 166;
            // 
            // tasta153
            // 
            this.tasta153.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta153.Location = new System.Drawing.Point(118, 87);
            this.tasta153.Name = "tasta153";
            this.tasta153.Size = new System.Drawing.Size(13, 21);
            this.tasta153.TabIndex = 165;
            // 
            // tasta154
            // 
            this.tasta154.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta154.Location = new System.Drawing.Point(99, 87);
            this.tasta154.Name = "tasta154";
            this.tasta154.Size = new System.Drawing.Size(13, 21);
            this.tasta154.TabIndex = 164;
            // 
            // tasta155
            // 
            this.tasta155.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta155.Location = new System.Drawing.Point(80, 87);
            this.tasta155.Name = "tasta155";
            this.tasta155.Size = new System.Drawing.Size(13, 21);
            this.tasta155.TabIndex = 163;
            // 
            // tasta156
            // 
            this.tasta156.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta156.Location = new System.Drawing.Point(61, 87);
            this.tasta156.Name = "tasta156";
            this.tasta156.Size = new System.Drawing.Size(13, 21);
            this.tasta156.TabIndex = 162;
            // 
            // tasta157
            // 
            this.tasta157.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta157.Location = new System.Drawing.Point(42, 87);
            this.tasta157.Name = "tasta157";
            this.tasta157.Size = new System.Drawing.Size(13, 21);
            this.tasta157.TabIndex = 161;
            // 
            // tasta158
            // 
            this.tasta158.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta158.Location = new System.Drawing.Point(23, 87);
            this.tasta158.Name = "tasta158";
            this.tasta158.Size = new System.Drawing.Size(13, 21);
            this.tasta158.TabIndex = 160;
            // 
            // tasta159
            // 
            this.tasta159.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta159.Location = new System.Drawing.Point(4, 87);
            this.tasta159.Name = "tasta159";
            this.tasta159.Size = new System.Drawing.Size(13, 21);
            this.tasta159.TabIndex = 159;
            // 
            // tasta160
            // 
            this.tasta160.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta160.Location = new System.Drawing.Point(993, 60);
            this.tasta160.Name = "tasta160";
            this.tasta160.Size = new System.Drawing.Size(13, 21);
            this.tasta160.TabIndex = 158;
            // 
            // tasta161
            // 
            this.tasta161.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta161.Location = new System.Drawing.Point(974, 60);
            this.tasta161.Name = "tasta161";
            this.tasta161.Size = new System.Drawing.Size(13, 21);
            this.tasta161.TabIndex = 157;
            // 
            // tasta162
            // 
            this.tasta162.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta162.Location = new System.Drawing.Point(955, 60);
            this.tasta162.Name = "tasta162";
            this.tasta162.Size = new System.Drawing.Size(13, 21);
            this.tasta162.TabIndex = 156;
            // 
            // tasta163
            // 
            this.tasta163.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta163.Location = new System.Drawing.Point(936, 60);
            this.tasta163.Name = "tasta163";
            this.tasta163.Size = new System.Drawing.Size(13, 21);
            this.tasta163.TabIndex = 155;
            // 
            // tasta164
            // 
            this.tasta164.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta164.Location = new System.Drawing.Point(917, 60);
            this.tasta164.Name = "tasta164";
            this.tasta164.Size = new System.Drawing.Size(13, 21);
            this.tasta164.TabIndex = 154;
            // 
            // tasta165
            // 
            this.tasta165.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta165.Location = new System.Drawing.Point(897, 60);
            this.tasta165.Name = "tasta165";
            this.tasta165.Size = new System.Drawing.Size(13, 21);
            this.tasta165.TabIndex = 153;
            // 
            // tasta166
            // 
            this.tasta166.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta166.Location = new System.Drawing.Point(878, 60);
            this.tasta166.Name = "tasta166";
            this.tasta166.Size = new System.Drawing.Size(13, 21);
            this.tasta166.TabIndex = 152;
            // 
            // tasta167
            // 
            this.tasta167.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta167.Location = new System.Drawing.Point(859, 60);
            this.tasta167.Name = "tasta167";
            this.tasta167.Size = new System.Drawing.Size(13, 21);
            this.tasta167.TabIndex = 151;
            // 
            // tasta168
            // 
            this.tasta168.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta168.Location = new System.Drawing.Point(840, 60);
            this.tasta168.Name = "tasta168";
            this.tasta168.Size = new System.Drawing.Size(13, 21);
            this.tasta168.TabIndex = 150;
            // 
            // tasta169
            // 
            this.tasta169.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta169.Location = new System.Drawing.Point(821, 60);
            this.tasta169.Name = "tasta169";
            this.tasta169.Size = new System.Drawing.Size(13, 21);
            this.tasta169.TabIndex = 149;
            // 
            // tasta170
            // 
            this.tasta170.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta170.Location = new System.Drawing.Point(802, 60);
            this.tasta170.Name = "tasta170";
            this.tasta170.Size = new System.Drawing.Size(13, 21);
            this.tasta170.TabIndex = 148;
            // 
            // tasta171
            // 
            this.tasta171.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta171.Location = new System.Drawing.Point(783, 60);
            this.tasta171.Name = "tasta171";
            this.tasta171.Size = new System.Drawing.Size(13, 21);
            this.tasta171.TabIndex = 147;
            // 
            // tasta172
            // 
            this.tasta172.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta172.Location = new System.Drawing.Point(764, 60);
            this.tasta172.Name = "tasta172";
            this.tasta172.Size = new System.Drawing.Size(13, 21);
            this.tasta172.TabIndex = 146;
            // 
            // tasta173
            // 
            this.tasta173.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta173.Location = new System.Drawing.Point(745, 60);
            this.tasta173.Name = "tasta173";
            this.tasta173.Size = new System.Drawing.Size(13, 21);
            this.tasta173.TabIndex = 145;
            // 
            // tasta174
            // 
            this.tasta174.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta174.Location = new System.Drawing.Point(726, 60);
            this.tasta174.Name = "tasta174";
            this.tasta174.Size = new System.Drawing.Size(13, 21);
            this.tasta174.TabIndex = 144;
            // 
            // tasta175
            // 
            this.tasta175.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta175.Location = new System.Drawing.Point(707, 60);
            this.tasta175.Name = "tasta175";
            this.tasta175.Size = new System.Drawing.Size(13, 21);
            this.tasta175.TabIndex = 143;
            // 
            // tasta176
            // 
            this.tasta176.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta176.Location = new System.Drawing.Point(688, 60);
            this.tasta176.Name = "tasta176";
            this.tasta176.Size = new System.Drawing.Size(13, 21);
            this.tasta176.TabIndex = 142;
            // 
            // tasta177
            // 
            this.tasta177.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta177.Location = new System.Drawing.Point(669, 60);
            this.tasta177.Name = "tasta177";
            this.tasta177.Size = new System.Drawing.Size(13, 21);
            this.tasta177.TabIndex = 141;
            // 
            // tasta178
            // 
            this.tasta178.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta178.Location = new System.Drawing.Point(650, 60);
            this.tasta178.Name = "tasta178";
            this.tasta178.Size = new System.Drawing.Size(13, 21);
            this.tasta178.TabIndex = 140;
            // 
            // tasta179
            // 
            this.tasta179.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta179.Location = new System.Drawing.Point(631, 60);
            this.tasta179.Name = "tasta179";
            this.tasta179.Size = new System.Drawing.Size(13, 21);
            this.tasta179.TabIndex = 139;
            // 
            // tasta180
            // 
            this.tasta180.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta180.Location = new System.Drawing.Point(612, 60);
            this.tasta180.Name = "tasta180";
            this.tasta180.Size = new System.Drawing.Size(13, 21);
            this.tasta180.TabIndex = 138;
            // 
            // tasta181
            // 
            this.tasta181.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta181.Location = new System.Drawing.Point(593, 60);
            this.tasta181.Name = "tasta181";
            this.tasta181.Size = new System.Drawing.Size(13, 21);
            this.tasta181.TabIndex = 137;
            // 
            // tasta182
            // 
            this.tasta182.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta182.Location = new System.Drawing.Point(574, 60);
            this.tasta182.Name = "tasta182";
            this.tasta182.Size = new System.Drawing.Size(13, 21);
            this.tasta182.TabIndex = 136;
            // 
            // tasta183
            // 
            this.tasta183.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta183.Location = new System.Drawing.Point(555, 60);
            this.tasta183.Name = "tasta183";
            this.tasta183.Size = new System.Drawing.Size(13, 21);
            this.tasta183.TabIndex = 135;
            // 
            // tasta184
            // 
            this.tasta184.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta184.Location = new System.Drawing.Point(536, 60);
            this.tasta184.Name = "tasta184";
            this.tasta184.Size = new System.Drawing.Size(13, 21);
            this.tasta184.TabIndex = 134;
            // 
            // tasta185
            // 
            this.tasta185.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta185.Location = new System.Drawing.Point(517, 60);
            this.tasta185.Name = "tasta185";
            this.tasta185.Size = new System.Drawing.Size(13, 21);
            this.tasta185.TabIndex = 133;
            // 
            // tasta186
            // 
            this.tasta186.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta186.Location = new System.Drawing.Point(498, 60);
            this.tasta186.Name = "tasta186";
            this.tasta186.Size = new System.Drawing.Size(13, 21);
            this.tasta186.TabIndex = 132;
            // 
            // tasta187
            // 
            this.tasta187.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta187.Location = new System.Drawing.Point(479, 60);
            this.tasta187.Name = "tasta187";
            this.tasta187.Size = new System.Drawing.Size(13, 21);
            this.tasta187.TabIndex = 131;
            // 
            // tasta188
            // 
            this.tasta188.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta188.Location = new System.Drawing.Point(460, 60);
            this.tasta188.Name = "tasta188";
            this.tasta188.Size = new System.Drawing.Size(13, 21);
            this.tasta188.TabIndex = 130;
            // 
            // tasta189
            // 
            this.tasta189.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta189.Location = new System.Drawing.Point(441, 60);
            this.tasta189.Name = "tasta189";
            this.tasta189.Size = new System.Drawing.Size(13, 21);
            this.tasta189.TabIndex = 129;
            // 
            // tasta190
            // 
            this.tasta190.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta190.Location = new System.Drawing.Point(422, 60);
            this.tasta190.Name = "tasta190";
            this.tasta190.Size = new System.Drawing.Size(13, 21);
            this.tasta190.TabIndex = 128;
            // 
            // tasta191
            // 
            this.tasta191.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta191.Location = new System.Drawing.Point(403, 60);
            this.tasta191.Name = "tasta191";
            this.tasta191.Size = new System.Drawing.Size(13, 21);
            this.tasta191.TabIndex = 127;
            // 
            // tasta192
            // 
            this.tasta192.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta192.Location = new System.Drawing.Point(384, 60);
            this.tasta192.Name = "tasta192";
            this.tasta192.Size = new System.Drawing.Size(13, 21);
            this.tasta192.TabIndex = 126;
            // 
            // tasta193
            // 
            this.tasta193.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta193.Location = new System.Drawing.Point(365, 60);
            this.tasta193.Name = "tasta193";
            this.tasta193.Size = new System.Drawing.Size(13, 21);
            this.tasta193.TabIndex = 125;
            // 
            // tasta194
            // 
            this.tasta194.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta194.Location = new System.Drawing.Point(346, 60);
            this.tasta194.Name = "tasta194";
            this.tasta194.Size = new System.Drawing.Size(13, 21);
            this.tasta194.TabIndex = 124;
            // 
            // tasta195
            // 
            this.tasta195.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta195.Location = new System.Drawing.Point(327, 60);
            this.tasta195.Name = "tasta195";
            this.tasta195.Size = new System.Drawing.Size(13, 21);
            this.tasta195.TabIndex = 123;
            // 
            // tasta196
            // 
            this.tasta196.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta196.Location = new System.Drawing.Point(308, 60);
            this.tasta196.Name = "tasta196";
            this.tasta196.Size = new System.Drawing.Size(13, 21);
            this.tasta196.TabIndex = 122;
            // 
            // tasta197
            // 
            this.tasta197.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta197.Location = new System.Drawing.Point(289, 60);
            this.tasta197.Name = "tasta197";
            this.tasta197.Size = new System.Drawing.Size(13, 21);
            this.tasta197.TabIndex = 121;
            // 
            // tasta198
            // 
            this.tasta198.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta198.Location = new System.Drawing.Point(270, 60);
            this.tasta198.Name = "tasta198";
            this.tasta198.Size = new System.Drawing.Size(13, 21);
            this.tasta198.TabIndex = 120;
            // 
            // tasta199
            // 
            this.tasta199.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta199.Location = new System.Drawing.Point(251, 60);
            this.tasta199.Name = "tasta199";
            this.tasta199.Size = new System.Drawing.Size(13, 21);
            this.tasta199.TabIndex = 119;
            // 
            // tasta200
            // 
            this.tasta200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta200.Location = new System.Drawing.Point(232, 60);
            this.tasta200.Name = "tasta200";
            this.tasta200.Size = new System.Drawing.Size(13, 21);
            this.tasta200.TabIndex = 118;
            // 
            // tasta201
            // 
            this.tasta201.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta201.Location = new System.Drawing.Point(213, 60);
            this.tasta201.Name = "tasta201";
            this.tasta201.Size = new System.Drawing.Size(13, 21);
            this.tasta201.TabIndex = 117;
            // 
            // tasta202
            // 
            this.tasta202.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta202.Location = new System.Drawing.Point(194, 60);
            this.tasta202.Name = "tasta202";
            this.tasta202.Size = new System.Drawing.Size(13, 21);
            this.tasta202.TabIndex = 116;
            // 
            // tasta203
            // 
            this.tasta203.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta203.Location = new System.Drawing.Point(175, 60);
            this.tasta203.Name = "tasta203";
            this.tasta203.Size = new System.Drawing.Size(13, 21);
            this.tasta203.TabIndex = 115;
            // 
            // tasta204
            // 
            this.tasta204.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta204.Location = new System.Drawing.Point(156, 60);
            this.tasta204.Name = "tasta204";
            this.tasta204.Size = new System.Drawing.Size(13, 21);
            this.tasta204.TabIndex = 114;
            // 
            // tasta205
            // 
            this.tasta205.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta205.Location = new System.Drawing.Point(137, 60);
            this.tasta205.Name = "tasta205";
            this.tasta205.Size = new System.Drawing.Size(13, 21);
            this.tasta205.TabIndex = 113;
            // 
            // tasta206
            // 
            this.tasta206.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta206.Location = new System.Drawing.Point(118, 60);
            this.tasta206.Name = "tasta206";
            this.tasta206.Size = new System.Drawing.Size(13, 21);
            this.tasta206.TabIndex = 112;
            // 
            // tasta207
            // 
            this.tasta207.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta207.Location = new System.Drawing.Point(99, 60);
            this.tasta207.Name = "tasta207";
            this.tasta207.Size = new System.Drawing.Size(13, 21);
            this.tasta207.TabIndex = 111;
            // 
            // tasta208
            // 
            this.tasta208.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta208.Location = new System.Drawing.Point(80, 60);
            this.tasta208.Name = "tasta208";
            this.tasta208.Size = new System.Drawing.Size(13, 21);
            this.tasta208.TabIndex = 110;
            // 
            // tasta209
            // 
            this.tasta209.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta209.Location = new System.Drawing.Point(61, 60);
            this.tasta209.Name = "tasta209";
            this.tasta209.Size = new System.Drawing.Size(13, 21);
            this.tasta209.TabIndex = 109;
            // 
            // tasta210
            // 
            this.tasta210.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta210.Location = new System.Drawing.Point(42, 60);
            this.tasta210.Name = "tasta210";
            this.tasta210.Size = new System.Drawing.Size(13, 21);
            this.tasta210.TabIndex = 108;
            // 
            // tasta211
            // 
            this.tasta211.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta211.Location = new System.Drawing.Point(23, 60);
            this.tasta211.Name = "tasta211";
            this.tasta211.Size = new System.Drawing.Size(13, 21);
            this.tasta211.TabIndex = 107;
            // 
            // tasta212
            // 
            this.tasta212.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta212.Location = new System.Drawing.Point(4, 60);
            this.tasta212.Name = "tasta212";
            this.tasta212.Size = new System.Drawing.Size(13, 21);
            this.tasta212.TabIndex = 106;
            // 
            // tasta213
            // 
            this.tasta213.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta213.Location = new System.Drawing.Point(993, 195);
            this.tasta213.Name = "tasta213";
            this.tasta213.Size = new System.Drawing.Size(13, 21);
            this.tasta213.TabIndex = 423;
            // 
            // tasta214
            // 
            this.tasta214.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta214.Location = new System.Drawing.Point(974, 195);
            this.tasta214.Name = "tasta214";
            this.tasta214.Size = new System.Drawing.Size(13, 21);
            this.tasta214.TabIndex = 422;
            // 
            // tasta215
            // 
            this.tasta215.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta215.Location = new System.Drawing.Point(955, 195);
            this.tasta215.Name = "tasta215";
            this.tasta215.Size = new System.Drawing.Size(13, 21);
            this.tasta215.TabIndex = 421;
            // 
            // tasta216
            // 
            this.tasta216.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta216.Location = new System.Drawing.Point(936, 195);
            this.tasta216.Name = "tasta216";
            this.tasta216.Size = new System.Drawing.Size(13, 21);
            this.tasta216.TabIndex = 420;
            // 
            // tasta217
            // 
            this.tasta217.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta217.Location = new System.Drawing.Point(917, 195);
            this.tasta217.Name = "tasta217";
            this.tasta217.Size = new System.Drawing.Size(13, 21);
            this.tasta217.TabIndex = 419;
            // 
            // tasta218
            // 
            this.tasta218.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta218.Location = new System.Drawing.Point(897, 195);
            this.tasta218.Name = "tasta218";
            this.tasta218.Size = new System.Drawing.Size(13, 21);
            this.tasta218.TabIndex = 418;
            // 
            // tasta219
            // 
            this.tasta219.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta219.Location = new System.Drawing.Point(878, 195);
            this.tasta219.Name = "tasta219";
            this.tasta219.Size = new System.Drawing.Size(13, 21);
            this.tasta219.TabIndex = 417;
            // 
            // tasta220
            // 
            this.tasta220.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta220.Location = new System.Drawing.Point(859, 195);
            this.tasta220.Name = "tasta220";
            this.tasta220.Size = new System.Drawing.Size(13, 21);
            this.tasta220.TabIndex = 416;
            // 
            // tasta221
            // 
            this.tasta221.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta221.Location = new System.Drawing.Point(840, 195);
            this.tasta221.Name = "tasta221";
            this.tasta221.Size = new System.Drawing.Size(13, 21);
            this.tasta221.TabIndex = 415;
            // 
            // tasta222
            // 
            this.tasta222.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta222.Location = new System.Drawing.Point(821, 195);
            this.tasta222.Name = "tasta222";
            this.tasta222.Size = new System.Drawing.Size(13, 21);
            this.tasta222.TabIndex = 414;
            // 
            // tasta223
            // 
            this.tasta223.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta223.Location = new System.Drawing.Point(802, 195);
            this.tasta223.Name = "tasta223";
            this.tasta223.Size = new System.Drawing.Size(13, 21);
            this.tasta223.TabIndex = 413;
            // 
            // tasta224
            // 
            this.tasta224.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta224.Location = new System.Drawing.Point(783, 195);
            this.tasta224.Name = "tasta224";
            this.tasta224.Size = new System.Drawing.Size(13, 21);
            this.tasta224.TabIndex = 412;
            // 
            // tasta225
            // 
            this.tasta225.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta225.Location = new System.Drawing.Point(764, 195);
            this.tasta225.Name = "tasta225";
            this.tasta225.Size = new System.Drawing.Size(13, 21);
            this.tasta225.TabIndex = 411;
            // 
            // tasta226
            // 
            this.tasta226.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta226.Location = new System.Drawing.Point(745, 195);
            this.tasta226.Name = "tasta226";
            this.tasta226.Size = new System.Drawing.Size(13, 21);
            this.tasta226.TabIndex = 410;
            // 
            // tasta227
            // 
            this.tasta227.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta227.Location = new System.Drawing.Point(726, 195);
            this.tasta227.Name = "tasta227";
            this.tasta227.Size = new System.Drawing.Size(13, 21);
            this.tasta227.TabIndex = 409;
            // 
            // tasta228
            // 
            this.tasta228.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta228.Location = new System.Drawing.Point(707, 195);
            this.tasta228.Name = "tasta228";
            this.tasta228.Size = new System.Drawing.Size(13, 21);
            this.tasta228.TabIndex = 408;
            // 
            // tasta229
            // 
            this.tasta229.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta229.Location = new System.Drawing.Point(688, 195);
            this.tasta229.Name = "tasta229";
            this.tasta229.Size = new System.Drawing.Size(13, 21);
            this.tasta229.TabIndex = 407;
            // 
            // tasta230
            // 
            this.tasta230.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta230.Location = new System.Drawing.Point(669, 195);
            this.tasta230.Name = "tasta230";
            this.tasta230.Size = new System.Drawing.Size(13, 21);
            this.tasta230.TabIndex = 406;
            // 
            // tasta231
            // 
            this.tasta231.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta231.Location = new System.Drawing.Point(650, 195);
            this.tasta231.Name = "tasta231";
            this.tasta231.Size = new System.Drawing.Size(13, 21);
            this.tasta231.TabIndex = 405;
            // 
            // tasta232
            // 
            this.tasta232.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta232.Location = new System.Drawing.Point(631, 195);
            this.tasta232.Name = "tasta232";
            this.tasta232.Size = new System.Drawing.Size(13, 21);
            this.tasta232.TabIndex = 404;
            // 
            // tasta233
            // 
            this.tasta233.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta233.Location = new System.Drawing.Point(612, 195);
            this.tasta233.Name = "tasta233";
            this.tasta233.Size = new System.Drawing.Size(13, 21);
            this.tasta233.TabIndex = 403;
            // 
            // tasta234
            // 
            this.tasta234.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta234.Location = new System.Drawing.Point(593, 195);
            this.tasta234.Name = "tasta234";
            this.tasta234.Size = new System.Drawing.Size(13, 21);
            this.tasta234.TabIndex = 402;
            // 
            // tasta235
            // 
            this.tasta235.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta235.Location = new System.Drawing.Point(574, 195);
            this.tasta235.Name = "tasta235";
            this.tasta235.Size = new System.Drawing.Size(13, 21);
            this.tasta235.TabIndex = 401;
            // 
            // tasta236
            // 
            this.tasta236.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta236.Location = new System.Drawing.Point(555, 195);
            this.tasta236.Name = "tasta236";
            this.tasta236.Size = new System.Drawing.Size(13, 21);
            this.tasta236.TabIndex = 400;
            // 
            // tasta237
            // 
            this.tasta237.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta237.Location = new System.Drawing.Point(536, 195);
            this.tasta237.Name = "tasta237";
            this.tasta237.Size = new System.Drawing.Size(13, 21);
            this.tasta237.TabIndex = 399;
            // 
            // tasta238
            // 
            this.tasta238.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta238.Location = new System.Drawing.Point(517, 195);
            this.tasta238.Name = "tasta238";
            this.tasta238.Size = new System.Drawing.Size(13, 21);
            this.tasta238.TabIndex = 398;
            // 
            // tasta239
            // 
            this.tasta239.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta239.Location = new System.Drawing.Point(498, 195);
            this.tasta239.Name = "tasta239";
            this.tasta239.Size = new System.Drawing.Size(13, 21);
            this.tasta239.TabIndex = 397;
            // 
            // tasta240
            // 
            this.tasta240.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta240.Location = new System.Drawing.Point(479, 195);
            this.tasta240.Name = "tasta240";
            this.tasta240.Size = new System.Drawing.Size(13, 21);
            this.tasta240.TabIndex = 396;
            // 
            // tasta241
            // 
            this.tasta241.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta241.Location = new System.Drawing.Point(460, 195);
            this.tasta241.Name = "tasta241";
            this.tasta241.Size = new System.Drawing.Size(13, 21);
            this.tasta241.TabIndex = 395;
            // 
            // tasta242
            // 
            this.tasta242.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta242.Location = new System.Drawing.Point(441, 195);
            this.tasta242.Name = "tasta242";
            this.tasta242.Size = new System.Drawing.Size(13, 21);
            this.tasta242.TabIndex = 394;
            // 
            // tasta243
            // 
            this.tasta243.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta243.Location = new System.Drawing.Point(422, 195);
            this.tasta243.Name = "tasta243";
            this.tasta243.Size = new System.Drawing.Size(13, 21);
            this.tasta243.TabIndex = 393;
            // 
            // tasta244
            // 
            this.tasta244.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta244.Location = new System.Drawing.Point(403, 195);
            this.tasta244.Name = "tasta244";
            this.tasta244.Size = new System.Drawing.Size(13, 21);
            this.tasta244.TabIndex = 392;
            // 
            // tasta245
            // 
            this.tasta245.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta245.Location = new System.Drawing.Point(384, 195);
            this.tasta245.Name = "tasta245";
            this.tasta245.Size = new System.Drawing.Size(13, 21);
            this.tasta245.TabIndex = 391;
            // 
            // tasta246
            // 
            this.tasta246.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta246.Location = new System.Drawing.Point(365, 195);
            this.tasta246.Name = "tasta246";
            this.tasta246.Size = new System.Drawing.Size(13, 21);
            this.tasta246.TabIndex = 390;
            // 
            // tasta247
            // 
            this.tasta247.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta247.Location = new System.Drawing.Point(346, 195);
            this.tasta247.Name = "tasta247";
            this.tasta247.Size = new System.Drawing.Size(13, 21);
            this.tasta247.TabIndex = 389;
            // 
            // tasta248
            // 
            this.tasta248.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta248.Location = new System.Drawing.Point(327, 195);
            this.tasta248.Name = "tasta248";
            this.tasta248.Size = new System.Drawing.Size(13, 21);
            this.tasta248.TabIndex = 388;
            // 
            // tasta249
            // 
            this.tasta249.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta249.Location = new System.Drawing.Point(308, 195);
            this.tasta249.Name = "tasta249";
            this.tasta249.Size = new System.Drawing.Size(13, 21);
            this.tasta249.TabIndex = 387;
            // 
            // tasta250
            // 
            this.tasta250.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta250.Location = new System.Drawing.Point(289, 195);
            this.tasta250.Name = "tasta250";
            this.tasta250.Size = new System.Drawing.Size(13, 21);
            this.tasta250.TabIndex = 386;
            // 
            // tasta251
            // 
            this.tasta251.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta251.Location = new System.Drawing.Point(270, 195);
            this.tasta251.Name = "tasta251";
            this.tasta251.Size = new System.Drawing.Size(13, 21);
            this.tasta251.TabIndex = 385;
            // 
            // tasta252
            // 
            this.tasta252.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta252.Location = new System.Drawing.Point(251, 195);
            this.tasta252.Name = "tasta252";
            this.tasta252.Size = new System.Drawing.Size(13, 21);
            this.tasta252.TabIndex = 384;
            // 
            // tasta253
            // 
            this.tasta253.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta253.Location = new System.Drawing.Point(232, 195);
            this.tasta253.Name = "tasta253";
            this.tasta253.Size = new System.Drawing.Size(13, 21);
            this.tasta253.TabIndex = 383;
            // 
            // tasta254
            // 
            this.tasta254.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta254.Location = new System.Drawing.Point(213, 195);
            this.tasta254.Name = "tasta254";
            this.tasta254.Size = new System.Drawing.Size(13, 21);
            this.tasta254.TabIndex = 382;
            // 
            // tasta255
            // 
            this.tasta255.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta255.Location = new System.Drawing.Point(194, 195);
            this.tasta255.Name = "tasta255";
            this.tasta255.Size = new System.Drawing.Size(13, 21);
            this.tasta255.TabIndex = 381;
            // 
            // tasta256
            // 
            this.tasta256.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta256.Location = new System.Drawing.Point(175, 195);
            this.tasta256.Name = "tasta256";
            this.tasta256.Size = new System.Drawing.Size(13, 21);
            this.tasta256.TabIndex = 380;
            // 
            // tasta257
            // 
            this.tasta257.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta257.Location = new System.Drawing.Point(156, 195);
            this.tasta257.Name = "tasta257";
            this.tasta257.Size = new System.Drawing.Size(13, 21);
            this.tasta257.TabIndex = 379;
            // 
            // tasta258
            // 
            this.tasta258.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta258.Location = new System.Drawing.Point(137, 195);
            this.tasta258.Name = "tasta258";
            this.tasta258.Size = new System.Drawing.Size(13, 21);
            this.tasta258.TabIndex = 378;
            // 
            // tasta259
            // 
            this.tasta259.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta259.Location = new System.Drawing.Point(118, 195);
            this.tasta259.Name = "tasta259";
            this.tasta259.Size = new System.Drawing.Size(13, 21);
            this.tasta259.TabIndex = 377;
            // 
            // tasta260
            // 
            this.tasta260.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta260.Location = new System.Drawing.Point(99, 195);
            this.tasta260.Name = "tasta260";
            this.tasta260.Size = new System.Drawing.Size(13, 21);
            this.tasta260.TabIndex = 376;
            // 
            // tasta261
            // 
            this.tasta261.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta261.Location = new System.Drawing.Point(80, 195);
            this.tasta261.Name = "tasta261";
            this.tasta261.Size = new System.Drawing.Size(13, 21);
            this.tasta261.TabIndex = 375;
            // 
            // tasta262
            // 
            this.tasta262.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta262.Location = new System.Drawing.Point(61, 195);
            this.tasta262.Name = "tasta262";
            this.tasta262.Size = new System.Drawing.Size(13, 21);
            this.tasta262.TabIndex = 374;
            // 
            // tasta263
            // 
            this.tasta263.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta263.Location = new System.Drawing.Point(42, 195);
            this.tasta263.Name = "tasta263";
            this.tasta263.Size = new System.Drawing.Size(13, 21);
            this.tasta263.TabIndex = 373;
            // 
            // tasta264
            // 
            this.tasta264.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta264.Location = new System.Drawing.Point(23, 195);
            this.tasta264.Name = "tasta264";
            this.tasta264.Size = new System.Drawing.Size(13, 21);
            this.tasta264.TabIndex = 372;
            // 
            // tasta265
            // 
            this.tasta265.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta265.Location = new System.Drawing.Point(4, 195);
            this.tasta265.Name = "tasta265";
            this.tasta265.Size = new System.Drawing.Size(13, 21);
            this.tasta265.TabIndex = 371;
            // 
            // tasta266
            // 
            this.tasta266.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta266.Location = new System.Drawing.Point(993, 168);
            this.tasta266.Name = "tasta266";
            this.tasta266.Size = new System.Drawing.Size(13, 21);
            this.tasta266.TabIndex = 370;
            // 
            // tasta267
            // 
            this.tasta267.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta267.Location = new System.Drawing.Point(974, 168);
            this.tasta267.Name = "tasta267";
            this.tasta267.Size = new System.Drawing.Size(13, 21);
            this.tasta267.TabIndex = 369;
            // 
            // tasta268
            // 
            this.tasta268.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta268.Location = new System.Drawing.Point(955, 168);
            this.tasta268.Name = "tasta268";
            this.tasta268.Size = new System.Drawing.Size(13, 21);
            this.tasta268.TabIndex = 368;
            // 
            // tasta269
            // 
            this.tasta269.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta269.Location = new System.Drawing.Point(936, 168);
            this.tasta269.Name = "tasta269";
            this.tasta269.Size = new System.Drawing.Size(13, 21);
            this.tasta269.TabIndex = 367;
            // 
            // tasta270
            // 
            this.tasta270.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta270.Location = new System.Drawing.Point(917, 168);
            this.tasta270.Name = "tasta270";
            this.tasta270.Size = new System.Drawing.Size(13, 21);
            this.tasta270.TabIndex = 366;
            // 
            // tasta271
            // 
            this.tasta271.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta271.Location = new System.Drawing.Point(897, 168);
            this.tasta271.Name = "tasta271";
            this.tasta271.Size = new System.Drawing.Size(13, 21);
            this.tasta271.TabIndex = 365;
            // 
            // tasta272
            // 
            this.tasta272.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta272.Location = new System.Drawing.Point(878, 168);
            this.tasta272.Name = "tasta272";
            this.tasta272.Size = new System.Drawing.Size(13, 21);
            this.tasta272.TabIndex = 364;
            // 
            // tasta273
            // 
            this.tasta273.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta273.Location = new System.Drawing.Point(859, 168);
            this.tasta273.Name = "tasta273";
            this.tasta273.Size = new System.Drawing.Size(13, 21);
            this.tasta273.TabIndex = 363;
            // 
            // tasta274
            // 
            this.tasta274.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta274.Location = new System.Drawing.Point(840, 168);
            this.tasta274.Name = "tasta274";
            this.tasta274.Size = new System.Drawing.Size(13, 21);
            this.tasta274.TabIndex = 362;
            // 
            // tasta275
            // 
            this.tasta275.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta275.Location = new System.Drawing.Point(821, 168);
            this.tasta275.Name = "tasta275";
            this.tasta275.Size = new System.Drawing.Size(13, 21);
            this.tasta275.TabIndex = 361;
            // 
            // tasta276
            // 
            this.tasta276.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta276.Location = new System.Drawing.Point(802, 168);
            this.tasta276.Name = "tasta276";
            this.tasta276.Size = new System.Drawing.Size(13, 21);
            this.tasta276.TabIndex = 360;
            // 
            // tasta277
            // 
            this.tasta277.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta277.Location = new System.Drawing.Point(783, 168);
            this.tasta277.Name = "tasta277";
            this.tasta277.Size = new System.Drawing.Size(13, 21);
            this.tasta277.TabIndex = 359;
            // 
            // tasta278
            // 
            this.tasta278.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta278.Location = new System.Drawing.Point(764, 168);
            this.tasta278.Name = "tasta278";
            this.tasta278.Size = new System.Drawing.Size(13, 21);
            this.tasta278.TabIndex = 358;
            // 
            // tasta279
            // 
            this.tasta279.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta279.Location = new System.Drawing.Point(745, 168);
            this.tasta279.Name = "tasta279";
            this.tasta279.Size = new System.Drawing.Size(13, 21);
            this.tasta279.TabIndex = 357;
            // 
            // tasta280
            // 
            this.tasta280.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta280.Location = new System.Drawing.Point(726, 168);
            this.tasta280.Name = "tasta280";
            this.tasta280.Size = new System.Drawing.Size(13, 21);
            this.tasta280.TabIndex = 356;
            // 
            // tasta281
            // 
            this.tasta281.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta281.Location = new System.Drawing.Point(707, 168);
            this.tasta281.Name = "tasta281";
            this.tasta281.Size = new System.Drawing.Size(13, 21);
            this.tasta281.TabIndex = 355;
            // 
            // tasta282
            // 
            this.tasta282.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta282.Location = new System.Drawing.Point(688, 168);
            this.tasta282.Name = "tasta282";
            this.tasta282.Size = new System.Drawing.Size(13, 21);
            this.tasta282.TabIndex = 354;
            // 
            // tasta283
            // 
            this.tasta283.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta283.Location = new System.Drawing.Point(669, 168);
            this.tasta283.Name = "tasta283";
            this.tasta283.Size = new System.Drawing.Size(13, 21);
            this.tasta283.TabIndex = 353;
            // 
            // tasta284
            // 
            this.tasta284.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta284.Location = new System.Drawing.Point(650, 168);
            this.tasta284.Name = "tasta284";
            this.tasta284.Size = new System.Drawing.Size(13, 21);
            this.tasta284.TabIndex = 352;
            // 
            // tasta285
            // 
            this.tasta285.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta285.Location = new System.Drawing.Point(631, 168);
            this.tasta285.Name = "tasta285";
            this.tasta285.Size = new System.Drawing.Size(13, 21);
            this.tasta285.TabIndex = 351;
            // 
            // tasta286
            // 
            this.tasta286.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta286.Location = new System.Drawing.Point(612, 168);
            this.tasta286.Name = "tasta286";
            this.tasta286.Size = new System.Drawing.Size(13, 21);
            this.tasta286.TabIndex = 350;
            // 
            // tasta287
            // 
            this.tasta287.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta287.Location = new System.Drawing.Point(593, 168);
            this.tasta287.Name = "tasta287";
            this.tasta287.Size = new System.Drawing.Size(13, 21);
            this.tasta287.TabIndex = 349;
            // 
            // tasta288
            // 
            this.tasta288.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta288.Location = new System.Drawing.Point(574, 168);
            this.tasta288.Name = "tasta288";
            this.tasta288.Size = new System.Drawing.Size(13, 21);
            this.tasta288.TabIndex = 348;
            // 
            // tasta289
            // 
            this.tasta289.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta289.Location = new System.Drawing.Point(555, 168);
            this.tasta289.Name = "tasta289";
            this.tasta289.Size = new System.Drawing.Size(13, 21);
            this.tasta289.TabIndex = 347;
            // 
            // tasta290
            // 
            this.tasta290.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta290.Location = new System.Drawing.Point(536, 168);
            this.tasta290.Name = "tasta290";
            this.tasta290.Size = new System.Drawing.Size(13, 21);
            this.tasta290.TabIndex = 346;
            // 
            // tasta291
            // 
            this.tasta291.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta291.Location = new System.Drawing.Point(517, 168);
            this.tasta291.Name = "tasta291";
            this.tasta291.Size = new System.Drawing.Size(13, 21);
            this.tasta291.TabIndex = 345;
            // 
            // tasta292
            // 
            this.tasta292.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta292.Location = new System.Drawing.Point(498, 168);
            this.tasta292.Name = "tasta292";
            this.tasta292.Size = new System.Drawing.Size(13, 21);
            this.tasta292.TabIndex = 344;
            // 
            // tasta293
            // 
            this.tasta293.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta293.Location = new System.Drawing.Point(479, 168);
            this.tasta293.Name = "tasta293";
            this.tasta293.Size = new System.Drawing.Size(13, 21);
            this.tasta293.TabIndex = 343;
            // 
            // tasta294
            // 
            this.tasta294.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta294.Location = new System.Drawing.Point(460, 168);
            this.tasta294.Name = "tasta294";
            this.tasta294.Size = new System.Drawing.Size(13, 21);
            this.tasta294.TabIndex = 342;
            // 
            // tasta295
            // 
            this.tasta295.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta295.Location = new System.Drawing.Point(441, 168);
            this.tasta295.Name = "tasta295";
            this.tasta295.Size = new System.Drawing.Size(13, 21);
            this.tasta295.TabIndex = 341;
            // 
            // tasta296
            // 
            this.tasta296.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta296.Location = new System.Drawing.Point(422, 168);
            this.tasta296.Name = "tasta296";
            this.tasta296.Size = new System.Drawing.Size(13, 21);
            this.tasta296.TabIndex = 340;
            // 
            // tasta297
            // 
            this.tasta297.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta297.Location = new System.Drawing.Point(403, 168);
            this.tasta297.Name = "tasta297";
            this.tasta297.Size = new System.Drawing.Size(13, 21);
            this.tasta297.TabIndex = 339;
            // 
            // tasta298
            // 
            this.tasta298.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta298.Location = new System.Drawing.Point(384, 168);
            this.tasta298.Name = "tasta298";
            this.tasta298.Size = new System.Drawing.Size(13, 21);
            this.tasta298.TabIndex = 338;
            // 
            // tasta299
            // 
            this.tasta299.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta299.Location = new System.Drawing.Point(365, 168);
            this.tasta299.Name = "tasta299";
            this.tasta299.Size = new System.Drawing.Size(13, 21);
            this.tasta299.TabIndex = 337;
            // 
            // tasta300
            // 
            this.tasta300.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta300.Location = new System.Drawing.Point(346, 168);
            this.tasta300.Name = "tasta300";
            this.tasta300.Size = new System.Drawing.Size(13, 21);
            this.tasta300.TabIndex = 336;
            // 
            // tasta301
            // 
            this.tasta301.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta301.Location = new System.Drawing.Point(327, 168);
            this.tasta301.Name = "tasta301";
            this.tasta301.Size = new System.Drawing.Size(13, 21);
            this.tasta301.TabIndex = 335;
            // 
            // tasta302
            // 
            this.tasta302.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta302.Location = new System.Drawing.Point(308, 168);
            this.tasta302.Name = "tasta302";
            this.tasta302.Size = new System.Drawing.Size(13, 21);
            this.tasta302.TabIndex = 334;
            // 
            // tasta303
            // 
            this.tasta303.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta303.Location = new System.Drawing.Point(289, 168);
            this.tasta303.Name = "tasta303";
            this.tasta303.Size = new System.Drawing.Size(13, 21);
            this.tasta303.TabIndex = 333;
            // 
            // tasta304
            // 
            this.tasta304.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta304.Location = new System.Drawing.Point(270, 168);
            this.tasta304.Name = "tasta304";
            this.tasta304.Size = new System.Drawing.Size(13, 21);
            this.tasta304.TabIndex = 332;
            // 
            // tasta305
            // 
            this.tasta305.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta305.Location = new System.Drawing.Point(251, 168);
            this.tasta305.Name = "tasta305";
            this.tasta305.Size = new System.Drawing.Size(13, 21);
            this.tasta305.TabIndex = 331;
            // 
            // tasta306
            // 
            this.tasta306.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta306.Location = new System.Drawing.Point(232, 168);
            this.tasta306.Name = "tasta306";
            this.tasta306.Size = new System.Drawing.Size(13, 21);
            this.tasta306.TabIndex = 330;
            // 
            // tasta307
            // 
            this.tasta307.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta307.Location = new System.Drawing.Point(213, 168);
            this.tasta307.Name = "tasta307";
            this.tasta307.Size = new System.Drawing.Size(13, 21);
            this.tasta307.TabIndex = 329;
            // 
            // tasta308
            // 
            this.tasta308.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta308.Location = new System.Drawing.Point(194, 168);
            this.tasta308.Name = "tasta308";
            this.tasta308.Size = new System.Drawing.Size(13, 21);
            this.tasta308.TabIndex = 328;
            // 
            // tasta309
            // 
            this.tasta309.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta309.Location = new System.Drawing.Point(175, 168);
            this.tasta309.Name = "tasta309";
            this.tasta309.Size = new System.Drawing.Size(13, 21);
            this.tasta309.TabIndex = 327;
            // 
            // tasta310
            // 
            this.tasta310.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta310.Location = new System.Drawing.Point(156, 168);
            this.tasta310.Name = "tasta310";
            this.tasta310.Size = new System.Drawing.Size(13, 21);
            this.tasta310.TabIndex = 326;
            // 
            // tasta311
            // 
            this.tasta311.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta311.Location = new System.Drawing.Point(137, 168);
            this.tasta311.Name = "tasta311";
            this.tasta311.Size = new System.Drawing.Size(13, 21);
            this.tasta311.TabIndex = 325;
            // 
            // tasta312
            // 
            this.tasta312.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta312.Location = new System.Drawing.Point(118, 168);
            this.tasta312.Name = "tasta312";
            this.tasta312.Size = new System.Drawing.Size(13, 21);
            this.tasta312.TabIndex = 324;
            // 
            // tasta313
            // 
            this.tasta313.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta313.Location = new System.Drawing.Point(99, 168);
            this.tasta313.Name = "tasta313";
            this.tasta313.Size = new System.Drawing.Size(13, 21);
            this.tasta313.TabIndex = 323;
            // 
            // tasta314
            // 
            this.tasta314.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta314.Location = new System.Drawing.Point(80, 168);
            this.tasta314.Name = "tasta314";
            this.tasta314.Size = new System.Drawing.Size(13, 21);
            this.tasta314.TabIndex = 322;
            // 
            // tasta315
            // 
            this.tasta315.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta315.Location = new System.Drawing.Point(61, 168);
            this.tasta315.Name = "tasta315";
            this.tasta315.Size = new System.Drawing.Size(13, 21);
            this.tasta315.TabIndex = 321;
            // 
            // tasta316
            // 
            this.tasta316.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta316.Location = new System.Drawing.Point(42, 168);
            this.tasta316.Name = "tasta316";
            this.tasta316.Size = new System.Drawing.Size(13, 21);
            this.tasta316.TabIndex = 320;
            // 
            // tasta317
            // 
            this.tasta317.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta317.Location = new System.Drawing.Point(23, 168);
            this.tasta317.Name = "tasta317";
            this.tasta317.Size = new System.Drawing.Size(13, 21);
            this.tasta317.TabIndex = 319;
            // 
            // tasta318
            // 
            this.tasta318.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta318.Location = new System.Drawing.Point(4, 168);
            this.tasta318.Name = "tasta318";
            this.tasta318.Size = new System.Drawing.Size(13, 21);
            this.tasta318.TabIndex = 318;
            // 
            // tasta319
            // 
            this.tasta319.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta319.Location = new System.Drawing.Point(993, 141);
            this.tasta319.Name = "tasta319";
            this.tasta319.Size = new System.Drawing.Size(13, 21);
            this.tasta319.TabIndex = 317;
            // 
            // tasta320
            // 
            this.tasta320.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta320.Location = new System.Drawing.Point(974, 141);
            this.tasta320.Name = "tasta320";
            this.tasta320.Size = new System.Drawing.Size(13, 21);
            this.tasta320.TabIndex = 316;
            // 
            // tasta321
            // 
            this.tasta321.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta321.Location = new System.Drawing.Point(955, 141);
            this.tasta321.Name = "tasta321";
            this.tasta321.Size = new System.Drawing.Size(13, 21);
            this.tasta321.TabIndex = 315;
            // 
            // tasta322
            // 
            this.tasta322.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta322.Location = new System.Drawing.Point(936, 141);
            this.tasta322.Name = "tasta322";
            this.tasta322.Size = new System.Drawing.Size(13, 21);
            this.tasta322.TabIndex = 314;
            // 
            // tasta323
            // 
            this.tasta323.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta323.Location = new System.Drawing.Point(917, 141);
            this.tasta323.Name = "tasta323";
            this.tasta323.Size = new System.Drawing.Size(13, 21);
            this.tasta323.TabIndex = 313;
            // 
            // tasta324
            // 
            this.tasta324.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta324.Location = new System.Drawing.Point(897, 141);
            this.tasta324.Name = "tasta324";
            this.tasta324.Size = new System.Drawing.Size(13, 21);
            this.tasta324.TabIndex = 312;
            // 
            // tasta325
            // 
            this.tasta325.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta325.Location = new System.Drawing.Point(878, 141);
            this.tasta325.Name = "tasta325";
            this.tasta325.Size = new System.Drawing.Size(13, 21);
            this.tasta325.TabIndex = 311;
            // 
            // tasta326
            // 
            this.tasta326.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta326.Location = new System.Drawing.Point(859, 141);
            this.tasta326.Name = "tasta326";
            this.tasta326.Size = new System.Drawing.Size(13, 21);
            this.tasta326.TabIndex = 310;
            // 
            // tasta327
            // 
            this.tasta327.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta327.Location = new System.Drawing.Point(840, 141);
            this.tasta327.Name = "tasta327";
            this.tasta327.Size = new System.Drawing.Size(13, 21);
            this.tasta327.TabIndex = 309;
            // 
            // tasta328
            // 
            this.tasta328.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta328.Location = new System.Drawing.Point(821, 141);
            this.tasta328.Name = "tasta328";
            this.tasta328.Size = new System.Drawing.Size(13, 21);
            this.tasta328.TabIndex = 308;
            // 
            // tasta329
            // 
            this.tasta329.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta329.Location = new System.Drawing.Point(802, 141);
            this.tasta329.Name = "tasta329";
            this.tasta329.Size = new System.Drawing.Size(13, 21);
            this.tasta329.TabIndex = 307;
            // 
            // tasta330
            // 
            this.tasta330.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta330.Location = new System.Drawing.Point(783, 141);
            this.tasta330.Name = "tasta330";
            this.tasta330.Size = new System.Drawing.Size(13, 21);
            this.tasta330.TabIndex = 306;
            // 
            // tasta331
            // 
            this.tasta331.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta331.Location = new System.Drawing.Point(764, 141);
            this.tasta331.Name = "tasta331";
            this.tasta331.Size = new System.Drawing.Size(13, 21);
            this.tasta331.TabIndex = 305;
            // 
            // tasta332
            // 
            this.tasta332.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta332.Location = new System.Drawing.Point(745, 141);
            this.tasta332.Name = "tasta332";
            this.tasta332.Size = new System.Drawing.Size(13, 21);
            this.tasta332.TabIndex = 304;
            // 
            // tasta333
            // 
            this.tasta333.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta333.Location = new System.Drawing.Point(726, 141);
            this.tasta333.Name = "tasta333";
            this.tasta333.Size = new System.Drawing.Size(13, 21);
            this.tasta333.TabIndex = 303;
            // 
            // tasta334
            // 
            this.tasta334.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta334.Location = new System.Drawing.Point(707, 141);
            this.tasta334.Name = "tasta334";
            this.tasta334.Size = new System.Drawing.Size(13, 21);
            this.tasta334.TabIndex = 302;
            // 
            // tasta335
            // 
            this.tasta335.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta335.Location = new System.Drawing.Point(688, 141);
            this.tasta335.Name = "tasta335";
            this.tasta335.Size = new System.Drawing.Size(13, 21);
            this.tasta335.TabIndex = 301;
            // 
            // tasta336
            // 
            this.tasta336.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta336.Location = new System.Drawing.Point(669, 141);
            this.tasta336.Name = "tasta336";
            this.tasta336.Size = new System.Drawing.Size(13, 21);
            this.tasta336.TabIndex = 300;
            // 
            // tasta337
            // 
            this.tasta337.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta337.Location = new System.Drawing.Point(650, 141);
            this.tasta337.Name = "tasta337";
            this.tasta337.Size = new System.Drawing.Size(13, 21);
            this.tasta337.TabIndex = 299;
            // 
            // tasta338
            // 
            this.tasta338.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta338.Location = new System.Drawing.Point(631, 141);
            this.tasta338.Name = "tasta338";
            this.tasta338.Size = new System.Drawing.Size(13, 21);
            this.tasta338.TabIndex = 298;
            // 
            // tasta339
            // 
            this.tasta339.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta339.Location = new System.Drawing.Point(612, 141);
            this.tasta339.Name = "tasta339";
            this.tasta339.Size = new System.Drawing.Size(13, 21);
            this.tasta339.TabIndex = 297;
            // 
            // tasta340
            // 
            this.tasta340.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta340.Location = new System.Drawing.Point(593, 141);
            this.tasta340.Name = "tasta340";
            this.tasta340.Size = new System.Drawing.Size(13, 21);
            this.tasta340.TabIndex = 296;
            // 
            // tasta341
            // 
            this.tasta341.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta341.Location = new System.Drawing.Point(574, 141);
            this.tasta341.Name = "tasta341";
            this.tasta341.Size = new System.Drawing.Size(13, 21);
            this.tasta341.TabIndex = 295;
            // 
            // tasta342
            // 
            this.tasta342.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta342.Location = new System.Drawing.Point(555, 141);
            this.tasta342.Name = "tasta342";
            this.tasta342.Size = new System.Drawing.Size(13, 21);
            this.tasta342.TabIndex = 294;
            // 
            // tasta343
            // 
            this.tasta343.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta343.Location = new System.Drawing.Point(536, 141);
            this.tasta343.Name = "tasta343";
            this.tasta343.Size = new System.Drawing.Size(13, 21);
            this.tasta343.TabIndex = 293;
            // 
            // tasta344
            // 
            this.tasta344.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta344.Location = new System.Drawing.Point(517, 141);
            this.tasta344.Name = "tasta344";
            this.tasta344.Size = new System.Drawing.Size(13, 21);
            this.tasta344.TabIndex = 292;
            // 
            // tasta345
            // 
            this.tasta345.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta345.Location = new System.Drawing.Point(498, 141);
            this.tasta345.Name = "tasta345";
            this.tasta345.Size = new System.Drawing.Size(13, 21);
            this.tasta345.TabIndex = 291;
            // 
            // tasta346
            // 
            this.tasta346.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta346.Location = new System.Drawing.Point(479, 141);
            this.tasta346.Name = "tasta346";
            this.tasta346.Size = new System.Drawing.Size(13, 21);
            this.tasta346.TabIndex = 290;
            // 
            // tasta347
            // 
            this.tasta347.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta347.Location = new System.Drawing.Point(460, 141);
            this.tasta347.Name = "tasta347";
            this.tasta347.Size = new System.Drawing.Size(13, 21);
            this.tasta347.TabIndex = 289;
            // 
            // tasta348
            // 
            this.tasta348.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta348.Location = new System.Drawing.Point(441, 141);
            this.tasta348.Name = "tasta348";
            this.tasta348.Size = new System.Drawing.Size(13, 21);
            this.tasta348.TabIndex = 288;
            // 
            // tasta349
            // 
            this.tasta349.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta349.Location = new System.Drawing.Point(422, 141);
            this.tasta349.Name = "tasta349";
            this.tasta349.Size = new System.Drawing.Size(13, 21);
            this.tasta349.TabIndex = 287;
            // 
            // tasta350
            // 
            this.tasta350.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta350.Location = new System.Drawing.Point(403, 141);
            this.tasta350.Name = "tasta350";
            this.tasta350.Size = new System.Drawing.Size(13, 21);
            this.tasta350.TabIndex = 286;
            // 
            // tasta351
            // 
            this.tasta351.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta351.Location = new System.Drawing.Point(384, 141);
            this.tasta351.Name = "tasta351";
            this.tasta351.Size = new System.Drawing.Size(13, 21);
            this.tasta351.TabIndex = 285;
            // 
            // tasta352
            // 
            this.tasta352.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta352.Location = new System.Drawing.Point(365, 141);
            this.tasta352.Name = "tasta352";
            this.tasta352.Size = new System.Drawing.Size(13, 21);
            this.tasta352.TabIndex = 284;
            // 
            // tasta353
            // 
            this.tasta353.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta353.Location = new System.Drawing.Point(346, 141);
            this.tasta353.Name = "tasta353";
            this.tasta353.Size = new System.Drawing.Size(13, 21);
            this.tasta353.TabIndex = 283;
            // 
            // tasta354
            // 
            this.tasta354.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta354.Location = new System.Drawing.Point(327, 141);
            this.tasta354.Name = "tasta354";
            this.tasta354.Size = new System.Drawing.Size(13, 21);
            this.tasta354.TabIndex = 282;
            // 
            // tasta355
            // 
            this.tasta355.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta355.Location = new System.Drawing.Point(308, 141);
            this.tasta355.Name = "tasta355";
            this.tasta355.Size = new System.Drawing.Size(13, 21);
            this.tasta355.TabIndex = 281;
            // 
            // tasta356
            // 
            this.tasta356.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta356.Location = new System.Drawing.Point(289, 141);
            this.tasta356.Name = "tasta356";
            this.tasta356.Size = new System.Drawing.Size(13, 21);
            this.tasta356.TabIndex = 280;
            // 
            // tasta357
            // 
            this.tasta357.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta357.Location = new System.Drawing.Point(270, 141);
            this.tasta357.Name = "tasta357";
            this.tasta357.Size = new System.Drawing.Size(13, 21);
            this.tasta357.TabIndex = 279;
            // 
            // tasta358
            // 
            this.tasta358.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta358.Location = new System.Drawing.Point(251, 141);
            this.tasta358.Name = "tasta358";
            this.tasta358.Size = new System.Drawing.Size(13, 21);
            this.tasta358.TabIndex = 278;
            // 
            // tasta359
            // 
            this.tasta359.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta359.Location = new System.Drawing.Point(232, 141);
            this.tasta359.Name = "tasta359";
            this.tasta359.Size = new System.Drawing.Size(13, 21);
            this.tasta359.TabIndex = 277;
            // 
            // tasta360
            // 
            this.tasta360.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta360.Location = new System.Drawing.Point(213, 141);
            this.tasta360.Name = "tasta360";
            this.tasta360.Size = new System.Drawing.Size(13, 21);
            this.tasta360.TabIndex = 276;
            // 
            // tasta361
            // 
            this.tasta361.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta361.Location = new System.Drawing.Point(194, 141);
            this.tasta361.Name = "tasta361";
            this.tasta361.Size = new System.Drawing.Size(13, 21);
            this.tasta361.TabIndex = 275;
            // 
            // tasta362
            // 
            this.tasta362.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta362.Location = new System.Drawing.Point(175, 141);
            this.tasta362.Name = "tasta362";
            this.tasta362.Size = new System.Drawing.Size(13, 21);
            this.tasta362.TabIndex = 274;
            // 
            // tasta363
            // 
            this.tasta363.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta363.Location = new System.Drawing.Point(156, 141);
            this.tasta363.Name = "tasta363";
            this.tasta363.Size = new System.Drawing.Size(13, 21);
            this.tasta363.TabIndex = 273;
            // 
            // tasta364
            // 
            this.tasta364.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta364.Location = new System.Drawing.Point(137, 141);
            this.tasta364.Name = "tasta364";
            this.tasta364.Size = new System.Drawing.Size(13, 21);
            this.tasta364.TabIndex = 272;
            // 
            // tasta365
            // 
            this.tasta365.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta365.Location = new System.Drawing.Point(118, 141);
            this.tasta365.Name = "tasta365";
            this.tasta365.Size = new System.Drawing.Size(13, 21);
            this.tasta365.TabIndex = 271;
            // 
            // tasta366
            // 
            this.tasta366.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta366.Location = new System.Drawing.Point(99, 141);
            this.tasta366.Name = "tasta366";
            this.tasta366.Size = new System.Drawing.Size(13, 21);
            this.tasta366.TabIndex = 270;
            // 
            // tasta367
            // 
            this.tasta367.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta367.Location = new System.Drawing.Point(80, 141);
            this.tasta367.Name = "tasta367";
            this.tasta367.Size = new System.Drawing.Size(13, 21);
            this.tasta367.TabIndex = 269;
            // 
            // tasta368
            // 
            this.tasta368.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta368.Location = new System.Drawing.Point(61, 141);
            this.tasta368.Name = "tasta368";
            this.tasta368.Size = new System.Drawing.Size(13, 21);
            this.tasta368.TabIndex = 268;
            // 
            // tasta369
            // 
            this.tasta369.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta369.Location = new System.Drawing.Point(42, 141);
            this.tasta369.Name = "tasta369";
            this.tasta369.Size = new System.Drawing.Size(13, 21);
            this.tasta369.TabIndex = 267;
            // 
            // tasta370
            // 
            this.tasta370.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta370.Location = new System.Drawing.Point(23, 141);
            this.tasta370.Name = "tasta370";
            this.tasta370.Size = new System.Drawing.Size(13, 21);
            this.tasta370.TabIndex = 266;
            // 
            // tasta371
            // 
            this.tasta371.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta371.Location = new System.Drawing.Point(4, 141);
            this.tasta371.Name = "tasta371";
            this.tasta371.Size = new System.Drawing.Size(13, 21);
            this.tasta371.TabIndex = 265;
            // 
            // tasta372
            // 
            this.tasta372.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta372.Location = new System.Drawing.Point(993, 114);
            this.tasta372.Name = "tasta372";
            this.tasta372.Size = new System.Drawing.Size(13, 21);
            this.tasta372.TabIndex = 264;
            // 
            // tasta373
            // 
            this.tasta373.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta373.Location = new System.Drawing.Point(974, 114);
            this.tasta373.Name = "tasta373";
            this.tasta373.Size = new System.Drawing.Size(13, 21);
            this.tasta373.TabIndex = 263;
            // 
            // tasta374
            // 
            this.tasta374.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta374.Location = new System.Drawing.Point(955, 114);
            this.tasta374.Name = "tasta374";
            this.tasta374.Size = new System.Drawing.Size(13, 21);
            this.tasta374.TabIndex = 262;
            // 
            // tasta375
            // 
            this.tasta375.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta375.Location = new System.Drawing.Point(936, 114);
            this.tasta375.Name = "tasta375";
            this.tasta375.Size = new System.Drawing.Size(13, 21);
            this.tasta375.TabIndex = 261;
            // 
            // tasta376
            // 
            this.tasta376.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta376.Location = new System.Drawing.Point(917, 114);
            this.tasta376.Name = "tasta376";
            this.tasta376.Size = new System.Drawing.Size(13, 21);
            this.tasta376.TabIndex = 260;
            // 
            // tasta377
            // 
            this.tasta377.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta377.Location = new System.Drawing.Point(897, 114);
            this.tasta377.Name = "tasta377";
            this.tasta377.Size = new System.Drawing.Size(13, 21);
            this.tasta377.TabIndex = 259;
            // 
            // tasta378
            // 
            this.tasta378.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta378.Location = new System.Drawing.Point(878, 114);
            this.tasta378.Name = "tasta378";
            this.tasta378.Size = new System.Drawing.Size(13, 21);
            this.tasta378.TabIndex = 258;
            // 
            // tasta379
            // 
            this.tasta379.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta379.Location = new System.Drawing.Point(859, 114);
            this.tasta379.Name = "tasta379";
            this.tasta379.Size = new System.Drawing.Size(13, 21);
            this.tasta379.TabIndex = 257;
            // 
            // tasta380
            // 
            this.tasta380.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta380.Location = new System.Drawing.Point(840, 114);
            this.tasta380.Name = "tasta380";
            this.tasta380.Size = new System.Drawing.Size(13, 21);
            this.tasta380.TabIndex = 256;
            // 
            // tasta381
            // 
            this.tasta381.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta381.Location = new System.Drawing.Point(821, 114);
            this.tasta381.Name = "tasta381";
            this.tasta381.Size = new System.Drawing.Size(13, 21);
            this.tasta381.TabIndex = 255;
            // 
            // tasta382
            // 
            this.tasta382.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta382.Location = new System.Drawing.Point(802, 114);
            this.tasta382.Name = "tasta382";
            this.tasta382.Size = new System.Drawing.Size(13, 21);
            this.tasta382.TabIndex = 254;
            // 
            // tasta383
            // 
            this.tasta383.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta383.Location = new System.Drawing.Point(783, 114);
            this.tasta383.Name = "tasta383";
            this.tasta383.Size = new System.Drawing.Size(13, 21);
            this.tasta383.TabIndex = 253;
            // 
            // tasta384
            // 
            this.tasta384.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta384.Location = new System.Drawing.Point(764, 114);
            this.tasta384.Name = "tasta384";
            this.tasta384.Size = new System.Drawing.Size(13, 21);
            this.tasta384.TabIndex = 252;
            // 
            // tasta385
            // 
            this.tasta385.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta385.Location = new System.Drawing.Point(745, 114);
            this.tasta385.Name = "tasta385";
            this.tasta385.Size = new System.Drawing.Size(13, 21);
            this.tasta385.TabIndex = 251;
            // 
            // tasta386
            // 
            this.tasta386.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta386.Location = new System.Drawing.Point(726, 114);
            this.tasta386.Name = "tasta386";
            this.tasta386.Size = new System.Drawing.Size(13, 21);
            this.tasta386.TabIndex = 250;
            // 
            // tasta387
            // 
            this.tasta387.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta387.Location = new System.Drawing.Point(707, 114);
            this.tasta387.Name = "tasta387";
            this.tasta387.Size = new System.Drawing.Size(13, 21);
            this.tasta387.TabIndex = 249;
            // 
            // tasta388
            // 
            this.tasta388.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta388.Location = new System.Drawing.Point(688, 114);
            this.tasta388.Name = "tasta388";
            this.tasta388.Size = new System.Drawing.Size(13, 21);
            this.tasta388.TabIndex = 248;
            // 
            // tasta389
            // 
            this.tasta389.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta389.Location = new System.Drawing.Point(669, 114);
            this.tasta389.Name = "tasta389";
            this.tasta389.Size = new System.Drawing.Size(13, 21);
            this.tasta389.TabIndex = 247;
            // 
            // tasta390
            // 
            this.tasta390.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta390.Location = new System.Drawing.Point(650, 114);
            this.tasta390.Name = "tasta390";
            this.tasta390.Size = new System.Drawing.Size(13, 21);
            this.tasta390.TabIndex = 246;
            // 
            // tasta391
            // 
            this.tasta391.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta391.Location = new System.Drawing.Point(631, 114);
            this.tasta391.Name = "tasta391";
            this.tasta391.Size = new System.Drawing.Size(13, 21);
            this.tasta391.TabIndex = 245;
            // 
            // tasta392
            // 
            this.tasta392.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta392.Location = new System.Drawing.Point(612, 114);
            this.tasta392.Name = "tasta392";
            this.tasta392.Size = new System.Drawing.Size(13, 21);
            this.tasta392.TabIndex = 244;
            // 
            // tasta393
            // 
            this.tasta393.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta393.Location = new System.Drawing.Point(593, 114);
            this.tasta393.Name = "tasta393";
            this.tasta393.Size = new System.Drawing.Size(13, 21);
            this.tasta393.TabIndex = 243;
            // 
            // tasta394
            // 
            this.tasta394.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta394.Location = new System.Drawing.Point(574, 114);
            this.tasta394.Name = "tasta394";
            this.tasta394.Size = new System.Drawing.Size(13, 21);
            this.tasta394.TabIndex = 242;
            // 
            // tasta395
            // 
            this.tasta395.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta395.Location = new System.Drawing.Point(555, 114);
            this.tasta395.Name = "tasta395";
            this.tasta395.Size = new System.Drawing.Size(13, 21);
            this.tasta395.TabIndex = 241;
            // 
            // tasta396
            // 
            this.tasta396.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta396.Location = new System.Drawing.Point(536, 114);
            this.tasta396.Name = "tasta396";
            this.tasta396.Size = new System.Drawing.Size(13, 21);
            this.tasta396.TabIndex = 240;
            // 
            // tasta397
            // 
            this.tasta397.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta397.Location = new System.Drawing.Point(517, 114);
            this.tasta397.Name = "tasta397";
            this.tasta397.Size = new System.Drawing.Size(13, 21);
            this.tasta397.TabIndex = 239;
            // 
            // tasta398
            // 
            this.tasta398.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta398.Location = new System.Drawing.Point(498, 114);
            this.tasta398.Name = "tasta398";
            this.tasta398.Size = new System.Drawing.Size(13, 21);
            this.tasta398.TabIndex = 238;
            // 
            // tasta399
            // 
            this.tasta399.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta399.Location = new System.Drawing.Point(479, 114);
            this.tasta399.Name = "tasta399";
            this.tasta399.Size = new System.Drawing.Size(13, 21);
            this.tasta399.TabIndex = 237;
            // 
            // tasta400
            // 
            this.tasta400.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta400.Location = new System.Drawing.Point(460, 114);
            this.tasta400.Name = "tasta400";
            this.tasta400.Size = new System.Drawing.Size(13, 21);
            this.tasta400.TabIndex = 236;
            // 
            // tasta401
            // 
            this.tasta401.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta401.Location = new System.Drawing.Point(441, 114);
            this.tasta401.Name = "tasta401";
            this.tasta401.Size = new System.Drawing.Size(13, 21);
            this.tasta401.TabIndex = 235;
            // 
            // tasta402
            // 
            this.tasta402.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta402.Location = new System.Drawing.Point(422, 114);
            this.tasta402.Name = "tasta402";
            this.tasta402.Size = new System.Drawing.Size(13, 21);
            this.tasta402.TabIndex = 234;
            // 
            // tasta403
            // 
            this.tasta403.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta403.Location = new System.Drawing.Point(403, 114);
            this.tasta403.Name = "tasta403";
            this.tasta403.Size = new System.Drawing.Size(13, 21);
            this.tasta403.TabIndex = 233;
            // 
            // tasta404
            // 
            this.tasta404.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta404.Location = new System.Drawing.Point(384, 114);
            this.tasta404.Name = "tasta404";
            this.tasta404.Size = new System.Drawing.Size(13, 21);
            this.tasta404.TabIndex = 232;
            // 
            // tasta405
            // 
            this.tasta405.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta405.Location = new System.Drawing.Point(365, 114);
            this.tasta405.Name = "tasta405";
            this.tasta405.Size = new System.Drawing.Size(13, 21);
            this.tasta405.TabIndex = 231;
            // 
            // tasta406
            // 
            this.tasta406.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta406.Location = new System.Drawing.Point(346, 114);
            this.tasta406.Name = "tasta406";
            this.tasta406.Size = new System.Drawing.Size(13, 21);
            this.tasta406.TabIndex = 230;
            // 
            // tasta407
            // 
            this.tasta407.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta407.Location = new System.Drawing.Point(327, 114);
            this.tasta407.Name = "tasta407";
            this.tasta407.Size = new System.Drawing.Size(13, 21);
            this.tasta407.TabIndex = 229;
            // 
            // tasta408
            // 
            this.tasta408.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta408.Location = new System.Drawing.Point(308, 114);
            this.tasta408.Name = "tasta408";
            this.tasta408.Size = new System.Drawing.Size(13, 21);
            this.tasta408.TabIndex = 228;
            // 
            // tasta409
            // 
            this.tasta409.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta409.Location = new System.Drawing.Point(289, 114);
            this.tasta409.Name = "tasta409";
            this.tasta409.Size = new System.Drawing.Size(13, 21);
            this.tasta409.TabIndex = 227;
            // 
            // tasta410
            // 
            this.tasta410.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta410.Location = new System.Drawing.Point(270, 114);
            this.tasta410.Name = "tasta410";
            this.tasta410.Size = new System.Drawing.Size(13, 21);
            this.tasta410.TabIndex = 226;
            // 
            // tasta411
            // 
            this.tasta411.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta411.Location = new System.Drawing.Point(251, 114);
            this.tasta411.Name = "tasta411";
            this.tasta411.Size = new System.Drawing.Size(13, 21);
            this.tasta411.TabIndex = 225;
            // 
            // tasta412
            // 
            this.tasta412.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta412.Location = new System.Drawing.Point(232, 114);
            this.tasta412.Name = "tasta412";
            this.tasta412.Size = new System.Drawing.Size(13, 21);
            this.tasta412.TabIndex = 224;
            // 
            // tasta413
            // 
            this.tasta413.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta413.Location = new System.Drawing.Point(213, 114);
            this.tasta413.Name = "tasta413";
            this.tasta413.Size = new System.Drawing.Size(13, 21);
            this.tasta413.TabIndex = 223;
            // 
            // tasta414
            // 
            this.tasta414.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta414.Location = new System.Drawing.Point(194, 114);
            this.tasta414.Name = "tasta414";
            this.tasta414.Size = new System.Drawing.Size(13, 21);
            this.tasta414.TabIndex = 222;
            // 
            // tasta415
            // 
            this.tasta415.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta415.Location = new System.Drawing.Point(175, 114);
            this.tasta415.Name = "tasta415";
            this.tasta415.Size = new System.Drawing.Size(13, 21);
            this.tasta415.TabIndex = 221;
            // 
            // tasta416
            // 
            this.tasta416.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta416.Location = new System.Drawing.Point(156, 114);
            this.tasta416.Name = "tasta416";
            this.tasta416.Size = new System.Drawing.Size(13, 21);
            this.tasta416.TabIndex = 220;
            // 
            // tasta417
            // 
            this.tasta417.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta417.Location = new System.Drawing.Point(137, 114);
            this.tasta417.Name = "tasta417";
            this.tasta417.Size = new System.Drawing.Size(13, 21);
            this.tasta417.TabIndex = 219;
            // 
            // tasta418
            // 
            this.tasta418.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta418.Location = new System.Drawing.Point(118, 114);
            this.tasta418.Name = "tasta418";
            this.tasta418.Size = new System.Drawing.Size(13, 21);
            this.tasta418.TabIndex = 218;
            // 
            // tasta419
            // 
            this.tasta419.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta419.Location = new System.Drawing.Point(99, 114);
            this.tasta419.Name = "tasta419";
            this.tasta419.Size = new System.Drawing.Size(13, 21);
            this.tasta419.TabIndex = 217;
            // 
            // tasta420
            // 
            this.tasta420.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta420.Location = new System.Drawing.Point(80, 114);
            this.tasta420.Name = "tasta420";
            this.tasta420.Size = new System.Drawing.Size(13, 21);
            this.tasta420.TabIndex = 216;
            // 
            // tasta421
            // 
            this.tasta421.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta421.Location = new System.Drawing.Point(61, 114);
            this.tasta421.Name = "tasta421";
            this.tasta421.Size = new System.Drawing.Size(13, 21);
            this.tasta421.TabIndex = 215;
            // 
            // tasta422
            // 
            this.tasta422.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta422.Location = new System.Drawing.Point(42, 114);
            this.tasta422.Name = "tasta422";
            this.tasta422.Size = new System.Drawing.Size(13, 21);
            this.tasta422.TabIndex = 214;
            // 
            // tasta423
            // 
            this.tasta423.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta423.Location = new System.Drawing.Point(23, 114);
            this.tasta423.Name = "tasta423";
            this.tasta423.Size = new System.Drawing.Size(13, 21);
            this.tasta423.TabIndex = 213;
            // 
            // tasta424
            // 
            this.tasta424.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta424.Location = new System.Drawing.Point(4, 114);
            this.tasta424.Name = "tasta424";
            this.tasta424.Size = new System.Drawing.Size(13, 21);
            this.tasta424.TabIndex = 212;
            // 
            // tasta425
            // 
            this.tasta425.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta425.Location = new System.Drawing.Point(993, 411);
            this.tasta425.Name = "tasta425";
            this.tasta425.Size = new System.Drawing.Size(13, 21);
            this.tasta425.TabIndex = 847;
            // 
            // tasta426
            // 
            this.tasta426.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta426.Location = new System.Drawing.Point(974, 411);
            this.tasta426.Name = "tasta426";
            this.tasta426.Size = new System.Drawing.Size(13, 21);
            this.tasta426.TabIndex = 846;
            // 
            // tasta427
            // 
            this.tasta427.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta427.Location = new System.Drawing.Point(955, 411);
            this.tasta427.Name = "tasta427";
            this.tasta427.Size = new System.Drawing.Size(13, 21);
            this.tasta427.TabIndex = 845;
            // 
            // tasta428
            // 
            this.tasta428.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta428.Location = new System.Drawing.Point(936, 411);
            this.tasta428.Name = "tasta428";
            this.tasta428.Size = new System.Drawing.Size(13, 21);
            this.tasta428.TabIndex = 844;
            // 
            // tasta429
            // 
            this.tasta429.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta429.Location = new System.Drawing.Point(917, 411);
            this.tasta429.Name = "tasta429";
            this.tasta429.Size = new System.Drawing.Size(13, 21);
            this.tasta429.TabIndex = 843;
            // 
            // tasta430
            // 
            this.tasta430.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta430.Location = new System.Drawing.Point(897, 411);
            this.tasta430.Name = "tasta430";
            this.tasta430.Size = new System.Drawing.Size(13, 21);
            this.tasta430.TabIndex = 842;
            // 
            // tasta431
            // 
            this.tasta431.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta431.Location = new System.Drawing.Point(878, 411);
            this.tasta431.Name = "tasta431";
            this.tasta431.Size = new System.Drawing.Size(13, 21);
            this.tasta431.TabIndex = 841;
            // 
            // tasta432
            // 
            this.tasta432.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta432.Location = new System.Drawing.Point(859, 411);
            this.tasta432.Name = "tasta432";
            this.tasta432.Size = new System.Drawing.Size(13, 21);
            this.tasta432.TabIndex = 840;
            // 
            // tasta433
            // 
            this.tasta433.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta433.Location = new System.Drawing.Point(840, 411);
            this.tasta433.Name = "tasta433";
            this.tasta433.Size = new System.Drawing.Size(13, 21);
            this.tasta433.TabIndex = 839;
            // 
            // tasta434
            // 
            this.tasta434.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta434.Location = new System.Drawing.Point(821, 411);
            this.tasta434.Name = "tasta434";
            this.tasta434.Size = new System.Drawing.Size(13, 21);
            this.tasta434.TabIndex = 838;
            // 
            // tasta435
            // 
            this.tasta435.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta435.Location = new System.Drawing.Point(802, 411);
            this.tasta435.Name = "tasta435";
            this.tasta435.Size = new System.Drawing.Size(13, 21);
            this.tasta435.TabIndex = 837;
            // 
            // tasta436
            // 
            this.tasta436.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta436.Location = new System.Drawing.Point(783, 411);
            this.tasta436.Name = "tasta436";
            this.tasta436.Size = new System.Drawing.Size(13, 21);
            this.tasta436.TabIndex = 836;
            // 
            // tasta437
            // 
            this.tasta437.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta437.Location = new System.Drawing.Point(764, 411);
            this.tasta437.Name = "tasta437";
            this.tasta437.Size = new System.Drawing.Size(13, 21);
            this.tasta437.TabIndex = 835;
            // 
            // tasta438
            // 
            this.tasta438.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta438.Location = new System.Drawing.Point(745, 411);
            this.tasta438.Name = "tasta438";
            this.tasta438.Size = new System.Drawing.Size(13, 21);
            this.tasta438.TabIndex = 834;
            // 
            // tasta439
            // 
            this.tasta439.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta439.Location = new System.Drawing.Point(726, 411);
            this.tasta439.Name = "tasta439";
            this.tasta439.Size = new System.Drawing.Size(13, 21);
            this.tasta439.TabIndex = 833;
            // 
            // tasta440
            // 
            this.tasta440.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta440.Location = new System.Drawing.Point(707, 411);
            this.tasta440.Name = "tasta440";
            this.tasta440.Size = new System.Drawing.Size(13, 21);
            this.tasta440.TabIndex = 832;
            // 
            // tasta441
            // 
            this.tasta441.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta441.Location = new System.Drawing.Point(688, 411);
            this.tasta441.Name = "tasta441";
            this.tasta441.Size = new System.Drawing.Size(13, 21);
            this.tasta441.TabIndex = 831;
            // 
            // tasta442
            // 
            this.tasta442.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta442.Location = new System.Drawing.Point(669, 411);
            this.tasta442.Name = "tasta442";
            this.tasta442.Size = new System.Drawing.Size(13, 21);
            this.tasta442.TabIndex = 830;
            // 
            // tasta443
            // 
            this.tasta443.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta443.Location = new System.Drawing.Point(650, 411);
            this.tasta443.Name = "tasta443";
            this.tasta443.Size = new System.Drawing.Size(13, 21);
            this.tasta443.TabIndex = 829;
            // 
            // tasta444
            // 
            this.tasta444.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta444.Location = new System.Drawing.Point(631, 411);
            this.tasta444.Name = "tasta444";
            this.tasta444.Size = new System.Drawing.Size(13, 21);
            this.tasta444.TabIndex = 828;
            // 
            // tasta445
            // 
            this.tasta445.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta445.Location = new System.Drawing.Point(612, 411);
            this.tasta445.Name = "tasta445";
            this.tasta445.Size = new System.Drawing.Size(13, 21);
            this.tasta445.TabIndex = 827;
            // 
            // tasta446
            // 
            this.tasta446.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta446.Location = new System.Drawing.Point(593, 411);
            this.tasta446.Name = "tasta446";
            this.tasta446.Size = new System.Drawing.Size(13, 21);
            this.tasta446.TabIndex = 826;
            // 
            // tasta447
            // 
            this.tasta447.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta447.Location = new System.Drawing.Point(574, 411);
            this.tasta447.Name = "tasta447";
            this.tasta447.Size = new System.Drawing.Size(13, 21);
            this.tasta447.TabIndex = 825;
            // 
            // tasta448
            // 
            this.tasta448.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta448.Location = new System.Drawing.Point(555, 411);
            this.tasta448.Name = "tasta448";
            this.tasta448.Size = new System.Drawing.Size(13, 21);
            this.tasta448.TabIndex = 824;
            // 
            // tasta449
            // 
            this.tasta449.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta449.Location = new System.Drawing.Point(536, 411);
            this.tasta449.Name = "tasta449";
            this.tasta449.Size = new System.Drawing.Size(13, 21);
            this.tasta449.TabIndex = 823;
            // 
            // tasta450
            // 
            this.tasta450.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta450.Location = new System.Drawing.Point(517, 411);
            this.tasta450.Name = "tasta450";
            this.tasta450.Size = new System.Drawing.Size(13, 21);
            this.tasta450.TabIndex = 822;
            // 
            // tasta451
            // 
            this.tasta451.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta451.Location = new System.Drawing.Point(498, 411);
            this.tasta451.Name = "tasta451";
            this.tasta451.Size = new System.Drawing.Size(13, 21);
            this.tasta451.TabIndex = 821;
            // 
            // tasta452
            // 
            this.tasta452.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta452.Location = new System.Drawing.Point(479, 411);
            this.tasta452.Name = "tasta452";
            this.tasta452.Size = new System.Drawing.Size(13, 21);
            this.tasta452.TabIndex = 820;
            // 
            // tasta453
            // 
            this.tasta453.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta453.Location = new System.Drawing.Point(460, 411);
            this.tasta453.Name = "tasta453";
            this.tasta453.Size = new System.Drawing.Size(13, 21);
            this.tasta453.TabIndex = 819;
            // 
            // tasta454
            // 
            this.tasta454.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta454.Location = new System.Drawing.Point(441, 411);
            this.tasta454.Name = "tasta454";
            this.tasta454.Size = new System.Drawing.Size(13, 21);
            this.tasta454.TabIndex = 818;
            // 
            // tasta455
            // 
            this.tasta455.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta455.Location = new System.Drawing.Point(422, 411);
            this.tasta455.Name = "tasta455";
            this.tasta455.Size = new System.Drawing.Size(13, 21);
            this.tasta455.TabIndex = 817;
            // 
            // tasta456
            // 
            this.tasta456.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta456.Location = new System.Drawing.Point(403, 411);
            this.tasta456.Name = "tasta456";
            this.tasta456.Size = new System.Drawing.Size(13, 21);
            this.tasta456.TabIndex = 816;
            // 
            // tasta457
            // 
            this.tasta457.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta457.Location = new System.Drawing.Point(384, 411);
            this.tasta457.Name = "tasta457";
            this.tasta457.Size = new System.Drawing.Size(13, 21);
            this.tasta457.TabIndex = 815;
            // 
            // tasta458
            // 
            this.tasta458.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta458.Location = new System.Drawing.Point(365, 411);
            this.tasta458.Name = "tasta458";
            this.tasta458.Size = new System.Drawing.Size(13, 21);
            this.tasta458.TabIndex = 814;
            // 
            // tasta459
            // 
            this.tasta459.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta459.Location = new System.Drawing.Point(346, 411);
            this.tasta459.Name = "tasta459";
            this.tasta459.Size = new System.Drawing.Size(13, 21);
            this.tasta459.TabIndex = 813;
            // 
            // tasta460
            // 
            this.tasta460.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta460.Location = new System.Drawing.Point(327, 411);
            this.tasta460.Name = "tasta460";
            this.tasta460.Size = new System.Drawing.Size(13, 21);
            this.tasta460.TabIndex = 812;
            // 
            // tasta461
            // 
            this.tasta461.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta461.Location = new System.Drawing.Point(308, 411);
            this.tasta461.Name = "tasta461";
            this.tasta461.Size = new System.Drawing.Size(13, 21);
            this.tasta461.TabIndex = 811;
            // 
            // tasta462
            // 
            this.tasta462.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta462.Location = new System.Drawing.Point(289, 411);
            this.tasta462.Name = "tasta462";
            this.tasta462.Size = new System.Drawing.Size(13, 21);
            this.tasta462.TabIndex = 810;
            // 
            // tasta463
            // 
            this.tasta463.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta463.Location = new System.Drawing.Point(270, 411);
            this.tasta463.Name = "tasta463";
            this.tasta463.Size = new System.Drawing.Size(13, 21);
            this.tasta463.TabIndex = 809;
            // 
            // tasta464
            // 
            this.tasta464.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta464.Location = new System.Drawing.Point(251, 411);
            this.tasta464.Name = "tasta464";
            this.tasta464.Size = new System.Drawing.Size(13, 21);
            this.tasta464.TabIndex = 808;
            // 
            // tasta465
            // 
            this.tasta465.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta465.Location = new System.Drawing.Point(232, 411);
            this.tasta465.Name = "tasta465";
            this.tasta465.Size = new System.Drawing.Size(13, 21);
            this.tasta465.TabIndex = 807;
            // 
            // tasta466
            // 
            this.tasta466.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta466.Location = new System.Drawing.Point(213, 411);
            this.tasta466.Name = "tasta466";
            this.tasta466.Size = new System.Drawing.Size(13, 21);
            this.tasta466.TabIndex = 806;
            // 
            // tasta467
            // 
            this.tasta467.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta467.Location = new System.Drawing.Point(194, 411);
            this.tasta467.Name = "tasta467";
            this.tasta467.Size = new System.Drawing.Size(13, 21);
            this.tasta467.TabIndex = 805;
            // 
            // tasta468
            // 
            this.tasta468.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta468.Location = new System.Drawing.Point(175, 411);
            this.tasta468.Name = "tasta468";
            this.tasta468.Size = new System.Drawing.Size(13, 21);
            this.tasta468.TabIndex = 804;
            // 
            // tasta469
            // 
            this.tasta469.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta469.Location = new System.Drawing.Point(156, 411);
            this.tasta469.Name = "tasta469";
            this.tasta469.Size = new System.Drawing.Size(13, 21);
            this.tasta469.TabIndex = 803;
            // 
            // tasta470
            // 
            this.tasta470.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta470.Location = new System.Drawing.Point(137, 411);
            this.tasta470.Name = "tasta470";
            this.tasta470.Size = new System.Drawing.Size(13, 21);
            this.tasta470.TabIndex = 802;
            // 
            // tasta471
            // 
            this.tasta471.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta471.Location = new System.Drawing.Point(118, 411);
            this.tasta471.Name = "tasta471";
            this.tasta471.Size = new System.Drawing.Size(13, 21);
            this.tasta471.TabIndex = 801;
            // 
            // tasta472
            // 
            this.tasta472.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta472.Location = new System.Drawing.Point(99, 411);
            this.tasta472.Name = "tasta472";
            this.tasta472.Size = new System.Drawing.Size(13, 21);
            this.tasta472.TabIndex = 800;
            // 
            // tasta473
            // 
            this.tasta473.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta473.Location = new System.Drawing.Point(80, 411);
            this.tasta473.Name = "tasta473";
            this.tasta473.Size = new System.Drawing.Size(13, 21);
            this.tasta473.TabIndex = 799;
            // 
            // tasta474
            // 
            this.tasta474.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta474.Location = new System.Drawing.Point(61, 411);
            this.tasta474.Name = "tasta474";
            this.tasta474.Size = new System.Drawing.Size(13, 21);
            this.tasta474.TabIndex = 798;
            // 
            // tasta475
            // 
            this.tasta475.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta475.Location = new System.Drawing.Point(42, 411);
            this.tasta475.Name = "tasta475";
            this.tasta475.Size = new System.Drawing.Size(13, 21);
            this.tasta475.TabIndex = 797;
            // 
            // tasta476
            // 
            this.tasta476.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta476.Location = new System.Drawing.Point(23, 411);
            this.tasta476.Name = "tasta476";
            this.tasta476.Size = new System.Drawing.Size(13, 21);
            this.tasta476.TabIndex = 796;
            // 
            // tasta477
            // 
            this.tasta477.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta477.Location = new System.Drawing.Point(4, 411);
            this.tasta477.Name = "tasta477";
            this.tasta477.Size = new System.Drawing.Size(13, 21);
            this.tasta477.TabIndex = 795;
            // 
            // tasta478
            // 
            this.tasta478.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta478.Location = new System.Drawing.Point(993, 384);
            this.tasta478.Name = "tasta478";
            this.tasta478.Size = new System.Drawing.Size(13, 21);
            this.tasta478.TabIndex = 794;
            // 
            // tasta479
            // 
            this.tasta479.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta479.Location = new System.Drawing.Point(974, 384);
            this.tasta479.Name = "tasta479";
            this.tasta479.Size = new System.Drawing.Size(13, 21);
            this.tasta479.TabIndex = 793;
            // 
            // tasta480
            // 
            this.tasta480.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta480.Location = new System.Drawing.Point(955, 384);
            this.tasta480.Name = "tasta480";
            this.tasta480.Size = new System.Drawing.Size(13, 21);
            this.tasta480.TabIndex = 792;
            // 
            // tasta481
            // 
            this.tasta481.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta481.Location = new System.Drawing.Point(936, 384);
            this.tasta481.Name = "tasta481";
            this.tasta481.Size = new System.Drawing.Size(13, 21);
            this.tasta481.TabIndex = 791;
            // 
            // tasta482
            // 
            this.tasta482.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta482.Location = new System.Drawing.Point(917, 384);
            this.tasta482.Name = "tasta482";
            this.tasta482.Size = new System.Drawing.Size(13, 21);
            this.tasta482.TabIndex = 790;
            // 
            // tasta483
            // 
            this.tasta483.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta483.Location = new System.Drawing.Point(897, 384);
            this.tasta483.Name = "tasta483";
            this.tasta483.Size = new System.Drawing.Size(13, 21);
            this.tasta483.TabIndex = 789;
            // 
            // tasta484
            // 
            this.tasta484.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta484.Location = new System.Drawing.Point(878, 384);
            this.tasta484.Name = "tasta484";
            this.tasta484.Size = new System.Drawing.Size(13, 21);
            this.tasta484.TabIndex = 788;
            // 
            // tasta485
            // 
            this.tasta485.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta485.Location = new System.Drawing.Point(859, 384);
            this.tasta485.Name = "tasta485";
            this.tasta485.Size = new System.Drawing.Size(13, 21);
            this.tasta485.TabIndex = 787;
            // 
            // tasta486
            // 
            this.tasta486.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta486.Location = new System.Drawing.Point(840, 384);
            this.tasta486.Name = "tasta486";
            this.tasta486.Size = new System.Drawing.Size(13, 21);
            this.tasta486.TabIndex = 786;
            // 
            // tasta487
            // 
            this.tasta487.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta487.Location = new System.Drawing.Point(821, 384);
            this.tasta487.Name = "tasta487";
            this.tasta487.Size = new System.Drawing.Size(13, 21);
            this.tasta487.TabIndex = 785;
            // 
            // tasta488
            // 
            this.tasta488.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta488.Location = new System.Drawing.Point(802, 384);
            this.tasta488.Name = "tasta488";
            this.tasta488.Size = new System.Drawing.Size(13, 21);
            this.tasta488.TabIndex = 784;
            // 
            // tasta489
            // 
            this.tasta489.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta489.Location = new System.Drawing.Point(783, 384);
            this.tasta489.Name = "tasta489";
            this.tasta489.Size = new System.Drawing.Size(13, 21);
            this.tasta489.TabIndex = 783;
            // 
            // tasta490
            // 
            this.tasta490.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta490.Location = new System.Drawing.Point(764, 384);
            this.tasta490.Name = "tasta490";
            this.tasta490.Size = new System.Drawing.Size(13, 21);
            this.tasta490.TabIndex = 782;
            // 
            // tasta491
            // 
            this.tasta491.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta491.Location = new System.Drawing.Point(745, 384);
            this.tasta491.Name = "tasta491";
            this.tasta491.Size = new System.Drawing.Size(13, 21);
            this.tasta491.TabIndex = 781;
            // 
            // tasta492
            // 
            this.tasta492.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta492.Location = new System.Drawing.Point(726, 384);
            this.tasta492.Name = "tasta492";
            this.tasta492.Size = new System.Drawing.Size(13, 21);
            this.tasta492.TabIndex = 780;
            // 
            // tasta493
            // 
            this.tasta493.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta493.Location = new System.Drawing.Point(707, 384);
            this.tasta493.Name = "tasta493";
            this.tasta493.Size = new System.Drawing.Size(13, 21);
            this.tasta493.TabIndex = 779;
            // 
            // tasta494
            // 
            this.tasta494.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta494.Location = new System.Drawing.Point(688, 384);
            this.tasta494.Name = "tasta494";
            this.tasta494.Size = new System.Drawing.Size(13, 21);
            this.tasta494.TabIndex = 778;
            // 
            // tasta495
            // 
            this.tasta495.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta495.Location = new System.Drawing.Point(669, 384);
            this.tasta495.Name = "tasta495";
            this.tasta495.Size = new System.Drawing.Size(13, 21);
            this.tasta495.TabIndex = 777;
            // 
            // tasta496
            // 
            this.tasta496.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta496.Location = new System.Drawing.Point(650, 384);
            this.tasta496.Name = "tasta496";
            this.tasta496.Size = new System.Drawing.Size(13, 21);
            this.tasta496.TabIndex = 776;
            // 
            // tasta497
            // 
            this.tasta497.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta497.Location = new System.Drawing.Point(631, 384);
            this.tasta497.Name = "tasta497";
            this.tasta497.Size = new System.Drawing.Size(13, 21);
            this.tasta497.TabIndex = 775;
            // 
            // tasta498
            // 
            this.tasta498.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta498.Location = new System.Drawing.Point(612, 384);
            this.tasta498.Name = "tasta498";
            this.tasta498.Size = new System.Drawing.Size(13, 21);
            this.tasta498.TabIndex = 774;
            // 
            // tasta499
            // 
            this.tasta499.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta499.Location = new System.Drawing.Point(593, 384);
            this.tasta499.Name = "tasta499";
            this.tasta499.Size = new System.Drawing.Size(13, 21);
            this.tasta499.TabIndex = 773;
            // 
            // tasta500
            // 
            this.tasta500.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta500.Location = new System.Drawing.Point(574, 384);
            this.tasta500.Name = "tasta500";
            this.tasta500.Size = new System.Drawing.Size(13, 21);
            this.tasta500.TabIndex = 772;
            // 
            // tasta501
            // 
            this.tasta501.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta501.Location = new System.Drawing.Point(555, 384);
            this.tasta501.Name = "tasta501";
            this.tasta501.Size = new System.Drawing.Size(13, 21);
            this.tasta501.TabIndex = 771;
            // 
            // tasta502
            // 
            this.tasta502.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta502.Location = new System.Drawing.Point(536, 384);
            this.tasta502.Name = "tasta502";
            this.tasta502.Size = new System.Drawing.Size(13, 21);
            this.tasta502.TabIndex = 770;
            // 
            // tasta503
            // 
            this.tasta503.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta503.Location = new System.Drawing.Point(517, 384);
            this.tasta503.Name = "tasta503";
            this.tasta503.Size = new System.Drawing.Size(13, 21);
            this.tasta503.TabIndex = 769;
            // 
            // tasta504
            // 
            this.tasta504.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta504.Location = new System.Drawing.Point(498, 384);
            this.tasta504.Name = "tasta504";
            this.tasta504.Size = new System.Drawing.Size(13, 21);
            this.tasta504.TabIndex = 768;
            // 
            // tasta505
            // 
            this.tasta505.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta505.Location = new System.Drawing.Point(479, 384);
            this.tasta505.Name = "tasta505";
            this.tasta505.Size = new System.Drawing.Size(13, 21);
            this.tasta505.TabIndex = 767;
            // 
            // tasta506
            // 
            this.tasta506.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta506.Location = new System.Drawing.Point(460, 384);
            this.tasta506.Name = "tasta506";
            this.tasta506.Size = new System.Drawing.Size(13, 21);
            this.tasta506.TabIndex = 766;
            // 
            // tasta507
            // 
            this.tasta507.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta507.Location = new System.Drawing.Point(441, 384);
            this.tasta507.Name = "tasta507";
            this.tasta507.Size = new System.Drawing.Size(13, 21);
            this.tasta507.TabIndex = 765;
            // 
            // tasta508
            // 
            this.tasta508.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta508.Location = new System.Drawing.Point(422, 384);
            this.tasta508.Name = "tasta508";
            this.tasta508.Size = new System.Drawing.Size(13, 21);
            this.tasta508.TabIndex = 764;
            // 
            // tasta509
            // 
            this.tasta509.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta509.Location = new System.Drawing.Point(403, 384);
            this.tasta509.Name = "tasta509";
            this.tasta509.Size = new System.Drawing.Size(13, 21);
            this.tasta509.TabIndex = 763;
            // 
            // tasta510
            // 
            this.tasta510.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta510.Location = new System.Drawing.Point(384, 384);
            this.tasta510.Name = "tasta510";
            this.tasta510.Size = new System.Drawing.Size(13, 21);
            this.tasta510.TabIndex = 762;
            // 
            // tasta511
            // 
            this.tasta511.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta511.Location = new System.Drawing.Point(365, 384);
            this.tasta511.Name = "tasta511";
            this.tasta511.Size = new System.Drawing.Size(13, 21);
            this.tasta511.TabIndex = 761;
            // 
            // tasta512
            // 
            this.tasta512.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta512.Location = new System.Drawing.Point(346, 384);
            this.tasta512.Name = "tasta512";
            this.tasta512.Size = new System.Drawing.Size(13, 21);
            this.tasta512.TabIndex = 760;
            // 
            // tasta513
            // 
            this.tasta513.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta513.Location = new System.Drawing.Point(327, 384);
            this.tasta513.Name = "tasta513";
            this.tasta513.Size = new System.Drawing.Size(13, 21);
            this.tasta513.TabIndex = 759;
            // 
            // tasta514
            // 
            this.tasta514.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta514.Location = new System.Drawing.Point(308, 384);
            this.tasta514.Name = "tasta514";
            this.tasta514.Size = new System.Drawing.Size(13, 21);
            this.tasta514.TabIndex = 758;
            // 
            // tasta515
            // 
            this.tasta515.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta515.Location = new System.Drawing.Point(289, 384);
            this.tasta515.Name = "tasta515";
            this.tasta515.Size = new System.Drawing.Size(13, 21);
            this.tasta515.TabIndex = 757;
            // 
            // tasta516
            // 
            this.tasta516.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta516.Location = new System.Drawing.Point(270, 384);
            this.tasta516.Name = "tasta516";
            this.tasta516.Size = new System.Drawing.Size(13, 21);
            this.tasta516.TabIndex = 756;
            // 
            // tasta517
            // 
            this.tasta517.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta517.Location = new System.Drawing.Point(251, 384);
            this.tasta517.Name = "tasta517";
            this.tasta517.Size = new System.Drawing.Size(13, 21);
            this.tasta517.TabIndex = 755;
            // 
            // tasta518
            // 
            this.tasta518.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta518.Location = new System.Drawing.Point(232, 384);
            this.tasta518.Name = "tasta518";
            this.tasta518.Size = new System.Drawing.Size(13, 21);
            this.tasta518.TabIndex = 754;
            // 
            // tasta519
            // 
            this.tasta519.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta519.Location = new System.Drawing.Point(213, 384);
            this.tasta519.Name = "tasta519";
            this.tasta519.Size = new System.Drawing.Size(13, 21);
            this.tasta519.TabIndex = 753;
            // 
            // tasta520
            // 
            this.tasta520.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta520.Location = new System.Drawing.Point(194, 384);
            this.tasta520.Name = "tasta520";
            this.tasta520.Size = new System.Drawing.Size(13, 21);
            this.tasta520.TabIndex = 752;
            // 
            // tasta521
            // 
            this.tasta521.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta521.Location = new System.Drawing.Point(175, 384);
            this.tasta521.Name = "tasta521";
            this.tasta521.Size = new System.Drawing.Size(13, 21);
            this.tasta521.TabIndex = 751;
            // 
            // tasta522
            // 
            this.tasta522.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta522.Location = new System.Drawing.Point(156, 384);
            this.tasta522.Name = "tasta522";
            this.tasta522.Size = new System.Drawing.Size(13, 21);
            this.tasta522.TabIndex = 750;
            // 
            // tasta523
            // 
            this.tasta523.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta523.Location = new System.Drawing.Point(137, 384);
            this.tasta523.Name = "tasta523";
            this.tasta523.Size = new System.Drawing.Size(13, 21);
            this.tasta523.TabIndex = 749;
            // 
            // tasta524
            // 
            this.tasta524.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta524.Location = new System.Drawing.Point(118, 384);
            this.tasta524.Name = "tasta524";
            this.tasta524.Size = new System.Drawing.Size(13, 21);
            this.tasta524.TabIndex = 748;
            // 
            // tasta525
            // 
            this.tasta525.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta525.Location = new System.Drawing.Point(99, 384);
            this.tasta525.Name = "tasta525";
            this.tasta525.Size = new System.Drawing.Size(13, 21);
            this.tasta525.TabIndex = 747;
            // 
            // tasta526
            // 
            this.tasta526.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta526.Location = new System.Drawing.Point(80, 384);
            this.tasta526.Name = "tasta526";
            this.tasta526.Size = new System.Drawing.Size(13, 21);
            this.tasta526.TabIndex = 746;
            // 
            // tasta527
            // 
            this.tasta527.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta527.Location = new System.Drawing.Point(61, 384);
            this.tasta527.Name = "tasta527";
            this.tasta527.Size = new System.Drawing.Size(13, 21);
            this.tasta527.TabIndex = 745;
            // 
            // tasta528
            // 
            this.tasta528.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta528.Location = new System.Drawing.Point(42, 384);
            this.tasta528.Name = "tasta528";
            this.tasta528.Size = new System.Drawing.Size(13, 21);
            this.tasta528.TabIndex = 744;
            // 
            // tasta529
            // 
            this.tasta529.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta529.Location = new System.Drawing.Point(23, 384);
            this.tasta529.Name = "tasta529";
            this.tasta529.Size = new System.Drawing.Size(13, 21);
            this.tasta529.TabIndex = 743;
            // 
            // tasta530
            // 
            this.tasta530.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta530.Location = new System.Drawing.Point(4, 384);
            this.tasta530.Name = "tasta530";
            this.tasta530.Size = new System.Drawing.Size(13, 21);
            this.tasta530.TabIndex = 742;
            // 
            // tasta531
            // 
            this.tasta531.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta531.Location = new System.Drawing.Point(993, 357);
            this.tasta531.Name = "tasta531";
            this.tasta531.Size = new System.Drawing.Size(13, 21);
            this.tasta531.TabIndex = 741;
            // 
            // tasta532
            // 
            this.tasta532.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta532.Location = new System.Drawing.Point(974, 357);
            this.tasta532.Name = "tasta532";
            this.tasta532.Size = new System.Drawing.Size(13, 21);
            this.tasta532.TabIndex = 740;
            // 
            // tasta533
            // 
            this.tasta533.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta533.Location = new System.Drawing.Point(955, 357);
            this.tasta533.Name = "tasta533";
            this.tasta533.Size = new System.Drawing.Size(13, 21);
            this.tasta533.TabIndex = 739;
            // 
            // tasta534
            // 
            this.tasta534.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta534.Location = new System.Drawing.Point(936, 357);
            this.tasta534.Name = "tasta534";
            this.tasta534.Size = new System.Drawing.Size(13, 21);
            this.tasta534.TabIndex = 738;
            // 
            // tasta535
            // 
            this.tasta535.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta535.Location = new System.Drawing.Point(917, 357);
            this.tasta535.Name = "tasta535";
            this.tasta535.Size = new System.Drawing.Size(13, 21);
            this.tasta535.TabIndex = 737;
            // 
            // tasta536
            // 
            this.tasta536.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta536.Location = new System.Drawing.Point(897, 357);
            this.tasta536.Name = "tasta536";
            this.tasta536.Size = new System.Drawing.Size(13, 21);
            this.tasta536.TabIndex = 736;
            // 
            // tasta537
            // 
            this.tasta537.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta537.Location = new System.Drawing.Point(878, 357);
            this.tasta537.Name = "tasta537";
            this.tasta537.Size = new System.Drawing.Size(13, 21);
            this.tasta537.TabIndex = 735;
            // 
            // tasta538
            // 
            this.tasta538.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta538.Location = new System.Drawing.Point(859, 357);
            this.tasta538.Name = "tasta538";
            this.tasta538.Size = new System.Drawing.Size(13, 21);
            this.tasta538.TabIndex = 734;
            // 
            // tasta539
            // 
            this.tasta539.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta539.Location = new System.Drawing.Point(840, 357);
            this.tasta539.Name = "tasta539";
            this.tasta539.Size = new System.Drawing.Size(13, 21);
            this.tasta539.TabIndex = 733;
            // 
            // tasta540
            // 
            this.tasta540.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta540.Location = new System.Drawing.Point(821, 357);
            this.tasta540.Name = "tasta540";
            this.tasta540.Size = new System.Drawing.Size(13, 21);
            this.tasta540.TabIndex = 732;
            // 
            // tasta541
            // 
            this.tasta541.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta541.Location = new System.Drawing.Point(802, 357);
            this.tasta541.Name = "tasta541";
            this.tasta541.Size = new System.Drawing.Size(13, 21);
            this.tasta541.TabIndex = 731;
            // 
            // tasta542
            // 
            this.tasta542.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta542.Location = new System.Drawing.Point(783, 357);
            this.tasta542.Name = "tasta542";
            this.tasta542.Size = new System.Drawing.Size(13, 21);
            this.tasta542.TabIndex = 730;
            // 
            // tasta543
            // 
            this.tasta543.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta543.Location = new System.Drawing.Point(764, 357);
            this.tasta543.Name = "tasta543";
            this.tasta543.Size = new System.Drawing.Size(13, 21);
            this.tasta543.TabIndex = 729;
            // 
            // tasta544
            // 
            this.tasta544.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta544.Location = new System.Drawing.Point(745, 357);
            this.tasta544.Name = "tasta544";
            this.tasta544.Size = new System.Drawing.Size(13, 21);
            this.tasta544.TabIndex = 728;
            // 
            // tasta545
            // 
            this.tasta545.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta545.Location = new System.Drawing.Point(726, 357);
            this.tasta545.Name = "tasta545";
            this.tasta545.Size = new System.Drawing.Size(13, 21);
            this.tasta545.TabIndex = 727;
            // 
            // tasta546
            // 
            this.tasta546.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta546.Location = new System.Drawing.Point(707, 357);
            this.tasta546.Name = "tasta546";
            this.tasta546.Size = new System.Drawing.Size(13, 21);
            this.tasta546.TabIndex = 726;
            // 
            // tasta547
            // 
            this.tasta547.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta547.Location = new System.Drawing.Point(688, 357);
            this.tasta547.Name = "tasta547";
            this.tasta547.Size = new System.Drawing.Size(13, 21);
            this.tasta547.TabIndex = 725;
            // 
            // tasta548
            // 
            this.tasta548.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta548.Location = new System.Drawing.Point(669, 357);
            this.tasta548.Name = "tasta548";
            this.tasta548.Size = new System.Drawing.Size(13, 21);
            this.tasta548.TabIndex = 724;
            // 
            // tasta549
            // 
            this.tasta549.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta549.Location = new System.Drawing.Point(650, 357);
            this.tasta549.Name = "tasta549";
            this.tasta549.Size = new System.Drawing.Size(13, 21);
            this.tasta549.TabIndex = 723;
            // 
            // tasta550
            // 
            this.tasta550.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta550.Location = new System.Drawing.Point(631, 357);
            this.tasta550.Name = "tasta550";
            this.tasta550.Size = new System.Drawing.Size(13, 21);
            this.tasta550.TabIndex = 722;
            // 
            // tasta551
            // 
            this.tasta551.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta551.Location = new System.Drawing.Point(612, 357);
            this.tasta551.Name = "tasta551";
            this.tasta551.Size = new System.Drawing.Size(13, 21);
            this.tasta551.TabIndex = 721;
            // 
            // tasta552
            // 
            this.tasta552.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta552.Location = new System.Drawing.Point(593, 357);
            this.tasta552.Name = "tasta552";
            this.tasta552.Size = new System.Drawing.Size(13, 21);
            this.tasta552.TabIndex = 720;
            // 
            // tasta553
            // 
            this.tasta553.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta553.Location = new System.Drawing.Point(574, 357);
            this.tasta553.Name = "tasta553";
            this.tasta553.Size = new System.Drawing.Size(13, 21);
            this.tasta553.TabIndex = 719;
            // 
            // tasta554
            // 
            this.tasta554.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta554.Location = new System.Drawing.Point(555, 357);
            this.tasta554.Name = "tasta554";
            this.tasta554.Size = new System.Drawing.Size(13, 21);
            this.tasta554.TabIndex = 718;
            // 
            // tasta555
            // 
            this.tasta555.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta555.Location = new System.Drawing.Point(536, 357);
            this.tasta555.Name = "tasta555";
            this.tasta555.Size = new System.Drawing.Size(13, 21);
            this.tasta555.TabIndex = 717;
            // 
            // tasta556
            // 
            this.tasta556.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta556.Location = new System.Drawing.Point(517, 357);
            this.tasta556.Name = "tasta556";
            this.tasta556.Size = new System.Drawing.Size(13, 21);
            this.tasta556.TabIndex = 716;
            // 
            // tasta557
            // 
            this.tasta557.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta557.Location = new System.Drawing.Point(498, 357);
            this.tasta557.Name = "tasta557";
            this.tasta557.Size = new System.Drawing.Size(13, 21);
            this.tasta557.TabIndex = 715;
            // 
            // tasta558
            // 
            this.tasta558.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta558.Location = new System.Drawing.Point(479, 357);
            this.tasta558.Name = "tasta558";
            this.tasta558.Size = new System.Drawing.Size(13, 21);
            this.tasta558.TabIndex = 714;
            // 
            // tasta559
            // 
            this.tasta559.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta559.Location = new System.Drawing.Point(460, 357);
            this.tasta559.Name = "tasta559";
            this.tasta559.Size = new System.Drawing.Size(13, 21);
            this.tasta559.TabIndex = 713;
            // 
            // tasta560
            // 
            this.tasta560.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta560.Location = new System.Drawing.Point(441, 357);
            this.tasta560.Name = "tasta560";
            this.tasta560.Size = new System.Drawing.Size(13, 21);
            this.tasta560.TabIndex = 712;
            // 
            // tasta561
            // 
            this.tasta561.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta561.Location = new System.Drawing.Point(422, 357);
            this.tasta561.Name = "tasta561";
            this.tasta561.Size = new System.Drawing.Size(13, 21);
            this.tasta561.TabIndex = 711;
            // 
            // tasta562
            // 
            this.tasta562.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta562.Location = new System.Drawing.Point(403, 357);
            this.tasta562.Name = "tasta562";
            this.tasta562.Size = new System.Drawing.Size(13, 21);
            this.tasta562.TabIndex = 710;
            // 
            // tasta563
            // 
            this.tasta563.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta563.Location = new System.Drawing.Point(384, 357);
            this.tasta563.Name = "tasta563";
            this.tasta563.Size = new System.Drawing.Size(13, 21);
            this.tasta563.TabIndex = 709;
            // 
            // tasta564
            // 
            this.tasta564.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta564.Location = new System.Drawing.Point(365, 357);
            this.tasta564.Name = "tasta564";
            this.tasta564.Size = new System.Drawing.Size(13, 21);
            this.tasta564.TabIndex = 708;
            // 
            // tasta565
            // 
            this.tasta565.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta565.Location = new System.Drawing.Point(346, 357);
            this.tasta565.Name = "tasta565";
            this.tasta565.Size = new System.Drawing.Size(13, 21);
            this.tasta565.TabIndex = 707;
            // 
            // tasta566
            // 
            this.tasta566.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta566.Location = new System.Drawing.Point(327, 357);
            this.tasta566.Name = "tasta566";
            this.tasta566.Size = new System.Drawing.Size(13, 21);
            this.tasta566.TabIndex = 706;
            // 
            // tasta567
            // 
            this.tasta567.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta567.Location = new System.Drawing.Point(308, 357);
            this.tasta567.Name = "tasta567";
            this.tasta567.Size = new System.Drawing.Size(13, 21);
            this.tasta567.TabIndex = 705;
            // 
            // tasta568
            // 
            this.tasta568.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta568.Location = new System.Drawing.Point(289, 357);
            this.tasta568.Name = "tasta568";
            this.tasta568.Size = new System.Drawing.Size(13, 21);
            this.tasta568.TabIndex = 704;
            // 
            // tasta569
            // 
            this.tasta569.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta569.Location = new System.Drawing.Point(270, 357);
            this.tasta569.Name = "tasta569";
            this.tasta569.Size = new System.Drawing.Size(13, 21);
            this.tasta569.TabIndex = 703;
            // 
            // tasta570
            // 
            this.tasta570.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta570.Location = new System.Drawing.Point(251, 357);
            this.tasta570.Name = "tasta570";
            this.tasta570.Size = new System.Drawing.Size(13, 21);
            this.tasta570.TabIndex = 702;
            // 
            // tasta571
            // 
            this.tasta571.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta571.Location = new System.Drawing.Point(232, 357);
            this.tasta571.Name = "tasta571";
            this.tasta571.Size = new System.Drawing.Size(13, 21);
            this.tasta571.TabIndex = 701;
            // 
            // tasta572
            // 
            this.tasta572.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta572.Location = new System.Drawing.Point(213, 357);
            this.tasta572.Name = "tasta572";
            this.tasta572.Size = new System.Drawing.Size(13, 21);
            this.tasta572.TabIndex = 700;
            // 
            // tasta573
            // 
            this.tasta573.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta573.Location = new System.Drawing.Point(194, 357);
            this.tasta573.Name = "tasta573";
            this.tasta573.Size = new System.Drawing.Size(13, 21);
            this.tasta573.TabIndex = 699;
            // 
            // tasta574
            // 
            this.tasta574.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta574.Location = new System.Drawing.Point(175, 357);
            this.tasta574.Name = "tasta574";
            this.tasta574.Size = new System.Drawing.Size(13, 21);
            this.tasta574.TabIndex = 698;
            // 
            // tasta575
            // 
            this.tasta575.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta575.Location = new System.Drawing.Point(156, 357);
            this.tasta575.Name = "tasta575";
            this.tasta575.Size = new System.Drawing.Size(13, 21);
            this.tasta575.TabIndex = 697;
            // 
            // tasta576
            // 
            this.tasta576.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta576.Location = new System.Drawing.Point(137, 357);
            this.tasta576.Name = "tasta576";
            this.tasta576.Size = new System.Drawing.Size(13, 21);
            this.tasta576.TabIndex = 696;
            // 
            // tasta577
            // 
            this.tasta577.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta577.Location = new System.Drawing.Point(118, 357);
            this.tasta577.Name = "tasta577";
            this.tasta577.Size = new System.Drawing.Size(13, 21);
            this.tasta577.TabIndex = 695;
            // 
            // tasta578
            // 
            this.tasta578.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta578.Location = new System.Drawing.Point(99, 357);
            this.tasta578.Name = "tasta578";
            this.tasta578.Size = new System.Drawing.Size(13, 21);
            this.tasta578.TabIndex = 694;
            // 
            // tasta579
            // 
            this.tasta579.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta579.Location = new System.Drawing.Point(80, 357);
            this.tasta579.Name = "tasta579";
            this.tasta579.Size = new System.Drawing.Size(13, 21);
            this.tasta579.TabIndex = 693;
            // 
            // tasta580
            // 
            this.tasta580.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta580.Location = new System.Drawing.Point(61, 357);
            this.tasta580.Name = "tasta580";
            this.tasta580.Size = new System.Drawing.Size(13, 21);
            this.tasta580.TabIndex = 692;
            // 
            // tasta581
            // 
            this.tasta581.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta581.Location = new System.Drawing.Point(42, 357);
            this.tasta581.Name = "tasta581";
            this.tasta581.Size = new System.Drawing.Size(13, 21);
            this.tasta581.TabIndex = 691;
            // 
            // tasta582
            // 
            this.tasta582.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta582.Location = new System.Drawing.Point(23, 357);
            this.tasta582.Name = "tasta582";
            this.tasta582.Size = new System.Drawing.Size(13, 21);
            this.tasta582.TabIndex = 690;
            // 
            // tasta583
            // 
            this.tasta583.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta583.Location = new System.Drawing.Point(4, 357);
            this.tasta583.Name = "tasta583";
            this.tasta583.Size = new System.Drawing.Size(13, 21);
            this.tasta583.TabIndex = 689;
            // 
            // tasta584
            // 
            this.tasta584.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta584.Location = new System.Drawing.Point(993, 330);
            this.tasta584.Name = "tasta584";
            this.tasta584.Size = new System.Drawing.Size(13, 21);
            this.tasta584.TabIndex = 688;
            // 
            // tasta585
            // 
            this.tasta585.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta585.Location = new System.Drawing.Point(974, 330);
            this.tasta585.Name = "tasta585";
            this.tasta585.Size = new System.Drawing.Size(13, 21);
            this.tasta585.TabIndex = 687;
            // 
            // tasta586
            // 
            this.tasta586.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta586.Location = new System.Drawing.Point(955, 330);
            this.tasta586.Name = "tasta586";
            this.tasta586.Size = new System.Drawing.Size(13, 21);
            this.tasta586.TabIndex = 686;
            // 
            // tasta587
            // 
            this.tasta587.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta587.Location = new System.Drawing.Point(936, 330);
            this.tasta587.Name = "tasta587";
            this.tasta587.Size = new System.Drawing.Size(13, 21);
            this.tasta587.TabIndex = 685;
            // 
            // tasta588
            // 
            this.tasta588.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta588.Location = new System.Drawing.Point(917, 330);
            this.tasta588.Name = "tasta588";
            this.tasta588.Size = new System.Drawing.Size(13, 21);
            this.tasta588.TabIndex = 684;
            // 
            // tasta589
            // 
            this.tasta589.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta589.Location = new System.Drawing.Point(897, 330);
            this.tasta589.Name = "tasta589";
            this.tasta589.Size = new System.Drawing.Size(13, 21);
            this.tasta589.TabIndex = 683;
            // 
            // tasta590
            // 
            this.tasta590.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta590.Location = new System.Drawing.Point(878, 330);
            this.tasta590.Name = "tasta590";
            this.tasta590.Size = new System.Drawing.Size(13, 21);
            this.tasta590.TabIndex = 682;
            // 
            // tasta591
            // 
            this.tasta591.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta591.Location = new System.Drawing.Point(859, 330);
            this.tasta591.Name = "tasta591";
            this.tasta591.Size = new System.Drawing.Size(13, 21);
            this.tasta591.TabIndex = 681;
            // 
            // tasta592
            // 
            this.tasta592.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta592.Location = new System.Drawing.Point(840, 330);
            this.tasta592.Name = "tasta592";
            this.tasta592.Size = new System.Drawing.Size(13, 21);
            this.tasta592.TabIndex = 680;
            // 
            // tasta593
            // 
            this.tasta593.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta593.Location = new System.Drawing.Point(821, 330);
            this.tasta593.Name = "tasta593";
            this.tasta593.Size = new System.Drawing.Size(13, 21);
            this.tasta593.TabIndex = 679;
            // 
            // tasta594
            // 
            this.tasta594.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta594.Location = new System.Drawing.Point(802, 330);
            this.tasta594.Name = "tasta594";
            this.tasta594.Size = new System.Drawing.Size(13, 21);
            this.tasta594.TabIndex = 678;
            // 
            // tasta595
            // 
            this.tasta595.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta595.Location = new System.Drawing.Point(783, 330);
            this.tasta595.Name = "tasta595";
            this.tasta595.Size = new System.Drawing.Size(13, 21);
            this.tasta595.TabIndex = 677;
            // 
            // tasta596
            // 
            this.tasta596.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta596.Location = new System.Drawing.Point(764, 330);
            this.tasta596.Name = "tasta596";
            this.tasta596.Size = new System.Drawing.Size(13, 21);
            this.tasta596.TabIndex = 676;
            // 
            // tasta597
            // 
            this.tasta597.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta597.Location = new System.Drawing.Point(745, 330);
            this.tasta597.Name = "tasta597";
            this.tasta597.Size = new System.Drawing.Size(13, 21);
            this.tasta597.TabIndex = 675;
            // 
            // tasta598
            // 
            this.tasta598.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta598.Location = new System.Drawing.Point(726, 330);
            this.tasta598.Name = "tasta598";
            this.tasta598.Size = new System.Drawing.Size(13, 21);
            this.tasta598.TabIndex = 674;
            // 
            // tasta599
            // 
            this.tasta599.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta599.Location = new System.Drawing.Point(707, 330);
            this.tasta599.Name = "tasta599";
            this.tasta599.Size = new System.Drawing.Size(13, 21);
            this.tasta599.TabIndex = 673;
            // 
            // tasta600
            // 
            this.tasta600.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta600.Location = new System.Drawing.Point(688, 330);
            this.tasta600.Name = "tasta600";
            this.tasta600.Size = new System.Drawing.Size(13, 21);
            this.tasta600.TabIndex = 672;
            // 
            // tasta601
            // 
            this.tasta601.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta601.Location = new System.Drawing.Point(669, 330);
            this.tasta601.Name = "tasta601";
            this.tasta601.Size = new System.Drawing.Size(13, 21);
            this.tasta601.TabIndex = 671;
            // 
            // tasta602
            // 
            this.tasta602.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta602.Location = new System.Drawing.Point(650, 330);
            this.tasta602.Name = "tasta602";
            this.tasta602.Size = new System.Drawing.Size(13, 21);
            this.tasta602.TabIndex = 670;
            // 
            // tasta603
            // 
            this.tasta603.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta603.Location = new System.Drawing.Point(631, 330);
            this.tasta603.Name = "tasta603";
            this.tasta603.Size = new System.Drawing.Size(13, 21);
            this.tasta603.TabIndex = 669;
            // 
            // tasta604
            // 
            this.tasta604.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta604.Location = new System.Drawing.Point(612, 330);
            this.tasta604.Name = "tasta604";
            this.tasta604.Size = new System.Drawing.Size(13, 21);
            this.tasta604.TabIndex = 668;
            // 
            // tasta605
            // 
            this.tasta605.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta605.Location = new System.Drawing.Point(593, 330);
            this.tasta605.Name = "tasta605";
            this.tasta605.Size = new System.Drawing.Size(13, 21);
            this.tasta605.TabIndex = 667;
            // 
            // tasta606
            // 
            this.tasta606.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta606.Location = new System.Drawing.Point(574, 330);
            this.tasta606.Name = "tasta606";
            this.tasta606.Size = new System.Drawing.Size(13, 21);
            this.tasta606.TabIndex = 666;
            // 
            // tasta607
            // 
            this.tasta607.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta607.Location = new System.Drawing.Point(555, 330);
            this.tasta607.Name = "tasta607";
            this.tasta607.Size = new System.Drawing.Size(13, 21);
            this.tasta607.TabIndex = 665;
            // 
            // tasta608
            // 
            this.tasta608.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta608.Location = new System.Drawing.Point(536, 330);
            this.tasta608.Name = "tasta608";
            this.tasta608.Size = new System.Drawing.Size(13, 21);
            this.tasta608.TabIndex = 664;
            // 
            // tasta609
            // 
            this.tasta609.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta609.Location = new System.Drawing.Point(517, 330);
            this.tasta609.Name = "tasta609";
            this.tasta609.Size = new System.Drawing.Size(13, 21);
            this.tasta609.TabIndex = 663;
            // 
            // tasta610
            // 
            this.tasta610.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta610.Location = new System.Drawing.Point(498, 330);
            this.tasta610.Name = "tasta610";
            this.tasta610.Size = new System.Drawing.Size(13, 21);
            this.tasta610.TabIndex = 662;
            // 
            // tasta611
            // 
            this.tasta611.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta611.Location = new System.Drawing.Point(479, 330);
            this.tasta611.Name = "tasta611";
            this.tasta611.Size = new System.Drawing.Size(13, 21);
            this.tasta611.TabIndex = 661;
            // 
            // tasta612
            // 
            this.tasta612.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta612.Location = new System.Drawing.Point(460, 330);
            this.tasta612.Name = "tasta612";
            this.tasta612.Size = new System.Drawing.Size(13, 21);
            this.tasta612.TabIndex = 660;
            // 
            // tasta613
            // 
            this.tasta613.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta613.Location = new System.Drawing.Point(441, 330);
            this.tasta613.Name = "tasta613";
            this.tasta613.Size = new System.Drawing.Size(13, 21);
            this.tasta613.TabIndex = 659;
            // 
            // tasta614
            // 
            this.tasta614.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta614.Location = new System.Drawing.Point(422, 330);
            this.tasta614.Name = "tasta614";
            this.tasta614.Size = new System.Drawing.Size(13, 21);
            this.tasta614.TabIndex = 658;
            // 
            // tasta615
            // 
            this.tasta615.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta615.Location = new System.Drawing.Point(403, 330);
            this.tasta615.Name = "tasta615";
            this.tasta615.Size = new System.Drawing.Size(13, 21);
            this.tasta615.TabIndex = 657;
            // 
            // tasta616
            // 
            this.tasta616.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta616.Location = new System.Drawing.Point(384, 330);
            this.tasta616.Name = "tasta616";
            this.tasta616.Size = new System.Drawing.Size(13, 21);
            this.tasta616.TabIndex = 656;
            // 
            // tasta617
            // 
            this.tasta617.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta617.Location = new System.Drawing.Point(365, 330);
            this.tasta617.Name = "tasta617";
            this.tasta617.Size = new System.Drawing.Size(13, 21);
            this.tasta617.TabIndex = 655;
            // 
            // tasta618
            // 
            this.tasta618.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta618.Location = new System.Drawing.Point(346, 330);
            this.tasta618.Name = "tasta618";
            this.tasta618.Size = new System.Drawing.Size(13, 21);
            this.tasta618.TabIndex = 654;
            // 
            // tasta619
            // 
            this.tasta619.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta619.Location = new System.Drawing.Point(327, 330);
            this.tasta619.Name = "tasta619";
            this.tasta619.Size = new System.Drawing.Size(13, 21);
            this.tasta619.TabIndex = 653;
            // 
            // tasta620
            // 
            this.tasta620.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta620.Location = new System.Drawing.Point(308, 330);
            this.tasta620.Name = "tasta620";
            this.tasta620.Size = new System.Drawing.Size(13, 21);
            this.tasta620.TabIndex = 652;
            // 
            // tasta621
            // 
            this.tasta621.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta621.Location = new System.Drawing.Point(289, 330);
            this.tasta621.Name = "tasta621";
            this.tasta621.Size = new System.Drawing.Size(13, 21);
            this.tasta621.TabIndex = 651;
            // 
            // tasta622
            // 
            this.tasta622.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta622.Location = new System.Drawing.Point(270, 330);
            this.tasta622.Name = "tasta622";
            this.tasta622.Size = new System.Drawing.Size(13, 21);
            this.tasta622.TabIndex = 650;
            // 
            // tasta623
            // 
            this.tasta623.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta623.Location = new System.Drawing.Point(251, 330);
            this.tasta623.Name = "tasta623";
            this.tasta623.Size = new System.Drawing.Size(13, 21);
            this.tasta623.TabIndex = 649;
            // 
            // tasta624
            // 
            this.tasta624.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta624.Location = new System.Drawing.Point(232, 330);
            this.tasta624.Name = "tasta624";
            this.tasta624.Size = new System.Drawing.Size(13, 21);
            this.tasta624.TabIndex = 648;
            // 
            // tasta625
            // 
            this.tasta625.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta625.Location = new System.Drawing.Point(213, 330);
            this.tasta625.Name = "tasta625";
            this.tasta625.Size = new System.Drawing.Size(13, 21);
            this.tasta625.TabIndex = 647;
            // 
            // tasta626
            // 
            this.tasta626.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta626.Location = new System.Drawing.Point(194, 330);
            this.tasta626.Name = "tasta626";
            this.tasta626.Size = new System.Drawing.Size(13, 21);
            this.tasta626.TabIndex = 646;
            // 
            // tasta627
            // 
            this.tasta627.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta627.Location = new System.Drawing.Point(175, 330);
            this.tasta627.Name = "tasta627";
            this.tasta627.Size = new System.Drawing.Size(13, 21);
            this.tasta627.TabIndex = 645;
            // 
            // tasta628
            // 
            this.tasta628.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta628.Location = new System.Drawing.Point(156, 330);
            this.tasta628.Name = "tasta628";
            this.tasta628.Size = new System.Drawing.Size(13, 21);
            this.tasta628.TabIndex = 644;
            // 
            // tasta629
            // 
            this.tasta629.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta629.Location = new System.Drawing.Point(137, 330);
            this.tasta629.Name = "tasta629";
            this.tasta629.Size = new System.Drawing.Size(13, 21);
            this.tasta629.TabIndex = 643;
            // 
            // tasta630
            // 
            this.tasta630.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta630.Location = new System.Drawing.Point(118, 330);
            this.tasta630.Name = "tasta630";
            this.tasta630.Size = new System.Drawing.Size(13, 21);
            this.tasta630.TabIndex = 642;
            // 
            // tasta631
            // 
            this.tasta631.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta631.Location = new System.Drawing.Point(99, 330);
            this.tasta631.Name = "tasta631";
            this.tasta631.Size = new System.Drawing.Size(13, 21);
            this.tasta631.TabIndex = 641;
            // 
            // tasta632
            // 
            this.tasta632.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta632.Location = new System.Drawing.Point(80, 330);
            this.tasta632.Name = "tasta632";
            this.tasta632.Size = new System.Drawing.Size(13, 21);
            this.tasta632.TabIndex = 640;
            // 
            // tasta633
            // 
            this.tasta633.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta633.Location = new System.Drawing.Point(61, 330);
            this.tasta633.Name = "tasta633";
            this.tasta633.Size = new System.Drawing.Size(13, 21);
            this.tasta633.TabIndex = 639;
            // 
            // tasta634
            // 
            this.tasta634.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta634.Location = new System.Drawing.Point(42, 330);
            this.tasta634.Name = "tasta634";
            this.tasta634.Size = new System.Drawing.Size(13, 21);
            this.tasta634.TabIndex = 638;
            // 
            // tasta635
            // 
            this.tasta635.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta635.Location = new System.Drawing.Point(23, 330);
            this.tasta635.Name = "tasta635";
            this.tasta635.Size = new System.Drawing.Size(13, 21);
            this.tasta635.TabIndex = 637;
            // 
            // tasta636
            // 
            this.tasta636.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta636.Location = new System.Drawing.Point(4, 330);
            this.tasta636.Name = "tasta636";
            this.tasta636.Size = new System.Drawing.Size(13, 21);
            this.tasta636.TabIndex = 636;
            // 
            // tasta637
            // 
            this.tasta637.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta637.Location = new System.Drawing.Point(993, 303);
            this.tasta637.Name = "tasta637";
            this.tasta637.Size = new System.Drawing.Size(13, 21);
            this.tasta637.TabIndex = 635;
            // 
            // tasta638
            // 
            this.tasta638.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta638.Location = new System.Drawing.Point(974, 303);
            this.tasta638.Name = "tasta638";
            this.tasta638.Size = new System.Drawing.Size(13, 21);
            this.tasta638.TabIndex = 634;
            // 
            // tasta639
            // 
            this.tasta639.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta639.Location = new System.Drawing.Point(955, 303);
            this.tasta639.Name = "tasta639";
            this.tasta639.Size = new System.Drawing.Size(13, 21);
            this.tasta639.TabIndex = 633;
            // 
            // tasta640
            // 
            this.tasta640.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta640.Location = new System.Drawing.Point(936, 303);
            this.tasta640.Name = "tasta640";
            this.tasta640.Size = new System.Drawing.Size(13, 21);
            this.tasta640.TabIndex = 632;
            // 
            // tasta641
            // 
            this.tasta641.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta641.Location = new System.Drawing.Point(917, 303);
            this.tasta641.Name = "tasta641";
            this.tasta641.Size = new System.Drawing.Size(13, 21);
            this.tasta641.TabIndex = 631;
            // 
            // tasta642
            // 
            this.tasta642.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta642.Location = new System.Drawing.Point(897, 303);
            this.tasta642.Name = "tasta642";
            this.tasta642.Size = new System.Drawing.Size(13, 21);
            this.tasta642.TabIndex = 630;
            // 
            // tasta643
            // 
            this.tasta643.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta643.Location = new System.Drawing.Point(878, 303);
            this.tasta643.Name = "tasta643";
            this.tasta643.Size = new System.Drawing.Size(13, 21);
            this.tasta643.TabIndex = 629;
            // 
            // tasta644
            // 
            this.tasta644.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta644.Location = new System.Drawing.Point(859, 303);
            this.tasta644.Name = "tasta644";
            this.tasta644.Size = new System.Drawing.Size(13, 21);
            this.tasta644.TabIndex = 628;
            // 
            // tasta645
            // 
            this.tasta645.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta645.Location = new System.Drawing.Point(840, 303);
            this.tasta645.Name = "tasta645";
            this.tasta645.Size = new System.Drawing.Size(13, 21);
            this.tasta645.TabIndex = 627;
            // 
            // tasta646
            // 
            this.tasta646.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta646.Location = new System.Drawing.Point(821, 303);
            this.tasta646.Name = "tasta646";
            this.tasta646.Size = new System.Drawing.Size(13, 21);
            this.tasta646.TabIndex = 626;
            // 
            // tasta647
            // 
            this.tasta647.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta647.Location = new System.Drawing.Point(802, 303);
            this.tasta647.Name = "tasta647";
            this.tasta647.Size = new System.Drawing.Size(13, 21);
            this.tasta647.TabIndex = 625;
            // 
            // tasta648
            // 
            this.tasta648.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta648.Location = new System.Drawing.Point(783, 303);
            this.tasta648.Name = "tasta648";
            this.tasta648.Size = new System.Drawing.Size(13, 21);
            this.tasta648.TabIndex = 624;
            // 
            // tasta649
            // 
            this.tasta649.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta649.Location = new System.Drawing.Point(764, 303);
            this.tasta649.Name = "tasta649";
            this.tasta649.Size = new System.Drawing.Size(13, 21);
            this.tasta649.TabIndex = 623;
            // 
            // tasta650
            // 
            this.tasta650.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta650.Location = new System.Drawing.Point(745, 303);
            this.tasta650.Name = "tasta650";
            this.tasta650.Size = new System.Drawing.Size(13, 21);
            this.tasta650.TabIndex = 622;
            // 
            // tasta651
            // 
            this.tasta651.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta651.Location = new System.Drawing.Point(726, 303);
            this.tasta651.Name = "tasta651";
            this.tasta651.Size = new System.Drawing.Size(13, 21);
            this.tasta651.TabIndex = 621;
            // 
            // tasta652
            // 
            this.tasta652.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta652.Location = new System.Drawing.Point(707, 303);
            this.tasta652.Name = "tasta652";
            this.tasta652.Size = new System.Drawing.Size(13, 21);
            this.tasta652.TabIndex = 620;
            // 
            // tasta653
            // 
            this.tasta653.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta653.Location = new System.Drawing.Point(688, 303);
            this.tasta653.Name = "tasta653";
            this.tasta653.Size = new System.Drawing.Size(13, 21);
            this.tasta653.TabIndex = 619;
            // 
            // tasta654
            // 
            this.tasta654.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta654.Location = new System.Drawing.Point(669, 303);
            this.tasta654.Name = "tasta654";
            this.tasta654.Size = new System.Drawing.Size(13, 21);
            this.tasta654.TabIndex = 618;
            // 
            // tasta655
            // 
            this.tasta655.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta655.Location = new System.Drawing.Point(650, 303);
            this.tasta655.Name = "tasta655";
            this.tasta655.Size = new System.Drawing.Size(13, 21);
            this.tasta655.TabIndex = 617;
            // 
            // tasta656
            // 
            this.tasta656.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta656.Location = new System.Drawing.Point(631, 303);
            this.tasta656.Name = "tasta656";
            this.tasta656.Size = new System.Drawing.Size(13, 21);
            this.tasta656.TabIndex = 616;
            // 
            // tasta657
            // 
            this.tasta657.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta657.Location = new System.Drawing.Point(612, 303);
            this.tasta657.Name = "tasta657";
            this.tasta657.Size = new System.Drawing.Size(13, 21);
            this.tasta657.TabIndex = 615;
            // 
            // tasta658
            // 
            this.tasta658.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta658.Location = new System.Drawing.Point(593, 303);
            this.tasta658.Name = "tasta658";
            this.tasta658.Size = new System.Drawing.Size(13, 21);
            this.tasta658.TabIndex = 614;
            // 
            // tasta659
            // 
            this.tasta659.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta659.Location = new System.Drawing.Point(574, 303);
            this.tasta659.Name = "tasta659";
            this.tasta659.Size = new System.Drawing.Size(13, 21);
            this.tasta659.TabIndex = 613;
            // 
            // tasta660
            // 
            this.tasta660.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta660.Location = new System.Drawing.Point(555, 303);
            this.tasta660.Name = "tasta660";
            this.tasta660.Size = new System.Drawing.Size(13, 21);
            this.tasta660.TabIndex = 612;
            // 
            // tasta661
            // 
            this.tasta661.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta661.Location = new System.Drawing.Point(536, 303);
            this.tasta661.Name = "tasta661";
            this.tasta661.Size = new System.Drawing.Size(13, 21);
            this.tasta661.TabIndex = 611;
            // 
            // tasta662
            // 
            this.tasta662.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta662.Location = new System.Drawing.Point(517, 303);
            this.tasta662.Name = "tasta662";
            this.tasta662.Size = new System.Drawing.Size(13, 21);
            this.tasta662.TabIndex = 610;
            // 
            // tasta663
            // 
            this.tasta663.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta663.Location = new System.Drawing.Point(498, 303);
            this.tasta663.Name = "tasta663";
            this.tasta663.Size = new System.Drawing.Size(13, 21);
            this.tasta663.TabIndex = 609;
            // 
            // tasta664
            // 
            this.tasta664.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta664.Location = new System.Drawing.Point(479, 303);
            this.tasta664.Name = "tasta664";
            this.tasta664.Size = new System.Drawing.Size(13, 21);
            this.tasta664.TabIndex = 608;
            // 
            // tasta665
            // 
            this.tasta665.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta665.Location = new System.Drawing.Point(460, 303);
            this.tasta665.Name = "tasta665";
            this.tasta665.Size = new System.Drawing.Size(13, 21);
            this.tasta665.TabIndex = 607;
            // 
            // tasta666
            // 
            this.tasta666.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta666.Location = new System.Drawing.Point(441, 303);
            this.tasta666.Name = "tasta666";
            this.tasta666.Size = new System.Drawing.Size(13, 21);
            this.tasta666.TabIndex = 606;
            // 
            // tasta667
            // 
            this.tasta667.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta667.Location = new System.Drawing.Point(422, 303);
            this.tasta667.Name = "tasta667";
            this.tasta667.Size = new System.Drawing.Size(13, 21);
            this.tasta667.TabIndex = 605;
            // 
            // tasta668
            // 
            this.tasta668.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta668.Location = new System.Drawing.Point(403, 303);
            this.tasta668.Name = "tasta668";
            this.tasta668.Size = new System.Drawing.Size(13, 21);
            this.tasta668.TabIndex = 604;
            // 
            // tasta669
            // 
            this.tasta669.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta669.Location = new System.Drawing.Point(384, 303);
            this.tasta669.Name = "tasta669";
            this.tasta669.Size = new System.Drawing.Size(13, 21);
            this.tasta669.TabIndex = 603;
            // 
            // tasta670
            // 
            this.tasta670.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta670.Location = new System.Drawing.Point(365, 303);
            this.tasta670.Name = "tasta670";
            this.tasta670.Size = new System.Drawing.Size(13, 21);
            this.tasta670.TabIndex = 602;
            // 
            // tasta671
            // 
            this.tasta671.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta671.Location = new System.Drawing.Point(346, 303);
            this.tasta671.Name = "tasta671";
            this.tasta671.Size = new System.Drawing.Size(13, 21);
            this.tasta671.TabIndex = 601;
            // 
            // tasta672
            // 
            this.tasta672.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta672.Location = new System.Drawing.Point(327, 303);
            this.tasta672.Name = "tasta672";
            this.tasta672.Size = new System.Drawing.Size(13, 21);
            this.tasta672.TabIndex = 600;
            // 
            // tasta673
            // 
            this.tasta673.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta673.Location = new System.Drawing.Point(308, 303);
            this.tasta673.Name = "tasta673";
            this.tasta673.Size = new System.Drawing.Size(13, 21);
            this.tasta673.TabIndex = 599;
            // 
            // tasta674
            // 
            this.tasta674.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta674.Location = new System.Drawing.Point(289, 303);
            this.tasta674.Name = "tasta674";
            this.tasta674.Size = new System.Drawing.Size(13, 21);
            this.tasta674.TabIndex = 598;
            // 
            // tasta675
            // 
            this.tasta675.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta675.Location = new System.Drawing.Point(270, 303);
            this.tasta675.Name = "tasta675";
            this.tasta675.Size = new System.Drawing.Size(13, 21);
            this.tasta675.TabIndex = 597;
            // 
            // tasta676
            // 
            this.tasta676.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta676.Location = new System.Drawing.Point(251, 303);
            this.tasta676.Name = "tasta676";
            this.tasta676.Size = new System.Drawing.Size(13, 21);
            this.tasta676.TabIndex = 596;
            // 
            // tasta677
            // 
            this.tasta677.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta677.Location = new System.Drawing.Point(232, 303);
            this.tasta677.Name = "tasta677";
            this.tasta677.Size = new System.Drawing.Size(13, 21);
            this.tasta677.TabIndex = 595;
            // 
            // tasta678
            // 
            this.tasta678.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta678.Location = new System.Drawing.Point(213, 303);
            this.tasta678.Name = "tasta678";
            this.tasta678.Size = new System.Drawing.Size(13, 21);
            this.tasta678.TabIndex = 594;
            // 
            // tasta679
            // 
            this.tasta679.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta679.Location = new System.Drawing.Point(194, 303);
            this.tasta679.Name = "tasta679";
            this.tasta679.Size = new System.Drawing.Size(13, 21);
            this.tasta679.TabIndex = 593;
            // 
            // tasta680
            // 
            this.tasta680.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta680.Location = new System.Drawing.Point(175, 303);
            this.tasta680.Name = "tasta680";
            this.tasta680.Size = new System.Drawing.Size(13, 21);
            this.tasta680.TabIndex = 592;
            // 
            // tasta681
            // 
            this.tasta681.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta681.Location = new System.Drawing.Point(156, 303);
            this.tasta681.Name = "tasta681";
            this.tasta681.Size = new System.Drawing.Size(13, 21);
            this.tasta681.TabIndex = 591;
            // 
            // tasta682
            // 
            this.tasta682.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta682.Location = new System.Drawing.Point(137, 303);
            this.tasta682.Name = "tasta682";
            this.tasta682.Size = new System.Drawing.Size(13, 21);
            this.tasta682.TabIndex = 590;
            // 
            // tasta683
            // 
            this.tasta683.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta683.Location = new System.Drawing.Point(118, 303);
            this.tasta683.Name = "tasta683";
            this.tasta683.Size = new System.Drawing.Size(13, 21);
            this.tasta683.TabIndex = 589;
            // 
            // tasta684
            // 
            this.tasta684.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta684.Location = new System.Drawing.Point(99, 303);
            this.tasta684.Name = "tasta684";
            this.tasta684.Size = new System.Drawing.Size(13, 21);
            this.tasta684.TabIndex = 588;
            // 
            // tasta685
            // 
            this.tasta685.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta685.Location = new System.Drawing.Point(80, 303);
            this.tasta685.Name = "tasta685";
            this.tasta685.Size = new System.Drawing.Size(13, 21);
            this.tasta685.TabIndex = 587;
            // 
            // tasta686
            // 
            this.tasta686.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta686.Location = new System.Drawing.Point(61, 303);
            this.tasta686.Name = "tasta686";
            this.tasta686.Size = new System.Drawing.Size(13, 21);
            this.tasta686.TabIndex = 586;
            // 
            // tasta687
            // 
            this.tasta687.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta687.Location = new System.Drawing.Point(42, 303);
            this.tasta687.Name = "tasta687";
            this.tasta687.Size = new System.Drawing.Size(13, 21);
            this.tasta687.TabIndex = 585;
            // 
            // tasta688
            // 
            this.tasta688.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta688.Location = new System.Drawing.Point(23, 303);
            this.tasta688.Name = "tasta688";
            this.tasta688.Size = new System.Drawing.Size(13, 21);
            this.tasta688.TabIndex = 584;
            // 
            // tasta689
            // 
            this.tasta689.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta689.Location = new System.Drawing.Point(4, 303);
            this.tasta689.Name = "tasta689";
            this.tasta689.Size = new System.Drawing.Size(13, 21);
            this.tasta689.TabIndex = 583;
            // 
            // tasta690
            // 
            this.tasta690.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta690.Location = new System.Drawing.Point(993, 276);
            this.tasta690.Name = "tasta690";
            this.tasta690.Size = new System.Drawing.Size(13, 21);
            this.tasta690.TabIndex = 582;
            // 
            // tasta691
            // 
            this.tasta691.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta691.Location = new System.Drawing.Point(974, 276);
            this.tasta691.Name = "tasta691";
            this.tasta691.Size = new System.Drawing.Size(13, 21);
            this.tasta691.TabIndex = 581;
            // 
            // tasta692
            // 
            this.tasta692.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta692.Location = new System.Drawing.Point(955, 276);
            this.tasta692.Name = "tasta692";
            this.tasta692.Size = new System.Drawing.Size(13, 21);
            this.tasta692.TabIndex = 580;
            // 
            // tasta693
            // 
            this.tasta693.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta693.Location = new System.Drawing.Point(936, 276);
            this.tasta693.Name = "tasta693";
            this.tasta693.Size = new System.Drawing.Size(13, 21);
            this.tasta693.TabIndex = 579;
            // 
            // tasta694
            // 
            this.tasta694.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta694.Location = new System.Drawing.Point(917, 276);
            this.tasta694.Name = "tasta694";
            this.tasta694.Size = new System.Drawing.Size(13, 21);
            this.tasta694.TabIndex = 578;
            // 
            // tasta695
            // 
            this.tasta695.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta695.Location = new System.Drawing.Point(897, 276);
            this.tasta695.Name = "tasta695";
            this.tasta695.Size = new System.Drawing.Size(13, 21);
            this.tasta695.TabIndex = 577;
            // 
            // tasta696
            // 
            this.tasta696.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta696.Location = new System.Drawing.Point(878, 276);
            this.tasta696.Name = "tasta696";
            this.tasta696.Size = new System.Drawing.Size(13, 21);
            this.tasta696.TabIndex = 576;
            // 
            // tasta697
            // 
            this.tasta697.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta697.Location = new System.Drawing.Point(859, 276);
            this.tasta697.Name = "tasta697";
            this.tasta697.Size = new System.Drawing.Size(13, 21);
            this.tasta697.TabIndex = 575;
            // 
            // tasta698
            // 
            this.tasta698.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta698.Location = new System.Drawing.Point(840, 276);
            this.tasta698.Name = "tasta698";
            this.tasta698.Size = new System.Drawing.Size(13, 21);
            this.tasta698.TabIndex = 574;
            // 
            // tasta699
            // 
            this.tasta699.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta699.Location = new System.Drawing.Point(821, 276);
            this.tasta699.Name = "tasta699";
            this.tasta699.Size = new System.Drawing.Size(13, 21);
            this.tasta699.TabIndex = 573;
            // 
            // tasta700
            // 
            this.tasta700.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta700.Location = new System.Drawing.Point(802, 276);
            this.tasta700.Name = "tasta700";
            this.tasta700.Size = new System.Drawing.Size(13, 21);
            this.tasta700.TabIndex = 572;
            // 
            // tasta701
            // 
            this.tasta701.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta701.Location = new System.Drawing.Point(783, 276);
            this.tasta701.Name = "tasta701";
            this.tasta701.Size = new System.Drawing.Size(13, 21);
            this.tasta701.TabIndex = 571;
            // 
            // tasta702
            // 
            this.tasta702.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta702.Location = new System.Drawing.Point(764, 276);
            this.tasta702.Name = "tasta702";
            this.tasta702.Size = new System.Drawing.Size(13, 21);
            this.tasta702.TabIndex = 570;
            // 
            // tasta703
            // 
            this.tasta703.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta703.Location = new System.Drawing.Point(745, 276);
            this.tasta703.Name = "tasta703";
            this.tasta703.Size = new System.Drawing.Size(13, 21);
            this.tasta703.TabIndex = 569;
            // 
            // tasta704
            // 
            this.tasta704.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta704.Location = new System.Drawing.Point(726, 276);
            this.tasta704.Name = "tasta704";
            this.tasta704.Size = new System.Drawing.Size(13, 21);
            this.tasta704.TabIndex = 568;
            // 
            // tasta705
            // 
            this.tasta705.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta705.Location = new System.Drawing.Point(707, 276);
            this.tasta705.Name = "tasta705";
            this.tasta705.Size = new System.Drawing.Size(13, 21);
            this.tasta705.TabIndex = 567;
            // 
            // tasta706
            // 
            this.tasta706.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta706.Location = new System.Drawing.Point(688, 276);
            this.tasta706.Name = "tasta706";
            this.tasta706.Size = new System.Drawing.Size(13, 21);
            this.tasta706.TabIndex = 566;
            // 
            // tasta707
            // 
            this.tasta707.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta707.Location = new System.Drawing.Point(669, 276);
            this.tasta707.Name = "tasta707";
            this.tasta707.Size = new System.Drawing.Size(13, 21);
            this.tasta707.TabIndex = 565;
            // 
            // tasta708
            // 
            this.tasta708.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta708.Location = new System.Drawing.Point(650, 276);
            this.tasta708.Name = "tasta708";
            this.tasta708.Size = new System.Drawing.Size(13, 21);
            this.tasta708.TabIndex = 564;
            // 
            // tasta709
            // 
            this.tasta709.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta709.Location = new System.Drawing.Point(631, 276);
            this.tasta709.Name = "tasta709";
            this.tasta709.Size = new System.Drawing.Size(13, 21);
            this.tasta709.TabIndex = 563;
            // 
            // tasta710
            // 
            this.tasta710.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta710.Location = new System.Drawing.Point(612, 276);
            this.tasta710.Name = "tasta710";
            this.tasta710.Size = new System.Drawing.Size(13, 21);
            this.tasta710.TabIndex = 562;
            // 
            // tasta711
            // 
            this.tasta711.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta711.Location = new System.Drawing.Point(593, 276);
            this.tasta711.Name = "tasta711";
            this.tasta711.Size = new System.Drawing.Size(13, 21);
            this.tasta711.TabIndex = 561;
            // 
            // tasta712
            // 
            this.tasta712.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta712.Location = new System.Drawing.Point(574, 276);
            this.tasta712.Name = "tasta712";
            this.tasta712.Size = new System.Drawing.Size(13, 21);
            this.tasta712.TabIndex = 560;
            // 
            // tasta713
            // 
            this.tasta713.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta713.Location = new System.Drawing.Point(555, 276);
            this.tasta713.Name = "tasta713";
            this.tasta713.Size = new System.Drawing.Size(13, 21);
            this.tasta713.TabIndex = 559;
            // 
            // tasta714
            // 
            this.tasta714.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta714.Location = new System.Drawing.Point(536, 276);
            this.tasta714.Name = "tasta714";
            this.tasta714.Size = new System.Drawing.Size(13, 21);
            this.tasta714.TabIndex = 558;
            // 
            // tasta715
            // 
            this.tasta715.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta715.Location = new System.Drawing.Point(517, 276);
            this.tasta715.Name = "tasta715";
            this.tasta715.Size = new System.Drawing.Size(13, 21);
            this.tasta715.TabIndex = 557;
            // 
            // tasta716
            // 
            this.tasta716.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta716.Location = new System.Drawing.Point(498, 276);
            this.tasta716.Name = "tasta716";
            this.tasta716.Size = new System.Drawing.Size(13, 21);
            this.tasta716.TabIndex = 556;
            // 
            // tasta717
            // 
            this.tasta717.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta717.Location = new System.Drawing.Point(479, 276);
            this.tasta717.Name = "tasta717";
            this.tasta717.Size = new System.Drawing.Size(13, 21);
            this.tasta717.TabIndex = 555;
            // 
            // tasta718
            // 
            this.tasta718.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta718.Location = new System.Drawing.Point(460, 276);
            this.tasta718.Name = "tasta718";
            this.tasta718.Size = new System.Drawing.Size(13, 21);
            this.tasta718.TabIndex = 554;
            // 
            // tasta719
            // 
            this.tasta719.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta719.Location = new System.Drawing.Point(441, 276);
            this.tasta719.Name = "tasta719";
            this.tasta719.Size = new System.Drawing.Size(13, 21);
            this.tasta719.TabIndex = 553;
            // 
            // tasta720
            // 
            this.tasta720.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta720.Location = new System.Drawing.Point(422, 276);
            this.tasta720.Name = "tasta720";
            this.tasta720.Size = new System.Drawing.Size(13, 21);
            this.tasta720.TabIndex = 552;
            // 
            // tasta721
            // 
            this.tasta721.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta721.Location = new System.Drawing.Point(403, 276);
            this.tasta721.Name = "tasta721";
            this.tasta721.Size = new System.Drawing.Size(13, 21);
            this.tasta721.TabIndex = 551;
            // 
            // tasta722
            // 
            this.tasta722.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta722.Location = new System.Drawing.Point(384, 276);
            this.tasta722.Name = "tasta722";
            this.tasta722.Size = new System.Drawing.Size(13, 21);
            this.tasta722.TabIndex = 550;
            // 
            // tasta723
            // 
            this.tasta723.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta723.Location = new System.Drawing.Point(365, 276);
            this.tasta723.Name = "tasta723";
            this.tasta723.Size = new System.Drawing.Size(13, 21);
            this.tasta723.TabIndex = 549;
            // 
            // tasta724
            // 
            this.tasta724.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta724.Location = new System.Drawing.Point(346, 276);
            this.tasta724.Name = "tasta724";
            this.tasta724.Size = new System.Drawing.Size(13, 21);
            this.tasta724.TabIndex = 548;
            // 
            // tasta725
            // 
            this.tasta725.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta725.Location = new System.Drawing.Point(327, 276);
            this.tasta725.Name = "tasta725";
            this.tasta725.Size = new System.Drawing.Size(13, 21);
            this.tasta725.TabIndex = 547;
            // 
            // tasta726
            // 
            this.tasta726.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta726.Location = new System.Drawing.Point(308, 276);
            this.tasta726.Name = "tasta726";
            this.tasta726.Size = new System.Drawing.Size(13, 21);
            this.tasta726.TabIndex = 546;
            // 
            // tasta727
            // 
            this.tasta727.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta727.Location = new System.Drawing.Point(289, 276);
            this.tasta727.Name = "tasta727";
            this.tasta727.Size = new System.Drawing.Size(13, 21);
            this.tasta727.TabIndex = 545;
            // 
            // tasta728
            // 
            this.tasta728.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta728.Location = new System.Drawing.Point(270, 276);
            this.tasta728.Name = "tasta728";
            this.tasta728.Size = new System.Drawing.Size(13, 21);
            this.tasta728.TabIndex = 544;
            // 
            // tasta729
            // 
            this.tasta729.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta729.Location = new System.Drawing.Point(251, 276);
            this.tasta729.Name = "tasta729";
            this.tasta729.Size = new System.Drawing.Size(13, 21);
            this.tasta729.TabIndex = 543;
            // 
            // tasta730
            // 
            this.tasta730.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta730.Location = new System.Drawing.Point(232, 276);
            this.tasta730.Name = "tasta730";
            this.tasta730.Size = new System.Drawing.Size(13, 21);
            this.tasta730.TabIndex = 542;
            // 
            // tasta731
            // 
            this.tasta731.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta731.Location = new System.Drawing.Point(213, 276);
            this.tasta731.Name = "tasta731";
            this.tasta731.Size = new System.Drawing.Size(13, 21);
            this.tasta731.TabIndex = 541;
            // 
            // tasta732
            // 
            this.tasta732.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta732.Location = new System.Drawing.Point(194, 276);
            this.tasta732.Name = "tasta732";
            this.tasta732.Size = new System.Drawing.Size(13, 21);
            this.tasta732.TabIndex = 540;
            // 
            // tasta733
            // 
            this.tasta733.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta733.Location = new System.Drawing.Point(175, 276);
            this.tasta733.Name = "tasta733";
            this.tasta733.Size = new System.Drawing.Size(13, 21);
            this.tasta733.TabIndex = 539;
            // 
            // tasta734
            // 
            this.tasta734.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta734.Location = new System.Drawing.Point(156, 276);
            this.tasta734.Name = "tasta734";
            this.tasta734.Size = new System.Drawing.Size(13, 21);
            this.tasta734.TabIndex = 538;
            // 
            // tasta735
            // 
            this.tasta735.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta735.Location = new System.Drawing.Point(137, 276);
            this.tasta735.Name = "tasta735";
            this.tasta735.Size = new System.Drawing.Size(13, 21);
            this.tasta735.TabIndex = 537;
            // 
            // tasta736
            // 
            this.tasta736.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta736.Location = new System.Drawing.Point(118, 276);
            this.tasta736.Name = "tasta736";
            this.tasta736.Size = new System.Drawing.Size(13, 21);
            this.tasta736.TabIndex = 536;
            // 
            // tasta737
            // 
            this.tasta737.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta737.Location = new System.Drawing.Point(99, 276);
            this.tasta737.Name = "tasta737";
            this.tasta737.Size = new System.Drawing.Size(13, 21);
            this.tasta737.TabIndex = 535;
            // 
            // tasta738
            // 
            this.tasta738.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta738.Location = new System.Drawing.Point(80, 276);
            this.tasta738.Name = "tasta738";
            this.tasta738.Size = new System.Drawing.Size(13, 21);
            this.tasta738.TabIndex = 534;
            // 
            // tasta739
            // 
            this.tasta739.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta739.Location = new System.Drawing.Point(61, 276);
            this.tasta739.Name = "tasta739";
            this.tasta739.Size = new System.Drawing.Size(13, 21);
            this.tasta739.TabIndex = 533;
            // 
            // tasta740
            // 
            this.tasta740.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta740.Location = new System.Drawing.Point(42, 276);
            this.tasta740.Name = "tasta740";
            this.tasta740.Size = new System.Drawing.Size(13, 21);
            this.tasta740.TabIndex = 532;
            // 
            // tasta741
            // 
            this.tasta741.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta741.Location = new System.Drawing.Point(23, 276);
            this.tasta741.Name = "tasta741";
            this.tasta741.Size = new System.Drawing.Size(13, 21);
            this.tasta741.TabIndex = 531;
            // 
            // tasta742
            // 
            this.tasta742.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta742.Location = new System.Drawing.Point(4, 276);
            this.tasta742.Name = "tasta742";
            this.tasta742.Size = new System.Drawing.Size(13, 21);
            this.tasta742.TabIndex = 530;
            // 
            // tasta743
            // 
            this.tasta743.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta743.Location = new System.Drawing.Point(993, 249);
            this.tasta743.Name = "tasta743";
            this.tasta743.Size = new System.Drawing.Size(13, 21);
            this.tasta743.TabIndex = 529;
            // 
            // tasta744
            // 
            this.tasta744.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta744.Location = new System.Drawing.Point(974, 249);
            this.tasta744.Name = "tasta744";
            this.tasta744.Size = new System.Drawing.Size(13, 21);
            this.tasta744.TabIndex = 528;
            // 
            // tasta745
            // 
            this.tasta745.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta745.Location = new System.Drawing.Point(955, 249);
            this.tasta745.Name = "tasta745";
            this.tasta745.Size = new System.Drawing.Size(13, 21);
            this.tasta745.TabIndex = 527;
            // 
            // tasta746
            // 
            this.tasta746.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta746.Location = new System.Drawing.Point(936, 249);
            this.tasta746.Name = "tasta746";
            this.tasta746.Size = new System.Drawing.Size(13, 21);
            this.tasta746.TabIndex = 526;
            // 
            // tasta747
            // 
            this.tasta747.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta747.Location = new System.Drawing.Point(917, 249);
            this.tasta747.Name = "tasta747";
            this.tasta747.Size = new System.Drawing.Size(13, 21);
            this.tasta747.TabIndex = 525;
            // 
            // tasta748
            // 
            this.tasta748.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta748.Location = new System.Drawing.Point(897, 249);
            this.tasta748.Name = "tasta748";
            this.tasta748.Size = new System.Drawing.Size(13, 21);
            this.tasta748.TabIndex = 524;
            // 
            // tasta749
            // 
            this.tasta749.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta749.Location = new System.Drawing.Point(878, 249);
            this.tasta749.Name = "tasta749";
            this.tasta749.Size = new System.Drawing.Size(13, 21);
            this.tasta749.TabIndex = 523;
            // 
            // tasta750
            // 
            this.tasta750.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta750.Location = new System.Drawing.Point(859, 249);
            this.tasta750.Name = "tasta750";
            this.tasta750.Size = new System.Drawing.Size(13, 21);
            this.tasta750.TabIndex = 522;
            // 
            // tasta751
            // 
            this.tasta751.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta751.Location = new System.Drawing.Point(840, 249);
            this.tasta751.Name = "tasta751";
            this.tasta751.Size = new System.Drawing.Size(13, 21);
            this.tasta751.TabIndex = 521;
            // 
            // tasta752
            // 
            this.tasta752.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta752.Location = new System.Drawing.Point(821, 249);
            this.tasta752.Name = "tasta752";
            this.tasta752.Size = new System.Drawing.Size(13, 21);
            this.tasta752.TabIndex = 520;
            // 
            // tasta753
            // 
            this.tasta753.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta753.Location = new System.Drawing.Point(802, 249);
            this.tasta753.Name = "tasta753";
            this.tasta753.Size = new System.Drawing.Size(13, 21);
            this.tasta753.TabIndex = 519;
            // 
            // tasta754
            // 
            this.tasta754.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta754.Location = new System.Drawing.Point(783, 249);
            this.tasta754.Name = "tasta754";
            this.tasta754.Size = new System.Drawing.Size(13, 21);
            this.tasta754.TabIndex = 518;
            // 
            // tasta755
            // 
            this.tasta755.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta755.Location = new System.Drawing.Point(764, 249);
            this.tasta755.Name = "tasta755";
            this.tasta755.Size = new System.Drawing.Size(13, 21);
            this.tasta755.TabIndex = 517;
            // 
            // tasta756
            // 
            this.tasta756.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta756.Location = new System.Drawing.Point(745, 249);
            this.tasta756.Name = "tasta756";
            this.tasta756.Size = new System.Drawing.Size(13, 21);
            this.tasta756.TabIndex = 516;
            // 
            // tasta757
            // 
            this.tasta757.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta757.Location = new System.Drawing.Point(726, 249);
            this.tasta757.Name = "tasta757";
            this.tasta757.Size = new System.Drawing.Size(13, 21);
            this.tasta757.TabIndex = 515;
            // 
            // tasta758
            // 
            this.tasta758.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta758.Location = new System.Drawing.Point(707, 249);
            this.tasta758.Name = "tasta758";
            this.tasta758.Size = new System.Drawing.Size(13, 21);
            this.tasta758.TabIndex = 514;
            // 
            // tasta759
            // 
            this.tasta759.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta759.Location = new System.Drawing.Point(688, 249);
            this.tasta759.Name = "tasta759";
            this.tasta759.Size = new System.Drawing.Size(13, 21);
            this.tasta759.TabIndex = 513;
            // 
            // tasta760
            // 
            this.tasta760.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta760.Location = new System.Drawing.Point(669, 249);
            this.tasta760.Name = "tasta760";
            this.tasta760.Size = new System.Drawing.Size(13, 21);
            this.tasta760.TabIndex = 512;
            // 
            // tasta761
            // 
            this.tasta761.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta761.Location = new System.Drawing.Point(650, 249);
            this.tasta761.Name = "tasta761";
            this.tasta761.Size = new System.Drawing.Size(13, 21);
            this.tasta761.TabIndex = 511;
            // 
            // tasta762
            // 
            this.tasta762.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta762.Location = new System.Drawing.Point(631, 249);
            this.tasta762.Name = "tasta762";
            this.tasta762.Size = new System.Drawing.Size(13, 21);
            this.tasta762.TabIndex = 510;
            // 
            // tasta763
            // 
            this.tasta763.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta763.Location = new System.Drawing.Point(612, 249);
            this.tasta763.Name = "tasta763";
            this.tasta763.Size = new System.Drawing.Size(13, 21);
            this.tasta763.TabIndex = 509;
            // 
            // tasta764
            // 
            this.tasta764.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta764.Location = new System.Drawing.Point(593, 249);
            this.tasta764.Name = "tasta764";
            this.tasta764.Size = new System.Drawing.Size(13, 21);
            this.tasta764.TabIndex = 508;
            // 
            // tasta765
            // 
            this.tasta765.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta765.Location = new System.Drawing.Point(574, 249);
            this.tasta765.Name = "tasta765";
            this.tasta765.Size = new System.Drawing.Size(13, 21);
            this.tasta765.TabIndex = 507;
            // 
            // tasta766
            // 
            this.tasta766.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta766.Location = new System.Drawing.Point(555, 249);
            this.tasta766.Name = "tasta766";
            this.tasta766.Size = new System.Drawing.Size(13, 21);
            this.tasta766.TabIndex = 506;
            // 
            // tasta767
            // 
            this.tasta767.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta767.Location = new System.Drawing.Point(536, 249);
            this.tasta767.Name = "tasta767";
            this.tasta767.Size = new System.Drawing.Size(13, 21);
            this.tasta767.TabIndex = 505;
            // 
            // tasta768
            // 
            this.tasta768.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta768.Location = new System.Drawing.Point(517, 249);
            this.tasta768.Name = "tasta768";
            this.tasta768.Size = new System.Drawing.Size(13, 21);
            this.tasta768.TabIndex = 504;
            // 
            // tasta769
            // 
            this.tasta769.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta769.Location = new System.Drawing.Point(498, 249);
            this.tasta769.Name = "tasta769";
            this.tasta769.Size = new System.Drawing.Size(13, 21);
            this.tasta769.TabIndex = 503;
            // 
            // tasta770
            // 
            this.tasta770.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta770.Location = new System.Drawing.Point(479, 249);
            this.tasta770.Name = "tasta770";
            this.tasta770.Size = new System.Drawing.Size(13, 21);
            this.tasta770.TabIndex = 502;
            // 
            // tasta771
            // 
            this.tasta771.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta771.Location = new System.Drawing.Point(460, 249);
            this.tasta771.Name = "tasta771";
            this.tasta771.Size = new System.Drawing.Size(13, 21);
            this.tasta771.TabIndex = 501;
            // 
            // tasta772
            // 
            this.tasta772.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta772.Location = new System.Drawing.Point(441, 249);
            this.tasta772.Name = "tasta772";
            this.tasta772.Size = new System.Drawing.Size(13, 21);
            this.tasta772.TabIndex = 500;
            // 
            // tasta773
            // 
            this.tasta773.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta773.Location = new System.Drawing.Point(422, 249);
            this.tasta773.Name = "tasta773";
            this.tasta773.Size = new System.Drawing.Size(13, 21);
            this.tasta773.TabIndex = 499;
            // 
            // tasta774
            // 
            this.tasta774.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta774.Location = new System.Drawing.Point(403, 249);
            this.tasta774.Name = "tasta774";
            this.tasta774.Size = new System.Drawing.Size(13, 21);
            this.tasta774.TabIndex = 498;
            // 
            // tasta775
            // 
            this.tasta775.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta775.Location = new System.Drawing.Point(384, 249);
            this.tasta775.Name = "tasta775";
            this.tasta775.Size = new System.Drawing.Size(13, 21);
            this.tasta775.TabIndex = 497;
            // 
            // tasta776
            // 
            this.tasta776.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta776.Location = new System.Drawing.Point(365, 249);
            this.tasta776.Name = "tasta776";
            this.tasta776.Size = new System.Drawing.Size(13, 21);
            this.tasta776.TabIndex = 496;
            // 
            // tasta777
            // 
            this.tasta777.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta777.Location = new System.Drawing.Point(346, 249);
            this.tasta777.Name = "tasta777";
            this.tasta777.Size = new System.Drawing.Size(13, 21);
            this.tasta777.TabIndex = 495;
            // 
            // tasta778
            // 
            this.tasta778.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta778.Location = new System.Drawing.Point(327, 249);
            this.tasta778.Name = "tasta778";
            this.tasta778.Size = new System.Drawing.Size(13, 21);
            this.tasta778.TabIndex = 494;
            // 
            // tasta779
            // 
            this.tasta779.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta779.Location = new System.Drawing.Point(308, 249);
            this.tasta779.Name = "tasta779";
            this.tasta779.Size = new System.Drawing.Size(13, 21);
            this.tasta779.TabIndex = 493;
            // 
            // tasta780
            // 
            this.tasta780.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta780.Location = new System.Drawing.Point(289, 249);
            this.tasta780.Name = "tasta780";
            this.tasta780.Size = new System.Drawing.Size(13, 21);
            this.tasta780.TabIndex = 492;
            // 
            // tasta781
            // 
            this.tasta781.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta781.Location = new System.Drawing.Point(270, 249);
            this.tasta781.Name = "tasta781";
            this.tasta781.Size = new System.Drawing.Size(13, 21);
            this.tasta781.TabIndex = 491;
            // 
            // tasta782
            // 
            this.tasta782.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta782.Location = new System.Drawing.Point(251, 249);
            this.tasta782.Name = "tasta782";
            this.tasta782.Size = new System.Drawing.Size(13, 21);
            this.tasta782.TabIndex = 490;
            // 
            // tasta783
            // 
            this.tasta783.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta783.Location = new System.Drawing.Point(232, 249);
            this.tasta783.Name = "tasta783";
            this.tasta783.Size = new System.Drawing.Size(13, 21);
            this.tasta783.TabIndex = 489;
            // 
            // tasta784
            // 
            this.tasta784.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta784.Location = new System.Drawing.Point(213, 249);
            this.tasta784.Name = "tasta784";
            this.tasta784.Size = new System.Drawing.Size(13, 21);
            this.tasta784.TabIndex = 488;
            // 
            // tasta785
            // 
            this.tasta785.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta785.Location = new System.Drawing.Point(194, 249);
            this.tasta785.Name = "tasta785";
            this.tasta785.Size = new System.Drawing.Size(13, 21);
            this.tasta785.TabIndex = 487;
            // 
            // tasta786
            // 
            this.tasta786.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta786.Location = new System.Drawing.Point(175, 249);
            this.tasta786.Name = "tasta786";
            this.tasta786.Size = new System.Drawing.Size(13, 21);
            this.tasta786.TabIndex = 486;
            // 
            // tasta787
            // 
            this.tasta787.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta787.Location = new System.Drawing.Point(156, 249);
            this.tasta787.Name = "tasta787";
            this.tasta787.Size = new System.Drawing.Size(13, 21);
            this.tasta787.TabIndex = 485;
            // 
            // tasta788
            // 
            this.tasta788.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta788.Location = new System.Drawing.Point(137, 249);
            this.tasta788.Name = "tasta788";
            this.tasta788.Size = new System.Drawing.Size(13, 21);
            this.tasta788.TabIndex = 484;
            // 
            // tasta789
            // 
            this.tasta789.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta789.Location = new System.Drawing.Point(118, 249);
            this.tasta789.Name = "tasta789";
            this.tasta789.Size = new System.Drawing.Size(13, 21);
            this.tasta789.TabIndex = 483;
            // 
            // tasta790
            // 
            this.tasta790.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta790.Location = new System.Drawing.Point(99, 249);
            this.tasta790.Name = "tasta790";
            this.tasta790.Size = new System.Drawing.Size(13, 21);
            this.tasta790.TabIndex = 482;
            // 
            // tasta791
            // 
            this.tasta791.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta791.Location = new System.Drawing.Point(80, 249);
            this.tasta791.Name = "tasta791";
            this.tasta791.Size = new System.Drawing.Size(13, 21);
            this.tasta791.TabIndex = 481;
            // 
            // tasta792
            // 
            this.tasta792.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta792.Location = new System.Drawing.Point(61, 249);
            this.tasta792.Name = "tasta792";
            this.tasta792.Size = new System.Drawing.Size(13, 21);
            this.tasta792.TabIndex = 480;
            // 
            // tasta793
            // 
            this.tasta793.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta793.Location = new System.Drawing.Point(42, 249);
            this.tasta793.Name = "tasta793";
            this.tasta793.Size = new System.Drawing.Size(13, 21);
            this.tasta793.TabIndex = 479;
            // 
            // tasta794
            // 
            this.tasta794.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta794.Location = new System.Drawing.Point(23, 249);
            this.tasta794.Name = "tasta794";
            this.tasta794.Size = new System.Drawing.Size(13, 21);
            this.tasta794.TabIndex = 478;
            // 
            // tasta795
            // 
            this.tasta795.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta795.Location = new System.Drawing.Point(4, 249);
            this.tasta795.Name = "tasta795";
            this.tasta795.Size = new System.Drawing.Size(13, 21);
            this.tasta795.TabIndex = 477;
            // 
            // tasta796
            // 
            this.tasta796.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta796.Location = new System.Drawing.Point(993, 222);
            this.tasta796.Name = "tasta796";
            this.tasta796.Size = new System.Drawing.Size(13, 21);
            this.tasta796.TabIndex = 476;
            // 
            // tasta797
            // 
            this.tasta797.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta797.Location = new System.Drawing.Point(974, 222);
            this.tasta797.Name = "tasta797";
            this.tasta797.Size = new System.Drawing.Size(13, 21);
            this.tasta797.TabIndex = 475;
            // 
            // tasta798
            // 
            this.tasta798.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta798.Location = new System.Drawing.Point(955, 222);
            this.tasta798.Name = "tasta798";
            this.tasta798.Size = new System.Drawing.Size(13, 21);
            this.tasta798.TabIndex = 474;
            // 
            // tasta799
            // 
            this.tasta799.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta799.Location = new System.Drawing.Point(936, 222);
            this.tasta799.Name = "tasta799";
            this.tasta799.Size = new System.Drawing.Size(13, 21);
            this.tasta799.TabIndex = 473;
            // 
            // tasta800
            // 
            this.tasta800.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta800.Location = new System.Drawing.Point(917, 222);
            this.tasta800.Name = "tasta800";
            this.tasta800.Size = new System.Drawing.Size(13, 21);
            this.tasta800.TabIndex = 472;
            // 
            // tasta801
            // 
            this.tasta801.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta801.Location = new System.Drawing.Point(897, 222);
            this.tasta801.Name = "tasta801";
            this.tasta801.Size = new System.Drawing.Size(13, 21);
            this.tasta801.TabIndex = 471;
            // 
            // tasta802
            // 
            this.tasta802.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta802.Location = new System.Drawing.Point(878, 222);
            this.tasta802.Name = "tasta802";
            this.tasta802.Size = new System.Drawing.Size(13, 21);
            this.tasta802.TabIndex = 470;
            // 
            // tasta803
            // 
            this.tasta803.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta803.Location = new System.Drawing.Point(859, 222);
            this.tasta803.Name = "tasta803";
            this.tasta803.Size = new System.Drawing.Size(13, 21);
            this.tasta803.TabIndex = 469;
            // 
            // tasta804
            // 
            this.tasta804.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta804.Location = new System.Drawing.Point(840, 222);
            this.tasta804.Name = "tasta804";
            this.tasta804.Size = new System.Drawing.Size(13, 21);
            this.tasta804.TabIndex = 468;
            // 
            // tasta805
            // 
            this.tasta805.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta805.Location = new System.Drawing.Point(821, 222);
            this.tasta805.Name = "tasta805";
            this.tasta805.Size = new System.Drawing.Size(13, 21);
            this.tasta805.TabIndex = 467;
            // 
            // tasta806
            // 
            this.tasta806.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta806.Location = new System.Drawing.Point(802, 222);
            this.tasta806.Name = "tasta806";
            this.tasta806.Size = new System.Drawing.Size(13, 21);
            this.tasta806.TabIndex = 466;
            // 
            // tasta807
            // 
            this.tasta807.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta807.Location = new System.Drawing.Point(783, 222);
            this.tasta807.Name = "tasta807";
            this.tasta807.Size = new System.Drawing.Size(13, 21);
            this.tasta807.TabIndex = 465;
            // 
            // tasta808
            // 
            this.tasta808.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta808.Location = new System.Drawing.Point(764, 222);
            this.tasta808.Name = "tasta808";
            this.tasta808.Size = new System.Drawing.Size(13, 21);
            this.tasta808.TabIndex = 464;
            // 
            // tasta809
            // 
            this.tasta809.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta809.Location = new System.Drawing.Point(745, 222);
            this.tasta809.Name = "tasta809";
            this.tasta809.Size = new System.Drawing.Size(13, 21);
            this.tasta809.TabIndex = 463;
            // 
            // tasta810
            // 
            this.tasta810.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta810.Location = new System.Drawing.Point(726, 222);
            this.tasta810.Name = "tasta810";
            this.tasta810.Size = new System.Drawing.Size(13, 21);
            this.tasta810.TabIndex = 462;
            // 
            // tasta811
            // 
            this.tasta811.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta811.Location = new System.Drawing.Point(707, 222);
            this.tasta811.Name = "tasta811";
            this.tasta811.Size = new System.Drawing.Size(13, 21);
            this.tasta811.TabIndex = 461;
            // 
            // tasta812
            // 
            this.tasta812.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta812.Location = new System.Drawing.Point(688, 222);
            this.tasta812.Name = "tasta812";
            this.tasta812.Size = new System.Drawing.Size(13, 21);
            this.tasta812.TabIndex = 460;
            // 
            // tasta813
            // 
            this.tasta813.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta813.Location = new System.Drawing.Point(669, 222);
            this.tasta813.Name = "tasta813";
            this.tasta813.Size = new System.Drawing.Size(13, 21);
            this.tasta813.TabIndex = 459;
            // 
            // tasta814
            // 
            this.tasta814.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta814.Location = new System.Drawing.Point(650, 222);
            this.tasta814.Name = "tasta814";
            this.tasta814.Size = new System.Drawing.Size(13, 21);
            this.tasta814.TabIndex = 458;
            // 
            // tasta815
            // 
            this.tasta815.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta815.Location = new System.Drawing.Point(631, 222);
            this.tasta815.Name = "tasta815";
            this.tasta815.Size = new System.Drawing.Size(13, 21);
            this.tasta815.TabIndex = 457;
            // 
            // tasta816
            // 
            this.tasta816.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta816.Location = new System.Drawing.Point(612, 222);
            this.tasta816.Name = "tasta816";
            this.tasta816.Size = new System.Drawing.Size(13, 21);
            this.tasta816.TabIndex = 456;
            // 
            // tasta817
            // 
            this.tasta817.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta817.Location = new System.Drawing.Point(593, 222);
            this.tasta817.Name = "tasta817";
            this.tasta817.Size = new System.Drawing.Size(13, 21);
            this.tasta817.TabIndex = 455;
            // 
            // tasta818
            // 
            this.tasta818.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta818.Location = new System.Drawing.Point(574, 222);
            this.tasta818.Name = "tasta818";
            this.tasta818.Size = new System.Drawing.Size(13, 21);
            this.tasta818.TabIndex = 454;
            // 
            // tasta819
            // 
            this.tasta819.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta819.Location = new System.Drawing.Point(555, 222);
            this.tasta819.Name = "tasta819";
            this.tasta819.Size = new System.Drawing.Size(13, 21);
            this.tasta819.TabIndex = 453;
            // 
            // tasta820
            // 
            this.tasta820.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta820.Location = new System.Drawing.Point(536, 222);
            this.tasta820.Name = "tasta820";
            this.tasta820.Size = new System.Drawing.Size(13, 21);
            this.tasta820.TabIndex = 452;
            // 
            // tasta821
            // 
            this.tasta821.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta821.Location = new System.Drawing.Point(517, 222);
            this.tasta821.Name = "tasta821";
            this.tasta821.Size = new System.Drawing.Size(13, 21);
            this.tasta821.TabIndex = 451;
            // 
            // tasta822
            // 
            this.tasta822.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta822.Location = new System.Drawing.Point(498, 222);
            this.tasta822.Name = "tasta822";
            this.tasta822.Size = new System.Drawing.Size(13, 21);
            this.tasta822.TabIndex = 450;
            // 
            // tasta823
            // 
            this.tasta823.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta823.Location = new System.Drawing.Point(479, 222);
            this.tasta823.Name = "tasta823";
            this.tasta823.Size = new System.Drawing.Size(13, 21);
            this.tasta823.TabIndex = 449;
            // 
            // tasta824
            // 
            this.tasta824.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta824.Location = new System.Drawing.Point(460, 222);
            this.tasta824.Name = "tasta824";
            this.tasta824.Size = new System.Drawing.Size(13, 21);
            this.tasta824.TabIndex = 448;
            // 
            // tasta825
            // 
            this.tasta825.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta825.Location = new System.Drawing.Point(441, 222);
            this.tasta825.Name = "tasta825";
            this.tasta825.Size = new System.Drawing.Size(13, 21);
            this.tasta825.TabIndex = 447;
            // 
            // tasta826
            // 
            this.tasta826.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta826.Location = new System.Drawing.Point(422, 222);
            this.tasta826.Name = "tasta826";
            this.tasta826.Size = new System.Drawing.Size(13, 21);
            this.tasta826.TabIndex = 446;
            // 
            // tasta827
            // 
            this.tasta827.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta827.Location = new System.Drawing.Point(403, 222);
            this.tasta827.Name = "tasta827";
            this.tasta827.Size = new System.Drawing.Size(13, 21);
            this.tasta827.TabIndex = 445;
            // 
            // tasta828
            // 
            this.tasta828.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta828.Location = new System.Drawing.Point(384, 222);
            this.tasta828.Name = "tasta828";
            this.tasta828.Size = new System.Drawing.Size(13, 21);
            this.tasta828.TabIndex = 444;
            // 
            // tasta829
            // 
            this.tasta829.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta829.Location = new System.Drawing.Point(365, 222);
            this.tasta829.Name = "tasta829";
            this.tasta829.Size = new System.Drawing.Size(13, 21);
            this.tasta829.TabIndex = 443;
            // 
            // tasta830
            // 
            this.tasta830.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta830.Location = new System.Drawing.Point(346, 222);
            this.tasta830.Name = "tasta830";
            this.tasta830.Size = new System.Drawing.Size(13, 21);
            this.tasta830.TabIndex = 442;
            // 
            // tasta831
            // 
            this.tasta831.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta831.Location = new System.Drawing.Point(327, 222);
            this.tasta831.Name = "tasta831";
            this.tasta831.Size = new System.Drawing.Size(13, 21);
            this.tasta831.TabIndex = 441;
            // 
            // tasta832
            // 
            this.tasta832.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta832.Location = new System.Drawing.Point(308, 222);
            this.tasta832.Name = "tasta832";
            this.tasta832.Size = new System.Drawing.Size(13, 21);
            this.tasta832.TabIndex = 440;
            // 
            // tasta833
            // 
            this.tasta833.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta833.Location = new System.Drawing.Point(289, 222);
            this.tasta833.Name = "tasta833";
            this.tasta833.Size = new System.Drawing.Size(13, 21);
            this.tasta833.TabIndex = 439;
            // 
            // tasta834
            // 
            this.tasta834.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta834.Location = new System.Drawing.Point(270, 222);
            this.tasta834.Name = "tasta834";
            this.tasta834.Size = new System.Drawing.Size(13, 21);
            this.tasta834.TabIndex = 438;
            // 
            // tasta835
            // 
            this.tasta835.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta835.Location = new System.Drawing.Point(251, 222);
            this.tasta835.Name = "tasta835";
            this.tasta835.Size = new System.Drawing.Size(13, 21);
            this.tasta835.TabIndex = 437;
            // 
            // tasta836
            // 
            this.tasta836.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta836.Location = new System.Drawing.Point(232, 222);
            this.tasta836.Name = "tasta836";
            this.tasta836.Size = new System.Drawing.Size(13, 21);
            this.tasta836.TabIndex = 436;
            // 
            // tasta837
            // 
            this.tasta837.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta837.Location = new System.Drawing.Point(213, 222);
            this.tasta837.Name = "tasta837";
            this.tasta837.Size = new System.Drawing.Size(13, 21);
            this.tasta837.TabIndex = 435;
            // 
            // tasta838
            // 
            this.tasta838.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta838.Location = new System.Drawing.Point(194, 222);
            this.tasta838.Name = "tasta838";
            this.tasta838.Size = new System.Drawing.Size(13, 21);
            this.tasta838.TabIndex = 434;
            // 
            // tasta839
            // 
            this.tasta839.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta839.Location = new System.Drawing.Point(175, 222);
            this.tasta839.Name = "tasta839";
            this.tasta839.Size = new System.Drawing.Size(13, 21);
            this.tasta839.TabIndex = 433;
            // 
            // tasta840
            // 
            this.tasta840.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta840.Location = new System.Drawing.Point(156, 222);
            this.tasta840.Name = "tasta840";
            this.tasta840.Size = new System.Drawing.Size(13, 21);
            this.tasta840.TabIndex = 432;
            // 
            // tasta841
            // 
            this.tasta841.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta841.Location = new System.Drawing.Point(137, 222);
            this.tasta841.Name = "tasta841";
            this.tasta841.Size = new System.Drawing.Size(13, 21);
            this.tasta841.TabIndex = 431;
            // 
            // tasta842
            // 
            this.tasta842.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta842.Location = new System.Drawing.Point(118, 222);
            this.tasta842.Name = "tasta842";
            this.tasta842.Size = new System.Drawing.Size(13, 21);
            this.tasta842.TabIndex = 430;
            // 
            // tasta843
            // 
            this.tasta843.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta843.Location = new System.Drawing.Point(99, 222);
            this.tasta843.Name = "tasta843";
            this.tasta843.Size = new System.Drawing.Size(13, 21);
            this.tasta843.TabIndex = 429;
            // 
            // tasta844
            // 
            this.tasta844.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta844.Location = new System.Drawing.Point(80, 222);
            this.tasta844.Name = "tasta844";
            this.tasta844.Size = new System.Drawing.Size(13, 21);
            this.tasta844.TabIndex = 428;
            // 
            // tasta845
            // 
            this.tasta845.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta845.Location = new System.Drawing.Point(61, 222);
            this.tasta845.Name = "tasta845";
            this.tasta845.Size = new System.Drawing.Size(13, 21);
            this.tasta845.TabIndex = 427;
            // 
            // tasta846
            // 
            this.tasta846.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta846.Location = new System.Drawing.Point(42, 222);
            this.tasta846.Name = "tasta846";
            this.tasta846.Size = new System.Drawing.Size(13, 21);
            this.tasta846.TabIndex = 426;
            // 
            // tasta847
            // 
            this.tasta847.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta847.Location = new System.Drawing.Point(23, 222);
            this.tasta847.Name = "tasta847";
            this.tasta847.Size = new System.Drawing.Size(13, 21);
            this.tasta847.TabIndex = 425;
            // 
            // tasta848
            // 
            this.tasta848.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta848.Location = new System.Drawing.Point(4, 222);
            this.tasta848.Name = "tasta848";
            this.tasta848.Size = new System.Drawing.Size(13, 21);
            this.tasta848.TabIndex = 424;
            // 
            // tasta849
            // 
            this.tasta849.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta849.Location = new System.Drawing.Point(993, 626);
            this.tasta849.Name = "tasta849";
            this.tasta849.Size = new System.Drawing.Size(13, 21);
            this.tasta849.TabIndex = 1271;
            // 
            // tasta850
            // 
            this.tasta850.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta850.Location = new System.Drawing.Point(974, 626);
            this.tasta850.Name = "tasta850";
            this.tasta850.Size = new System.Drawing.Size(13, 21);
            this.tasta850.TabIndex = 1270;
            // 
            // tasta851
            // 
            this.tasta851.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta851.Location = new System.Drawing.Point(955, 626);
            this.tasta851.Name = "tasta851";
            this.tasta851.Size = new System.Drawing.Size(13, 21);
            this.tasta851.TabIndex = 1269;
            // 
            // tasta852
            // 
            this.tasta852.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta852.Location = new System.Drawing.Point(936, 626);
            this.tasta852.Name = "tasta852";
            this.tasta852.Size = new System.Drawing.Size(13, 21);
            this.tasta852.TabIndex = 1268;
            // 
            // tasta853
            // 
            this.tasta853.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta853.Location = new System.Drawing.Point(917, 626);
            this.tasta853.Name = "tasta853";
            this.tasta853.Size = new System.Drawing.Size(13, 21);
            this.tasta853.TabIndex = 1267;
            // 
            // tasta854
            // 
            this.tasta854.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta854.Location = new System.Drawing.Point(897, 626);
            this.tasta854.Name = "tasta854";
            this.tasta854.Size = new System.Drawing.Size(13, 21);
            this.tasta854.TabIndex = 1266;
            // 
            // tasta855
            // 
            this.tasta855.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta855.Location = new System.Drawing.Point(878, 626);
            this.tasta855.Name = "tasta855";
            this.tasta855.Size = new System.Drawing.Size(13, 21);
            this.tasta855.TabIndex = 1265;
            // 
            // tasta856
            // 
            this.tasta856.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta856.Location = new System.Drawing.Point(859, 626);
            this.tasta856.Name = "tasta856";
            this.tasta856.Size = new System.Drawing.Size(13, 21);
            this.tasta856.TabIndex = 1264;
            // 
            // tasta857
            // 
            this.tasta857.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta857.Location = new System.Drawing.Point(840, 626);
            this.tasta857.Name = "tasta857";
            this.tasta857.Size = new System.Drawing.Size(13, 21);
            this.tasta857.TabIndex = 1263;
            // 
            // tasta858
            // 
            this.tasta858.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta858.Location = new System.Drawing.Point(821, 626);
            this.tasta858.Name = "tasta858";
            this.tasta858.Size = new System.Drawing.Size(13, 21);
            this.tasta858.TabIndex = 1262;
            // 
            // tasta859
            // 
            this.tasta859.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta859.Location = new System.Drawing.Point(802, 626);
            this.tasta859.Name = "tasta859";
            this.tasta859.Size = new System.Drawing.Size(13, 21);
            this.tasta859.TabIndex = 1261;
            // 
            // tasta860
            // 
            this.tasta860.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta860.Location = new System.Drawing.Point(783, 626);
            this.tasta860.Name = "tasta860";
            this.tasta860.Size = new System.Drawing.Size(13, 21);
            this.tasta860.TabIndex = 1260;
            // 
            // tasta861
            // 
            this.tasta861.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta861.Location = new System.Drawing.Point(764, 626);
            this.tasta861.Name = "tasta861";
            this.tasta861.Size = new System.Drawing.Size(13, 21);
            this.tasta861.TabIndex = 1259;
            // 
            // tasta862
            // 
            this.tasta862.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta862.Location = new System.Drawing.Point(745, 626);
            this.tasta862.Name = "tasta862";
            this.tasta862.Size = new System.Drawing.Size(13, 21);
            this.tasta862.TabIndex = 1258;
            // 
            // tasta863
            // 
            this.tasta863.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta863.Location = new System.Drawing.Point(726, 626);
            this.tasta863.Name = "tasta863";
            this.tasta863.Size = new System.Drawing.Size(13, 21);
            this.tasta863.TabIndex = 1257;
            // 
            // tasta864
            // 
            this.tasta864.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta864.Location = new System.Drawing.Point(707, 626);
            this.tasta864.Name = "tasta864";
            this.tasta864.Size = new System.Drawing.Size(13, 21);
            this.tasta864.TabIndex = 1256;
            // 
            // tasta865
            // 
            this.tasta865.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta865.Location = new System.Drawing.Point(688, 626);
            this.tasta865.Name = "tasta865";
            this.tasta865.Size = new System.Drawing.Size(13, 21);
            this.tasta865.TabIndex = 1255;
            // 
            // tasta866
            // 
            this.tasta866.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta866.Location = new System.Drawing.Point(669, 626);
            this.tasta866.Name = "tasta866";
            this.tasta866.Size = new System.Drawing.Size(13, 21);
            this.tasta866.TabIndex = 1254;
            // 
            // tasta867
            // 
            this.tasta867.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta867.Location = new System.Drawing.Point(650, 626);
            this.tasta867.Name = "tasta867";
            this.tasta867.Size = new System.Drawing.Size(13, 21);
            this.tasta867.TabIndex = 1253;
            // 
            // tasta868
            // 
            this.tasta868.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta868.Location = new System.Drawing.Point(631, 626);
            this.tasta868.Name = "tasta868";
            this.tasta868.Size = new System.Drawing.Size(13, 21);
            this.tasta868.TabIndex = 1252;
            // 
            // tasta869
            // 
            this.tasta869.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta869.Location = new System.Drawing.Point(612, 626);
            this.tasta869.Name = "tasta869";
            this.tasta869.Size = new System.Drawing.Size(13, 21);
            this.tasta869.TabIndex = 1251;
            // 
            // tasta870
            // 
            this.tasta870.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta870.Location = new System.Drawing.Point(593, 626);
            this.tasta870.Name = "tasta870";
            this.tasta870.Size = new System.Drawing.Size(13, 21);
            this.tasta870.TabIndex = 1250;
            // 
            // tasta871
            // 
            this.tasta871.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta871.Location = new System.Drawing.Point(574, 626);
            this.tasta871.Name = "tasta871";
            this.tasta871.Size = new System.Drawing.Size(13, 21);
            this.tasta871.TabIndex = 1249;
            // 
            // tasta872
            // 
            this.tasta872.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta872.Location = new System.Drawing.Point(555, 626);
            this.tasta872.Name = "tasta872";
            this.tasta872.Size = new System.Drawing.Size(13, 21);
            this.tasta872.TabIndex = 1248;
            // 
            // tasta873
            // 
            this.tasta873.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta873.Location = new System.Drawing.Point(536, 626);
            this.tasta873.Name = "tasta873";
            this.tasta873.Size = new System.Drawing.Size(13, 21);
            this.tasta873.TabIndex = 1247;
            // 
            // tasta874
            // 
            this.tasta874.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta874.Location = new System.Drawing.Point(517, 626);
            this.tasta874.Name = "tasta874";
            this.tasta874.Size = new System.Drawing.Size(13, 21);
            this.tasta874.TabIndex = 1246;
            // 
            // tasta875
            // 
            this.tasta875.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta875.Location = new System.Drawing.Point(498, 626);
            this.tasta875.Name = "tasta875";
            this.tasta875.Size = new System.Drawing.Size(13, 21);
            this.tasta875.TabIndex = 1245;
            // 
            // tasta876
            // 
            this.tasta876.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta876.Location = new System.Drawing.Point(479, 626);
            this.tasta876.Name = "tasta876";
            this.tasta876.Size = new System.Drawing.Size(13, 21);
            this.tasta876.TabIndex = 1244;
            // 
            // tasta877
            // 
            this.tasta877.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta877.Location = new System.Drawing.Point(460, 626);
            this.tasta877.Name = "tasta877";
            this.tasta877.Size = new System.Drawing.Size(13, 21);
            this.tasta877.TabIndex = 1243;
            // 
            // tasta878
            // 
            this.tasta878.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta878.Location = new System.Drawing.Point(441, 626);
            this.tasta878.Name = "tasta878";
            this.tasta878.Size = new System.Drawing.Size(13, 21);
            this.tasta878.TabIndex = 1242;
            // 
            // tasta879
            // 
            this.tasta879.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta879.Location = new System.Drawing.Point(422, 626);
            this.tasta879.Name = "tasta879";
            this.tasta879.Size = new System.Drawing.Size(13, 21);
            this.tasta879.TabIndex = 1241;
            // 
            // tasta880
            // 
            this.tasta880.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta880.Location = new System.Drawing.Point(403, 626);
            this.tasta880.Name = "tasta880";
            this.tasta880.Size = new System.Drawing.Size(13, 21);
            this.tasta880.TabIndex = 1240;
            // 
            // tasta881
            // 
            this.tasta881.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta881.Location = new System.Drawing.Point(384, 626);
            this.tasta881.Name = "tasta881";
            this.tasta881.Size = new System.Drawing.Size(13, 21);
            this.tasta881.TabIndex = 1239;
            // 
            // tasta882
            // 
            this.tasta882.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta882.Location = new System.Drawing.Point(365, 626);
            this.tasta882.Name = "tasta882";
            this.tasta882.Size = new System.Drawing.Size(13, 21);
            this.tasta882.TabIndex = 1238;
            // 
            // tasta883
            // 
            this.tasta883.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta883.Location = new System.Drawing.Point(346, 626);
            this.tasta883.Name = "tasta883";
            this.tasta883.Size = new System.Drawing.Size(13, 21);
            this.tasta883.TabIndex = 1237;
            // 
            // tasta884
            // 
            this.tasta884.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta884.Location = new System.Drawing.Point(327, 626);
            this.tasta884.Name = "tasta884";
            this.tasta884.Size = new System.Drawing.Size(13, 21);
            this.tasta884.TabIndex = 1236;
            // 
            // tasta885
            // 
            this.tasta885.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta885.Location = new System.Drawing.Point(308, 626);
            this.tasta885.Name = "tasta885";
            this.tasta885.Size = new System.Drawing.Size(13, 21);
            this.tasta885.TabIndex = 1235;
            // 
            // tasta886
            // 
            this.tasta886.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta886.Location = new System.Drawing.Point(289, 626);
            this.tasta886.Name = "tasta886";
            this.tasta886.Size = new System.Drawing.Size(13, 21);
            this.tasta886.TabIndex = 1234;
            // 
            // tasta887
            // 
            this.tasta887.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta887.Location = new System.Drawing.Point(270, 626);
            this.tasta887.Name = "tasta887";
            this.tasta887.Size = new System.Drawing.Size(13, 21);
            this.tasta887.TabIndex = 1233;
            // 
            // tasta888
            // 
            this.tasta888.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta888.Location = new System.Drawing.Point(251, 626);
            this.tasta888.Name = "tasta888";
            this.tasta888.Size = new System.Drawing.Size(13, 21);
            this.tasta888.TabIndex = 1232;
            // 
            // tasta889
            // 
            this.tasta889.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta889.Location = new System.Drawing.Point(232, 626);
            this.tasta889.Name = "tasta889";
            this.tasta889.Size = new System.Drawing.Size(13, 21);
            this.tasta889.TabIndex = 1231;
            // 
            // tasta890
            // 
            this.tasta890.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta890.Location = new System.Drawing.Point(213, 626);
            this.tasta890.Name = "tasta890";
            this.tasta890.Size = new System.Drawing.Size(13, 21);
            this.tasta890.TabIndex = 1230;
            // 
            // tasta891
            // 
            this.tasta891.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta891.Location = new System.Drawing.Point(194, 626);
            this.tasta891.Name = "tasta891";
            this.tasta891.Size = new System.Drawing.Size(13, 21);
            this.tasta891.TabIndex = 1229;
            // 
            // tasta892
            // 
            this.tasta892.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta892.Location = new System.Drawing.Point(175, 626);
            this.tasta892.Name = "tasta892";
            this.tasta892.Size = new System.Drawing.Size(13, 21);
            this.tasta892.TabIndex = 1228;
            // 
            // tasta893
            // 
            this.tasta893.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta893.Location = new System.Drawing.Point(156, 626);
            this.tasta893.Name = "tasta893";
            this.tasta893.Size = new System.Drawing.Size(13, 21);
            this.tasta893.TabIndex = 1227;
            // 
            // tasta894
            // 
            this.tasta894.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta894.Location = new System.Drawing.Point(137, 626);
            this.tasta894.Name = "tasta894";
            this.tasta894.Size = new System.Drawing.Size(13, 21);
            this.tasta894.TabIndex = 1226;
            // 
            // tasta895
            // 
            this.tasta895.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta895.Location = new System.Drawing.Point(118, 626);
            this.tasta895.Name = "tasta895";
            this.tasta895.Size = new System.Drawing.Size(13, 21);
            this.tasta895.TabIndex = 1225;
            // 
            // tasta896
            // 
            this.tasta896.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta896.Location = new System.Drawing.Point(99, 626);
            this.tasta896.Name = "tasta896";
            this.tasta896.Size = new System.Drawing.Size(13, 21);
            this.tasta896.TabIndex = 1224;
            // 
            // tasta897
            // 
            this.tasta897.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta897.Location = new System.Drawing.Point(80, 626);
            this.tasta897.Name = "tasta897";
            this.tasta897.Size = new System.Drawing.Size(13, 21);
            this.tasta897.TabIndex = 1223;
            // 
            // tasta898
            // 
            this.tasta898.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta898.Location = new System.Drawing.Point(61, 626);
            this.tasta898.Name = "tasta898";
            this.tasta898.Size = new System.Drawing.Size(13, 21);
            this.tasta898.TabIndex = 1222;
            // 
            // tasta899
            // 
            this.tasta899.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta899.Location = new System.Drawing.Point(42, 626);
            this.tasta899.Name = "tasta899";
            this.tasta899.Size = new System.Drawing.Size(13, 21);
            this.tasta899.TabIndex = 1221;
            // 
            // tasta900
            // 
            this.tasta900.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta900.Location = new System.Drawing.Point(23, 626);
            this.tasta900.Name = "tasta900";
            this.tasta900.Size = new System.Drawing.Size(13, 21);
            this.tasta900.TabIndex = 1220;
            // 
            // tasta901
            // 
            this.tasta901.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta901.Location = new System.Drawing.Point(4, 626);
            this.tasta901.Name = "tasta901";
            this.tasta901.Size = new System.Drawing.Size(13, 21);
            this.tasta901.TabIndex = 1219;
            // 
            // tasta902
            // 
            this.tasta902.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta902.Location = new System.Drawing.Point(993, 599);
            this.tasta902.Name = "tasta902";
            this.tasta902.Size = new System.Drawing.Size(13, 21);
            this.tasta902.TabIndex = 1218;
            // 
            // tasta903
            // 
            this.tasta903.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta903.Location = new System.Drawing.Point(974, 599);
            this.tasta903.Name = "tasta903";
            this.tasta903.Size = new System.Drawing.Size(13, 21);
            this.tasta903.TabIndex = 1217;
            // 
            // tasta904
            // 
            this.tasta904.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta904.Location = new System.Drawing.Point(955, 599);
            this.tasta904.Name = "tasta904";
            this.tasta904.Size = new System.Drawing.Size(13, 21);
            this.tasta904.TabIndex = 1216;
            // 
            // tasta905
            // 
            this.tasta905.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta905.Location = new System.Drawing.Point(936, 599);
            this.tasta905.Name = "tasta905";
            this.tasta905.Size = new System.Drawing.Size(13, 21);
            this.tasta905.TabIndex = 1215;
            // 
            // tasta906
            // 
            this.tasta906.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta906.Location = new System.Drawing.Point(917, 599);
            this.tasta906.Name = "tasta906";
            this.tasta906.Size = new System.Drawing.Size(13, 21);
            this.tasta906.TabIndex = 1214;
            // 
            // tasta907
            // 
            this.tasta907.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta907.Location = new System.Drawing.Point(897, 599);
            this.tasta907.Name = "tasta907";
            this.tasta907.Size = new System.Drawing.Size(13, 21);
            this.tasta907.TabIndex = 1213;
            // 
            // tasta908
            // 
            this.tasta908.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta908.Location = new System.Drawing.Point(878, 599);
            this.tasta908.Name = "tasta908";
            this.tasta908.Size = new System.Drawing.Size(13, 21);
            this.tasta908.TabIndex = 1212;
            // 
            // tasta909
            // 
            this.tasta909.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta909.Location = new System.Drawing.Point(859, 599);
            this.tasta909.Name = "tasta909";
            this.tasta909.Size = new System.Drawing.Size(13, 21);
            this.tasta909.TabIndex = 1211;
            // 
            // tasta910
            // 
            this.tasta910.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta910.Location = new System.Drawing.Point(840, 599);
            this.tasta910.Name = "tasta910";
            this.tasta910.Size = new System.Drawing.Size(13, 21);
            this.tasta910.TabIndex = 1210;
            // 
            // tasta911
            // 
            this.tasta911.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta911.Location = new System.Drawing.Point(821, 599);
            this.tasta911.Name = "tasta911";
            this.tasta911.Size = new System.Drawing.Size(13, 21);
            this.tasta911.TabIndex = 1209;
            // 
            // tasta912
            // 
            this.tasta912.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta912.Location = new System.Drawing.Point(802, 599);
            this.tasta912.Name = "tasta912";
            this.tasta912.Size = new System.Drawing.Size(13, 21);
            this.tasta912.TabIndex = 1208;
            // 
            // tasta913
            // 
            this.tasta913.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta913.Location = new System.Drawing.Point(783, 599);
            this.tasta913.Name = "tasta913";
            this.tasta913.Size = new System.Drawing.Size(13, 21);
            this.tasta913.TabIndex = 1207;
            // 
            // tasta914
            // 
            this.tasta914.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta914.Location = new System.Drawing.Point(764, 599);
            this.tasta914.Name = "tasta914";
            this.tasta914.Size = new System.Drawing.Size(13, 21);
            this.tasta914.TabIndex = 1206;
            // 
            // tasta915
            // 
            this.tasta915.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta915.Location = new System.Drawing.Point(745, 599);
            this.tasta915.Name = "tasta915";
            this.tasta915.Size = new System.Drawing.Size(13, 21);
            this.tasta915.TabIndex = 1205;
            // 
            // tasta916
            // 
            this.tasta916.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta916.Location = new System.Drawing.Point(726, 599);
            this.tasta916.Name = "tasta916";
            this.tasta916.Size = new System.Drawing.Size(13, 21);
            this.tasta916.TabIndex = 1204;
            // 
            // tasta917
            // 
            this.tasta917.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta917.Location = new System.Drawing.Point(707, 599);
            this.tasta917.Name = "tasta917";
            this.tasta917.Size = new System.Drawing.Size(13, 21);
            this.tasta917.TabIndex = 1203;
            // 
            // tasta918
            // 
            this.tasta918.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta918.Location = new System.Drawing.Point(688, 599);
            this.tasta918.Name = "tasta918";
            this.tasta918.Size = new System.Drawing.Size(13, 21);
            this.tasta918.TabIndex = 1202;
            // 
            // tasta919
            // 
            this.tasta919.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta919.Location = new System.Drawing.Point(669, 599);
            this.tasta919.Name = "tasta919";
            this.tasta919.Size = new System.Drawing.Size(13, 21);
            this.tasta919.TabIndex = 1201;
            // 
            // tasta920
            // 
            this.tasta920.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta920.Location = new System.Drawing.Point(650, 599);
            this.tasta920.Name = "tasta920";
            this.tasta920.Size = new System.Drawing.Size(13, 21);
            this.tasta920.TabIndex = 1200;
            // 
            // tasta921
            // 
            this.tasta921.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta921.Location = new System.Drawing.Point(631, 599);
            this.tasta921.Name = "tasta921";
            this.tasta921.Size = new System.Drawing.Size(13, 21);
            this.tasta921.TabIndex = 1199;
            // 
            // tasta922
            // 
            this.tasta922.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta922.Location = new System.Drawing.Point(612, 599);
            this.tasta922.Name = "tasta922";
            this.tasta922.Size = new System.Drawing.Size(13, 21);
            this.tasta922.TabIndex = 1198;
            // 
            // tasta923
            // 
            this.tasta923.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta923.Location = new System.Drawing.Point(593, 599);
            this.tasta923.Name = "tasta923";
            this.tasta923.Size = new System.Drawing.Size(13, 21);
            this.tasta923.TabIndex = 1197;
            // 
            // tasta924
            // 
            this.tasta924.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta924.Location = new System.Drawing.Point(574, 599);
            this.tasta924.Name = "tasta924";
            this.tasta924.Size = new System.Drawing.Size(13, 21);
            this.tasta924.TabIndex = 1196;
            // 
            // tasta925
            // 
            this.tasta925.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta925.Location = new System.Drawing.Point(555, 599);
            this.tasta925.Name = "tasta925";
            this.tasta925.Size = new System.Drawing.Size(13, 21);
            this.tasta925.TabIndex = 1195;
            // 
            // tasta926
            // 
            this.tasta926.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta926.Location = new System.Drawing.Point(536, 599);
            this.tasta926.Name = "tasta926";
            this.tasta926.Size = new System.Drawing.Size(13, 21);
            this.tasta926.TabIndex = 1194;
            // 
            // tasta927
            // 
            this.tasta927.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta927.Location = new System.Drawing.Point(517, 599);
            this.tasta927.Name = "tasta927";
            this.tasta927.Size = new System.Drawing.Size(13, 21);
            this.tasta927.TabIndex = 1193;
            // 
            // tasta928
            // 
            this.tasta928.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta928.Location = new System.Drawing.Point(498, 599);
            this.tasta928.Name = "tasta928";
            this.tasta928.Size = new System.Drawing.Size(13, 21);
            this.tasta928.TabIndex = 1192;
            // 
            // tasta929
            // 
            this.tasta929.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta929.Location = new System.Drawing.Point(479, 599);
            this.tasta929.Name = "tasta929";
            this.tasta929.Size = new System.Drawing.Size(13, 21);
            this.tasta929.TabIndex = 1191;
            // 
            // tasta930
            // 
            this.tasta930.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta930.Location = new System.Drawing.Point(460, 599);
            this.tasta930.Name = "tasta930";
            this.tasta930.Size = new System.Drawing.Size(13, 21);
            this.tasta930.TabIndex = 1190;
            // 
            // tasta931
            // 
            this.tasta931.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta931.Location = new System.Drawing.Point(441, 599);
            this.tasta931.Name = "tasta931";
            this.tasta931.Size = new System.Drawing.Size(13, 21);
            this.tasta931.TabIndex = 1189;
            // 
            // tasta932
            // 
            this.tasta932.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta932.Location = new System.Drawing.Point(422, 599);
            this.tasta932.Name = "tasta932";
            this.tasta932.Size = new System.Drawing.Size(13, 21);
            this.tasta932.TabIndex = 1188;
            // 
            // tasta933
            // 
            this.tasta933.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta933.Location = new System.Drawing.Point(403, 599);
            this.tasta933.Name = "tasta933";
            this.tasta933.Size = new System.Drawing.Size(13, 21);
            this.tasta933.TabIndex = 1187;
            // 
            // tasta934
            // 
            this.tasta934.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta934.Location = new System.Drawing.Point(384, 599);
            this.tasta934.Name = "tasta934";
            this.tasta934.Size = new System.Drawing.Size(13, 21);
            this.tasta934.TabIndex = 1186;
            // 
            // tasta935
            // 
            this.tasta935.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta935.Location = new System.Drawing.Point(365, 599);
            this.tasta935.Name = "tasta935";
            this.tasta935.Size = new System.Drawing.Size(13, 21);
            this.tasta935.TabIndex = 1185;
            // 
            // tasta936
            // 
            this.tasta936.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta936.Location = new System.Drawing.Point(346, 599);
            this.tasta936.Name = "tasta936";
            this.tasta936.Size = new System.Drawing.Size(13, 21);
            this.tasta936.TabIndex = 1184;
            // 
            // tasta937
            // 
            this.tasta937.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta937.Location = new System.Drawing.Point(327, 599);
            this.tasta937.Name = "tasta937";
            this.tasta937.Size = new System.Drawing.Size(13, 21);
            this.tasta937.TabIndex = 1183;
            // 
            // tasta938
            // 
            this.tasta938.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta938.Location = new System.Drawing.Point(308, 599);
            this.tasta938.Name = "tasta938";
            this.tasta938.Size = new System.Drawing.Size(13, 21);
            this.tasta938.TabIndex = 1182;
            // 
            // tasta939
            // 
            this.tasta939.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta939.Location = new System.Drawing.Point(289, 599);
            this.tasta939.Name = "tasta939";
            this.tasta939.Size = new System.Drawing.Size(13, 21);
            this.tasta939.TabIndex = 1181;
            // 
            // tasta940
            // 
            this.tasta940.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta940.Location = new System.Drawing.Point(270, 599);
            this.tasta940.Name = "tasta940";
            this.tasta940.Size = new System.Drawing.Size(13, 21);
            this.tasta940.TabIndex = 1180;
            // 
            // tasta941
            // 
            this.tasta941.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta941.Location = new System.Drawing.Point(251, 599);
            this.tasta941.Name = "tasta941";
            this.tasta941.Size = new System.Drawing.Size(13, 21);
            this.tasta941.TabIndex = 1179;
            // 
            // tasta942
            // 
            this.tasta942.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta942.Location = new System.Drawing.Point(232, 599);
            this.tasta942.Name = "tasta942";
            this.tasta942.Size = new System.Drawing.Size(13, 21);
            this.tasta942.TabIndex = 1178;
            // 
            // tasta943
            // 
            this.tasta943.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta943.Location = new System.Drawing.Point(213, 599);
            this.tasta943.Name = "tasta943";
            this.tasta943.Size = new System.Drawing.Size(13, 21);
            this.tasta943.TabIndex = 1177;
            // 
            // tasta944
            // 
            this.tasta944.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta944.Location = new System.Drawing.Point(194, 599);
            this.tasta944.Name = "tasta944";
            this.tasta944.Size = new System.Drawing.Size(13, 21);
            this.tasta944.TabIndex = 1176;
            // 
            // tasta945
            // 
            this.tasta945.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta945.Location = new System.Drawing.Point(175, 599);
            this.tasta945.Name = "tasta945";
            this.tasta945.Size = new System.Drawing.Size(13, 21);
            this.tasta945.TabIndex = 1175;
            // 
            // tasta946
            // 
            this.tasta946.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta946.Location = new System.Drawing.Point(156, 599);
            this.tasta946.Name = "tasta946";
            this.tasta946.Size = new System.Drawing.Size(13, 21);
            this.tasta946.TabIndex = 1174;
            // 
            // tasta947
            // 
            this.tasta947.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta947.Location = new System.Drawing.Point(137, 599);
            this.tasta947.Name = "tasta947";
            this.tasta947.Size = new System.Drawing.Size(13, 21);
            this.tasta947.TabIndex = 1173;
            // 
            // tasta948
            // 
            this.tasta948.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta948.Location = new System.Drawing.Point(118, 599);
            this.tasta948.Name = "tasta948";
            this.tasta948.Size = new System.Drawing.Size(13, 21);
            this.tasta948.TabIndex = 1172;
            // 
            // tasta949
            // 
            this.tasta949.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta949.Location = new System.Drawing.Point(99, 599);
            this.tasta949.Name = "tasta949";
            this.tasta949.Size = new System.Drawing.Size(13, 21);
            this.tasta949.TabIndex = 1171;
            // 
            // tasta950
            // 
            this.tasta950.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta950.Location = new System.Drawing.Point(80, 599);
            this.tasta950.Name = "tasta950";
            this.tasta950.Size = new System.Drawing.Size(13, 21);
            this.tasta950.TabIndex = 1170;
            // 
            // tasta951
            // 
            this.tasta951.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta951.Location = new System.Drawing.Point(61, 599);
            this.tasta951.Name = "tasta951";
            this.tasta951.Size = new System.Drawing.Size(13, 21);
            this.tasta951.TabIndex = 1169;
            // 
            // tasta952
            // 
            this.tasta952.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta952.Location = new System.Drawing.Point(42, 599);
            this.tasta952.Name = "tasta952";
            this.tasta952.Size = new System.Drawing.Size(13, 21);
            this.tasta952.TabIndex = 1168;
            // 
            // tasta953
            // 
            this.tasta953.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta953.Location = new System.Drawing.Point(23, 599);
            this.tasta953.Name = "tasta953";
            this.tasta953.Size = new System.Drawing.Size(13, 21);
            this.tasta953.TabIndex = 1167;
            // 
            // tasta954
            // 
            this.tasta954.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta954.Location = new System.Drawing.Point(4, 599);
            this.tasta954.Name = "tasta954";
            this.tasta954.Size = new System.Drawing.Size(13, 21);
            this.tasta954.TabIndex = 1166;
            // 
            // tasta955
            // 
            this.tasta955.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta955.Location = new System.Drawing.Point(993, 572);
            this.tasta955.Name = "tasta955";
            this.tasta955.Size = new System.Drawing.Size(13, 21);
            this.tasta955.TabIndex = 1165;
            // 
            // tasta956
            // 
            this.tasta956.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta956.Location = new System.Drawing.Point(974, 572);
            this.tasta956.Name = "tasta956";
            this.tasta956.Size = new System.Drawing.Size(13, 21);
            this.tasta956.TabIndex = 1164;
            // 
            // tasta957
            // 
            this.tasta957.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta957.Location = new System.Drawing.Point(955, 572);
            this.tasta957.Name = "tasta957";
            this.tasta957.Size = new System.Drawing.Size(13, 21);
            this.tasta957.TabIndex = 1163;
            // 
            // tasta958
            // 
            this.tasta958.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta958.Location = new System.Drawing.Point(936, 572);
            this.tasta958.Name = "tasta958";
            this.tasta958.Size = new System.Drawing.Size(13, 21);
            this.tasta958.TabIndex = 1162;
            // 
            // tasta959
            // 
            this.tasta959.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta959.Location = new System.Drawing.Point(917, 572);
            this.tasta959.Name = "tasta959";
            this.tasta959.Size = new System.Drawing.Size(13, 21);
            this.tasta959.TabIndex = 1161;
            // 
            // tasta960
            // 
            this.tasta960.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta960.Location = new System.Drawing.Point(897, 572);
            this.tasta960.Name = "tasta960";
            this.tasta960.Size = new System.Drawing.Size(13, 21);
            this.tasta960.TabIndex = 1160;
            // 
            // tasta961
            // 
            this.tasta961.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta961.Location = new System.Drawing.Point(878, 572);
            this.tasta961.Name = "tasta961";
            this.tasta961.Size = new System.Drawing.Size(13, 21);
            this.tasta961.TabIndex = 1159;
            // 
            // tasta962
            // 
            this.tasta962.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta962.Location = new System.Drawing.Point(859, 572);
            this.tasta962.Name = "tasta962";
            this.tasta962.Size = new System.Drawing.Size(13, 21);
            this.tasta962.TabIndex = 1158;
            // 
            // tasta963
            // 
            this.tasta963.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta963.Location = new System.Drawing.Point(840, 572);
            this.tasta963.Name = "tasta963";
            this.tasta963.Size = new System.Drawing.Size(13, 21);
            this.tasta963.TabIndex = 1157;
            // 
            // tasta964
            // 
            this.tasta964.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta964.Location = new System.Drawing.Point(821, 572);
            this.tasta964.Name = "tasta964";
            this.tasta964.Size = new System.Drawing.Size(13, 21);
            this.tasta964.TabIndex = 1156;
            // 
            // tasta965
            // 
            this.tasta965.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta965.Location = new System.Drawing.Point(802, 572);
            this.tasta965.Name = "tasta965";
            this.tasta965.Size = new System.Drawing.Size(13, 21);
            this.tasta965.TabIndex = 1155;
            // 
            // tasta966
            // 
            this.tasta966.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta966.Location = new System.Drawing.Point(783, 572);
            this.tasta966.Name = "tasta966";
            this.tasta966.Size = new System.Drawing.Size(13, 21);
            this.tasta966.TabIndex = 1154;
            // 
            // tasta967
            // 
            this.tasta967.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta967.Location = new System.Drawing.Point(764, 572);
            this.tasta967.Name = "tasta967";
            this.tasta967.Size = new System.Drawing.Size(13, 21);
            this.tasta967.TabIndex = 1153;
            // 
            // tasta968
            // 
            this.tasta968.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta968.Location = new System.Drawing.Point(745, 572);
            this.tasta968.Name = "tasta968";
            this.tasta968.Size = new System.Drawing.Size(13, 21);
            this.tasta968.TabIndex = 1152;
            // 
            // tasta969
            // 
            this.tasta969.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta969.Location = new System.Drawing.Point(726, 572);
            this.tasta969.Name = "tasta969";
            this.tasta969.Size = new System.Drawing.Size(13, 21);
            this.tasta969.TabIndex = 1151;
            // 
            // tasta970
            // 
            this.tasta970.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta970.Location = new System.Drawing.Point(707, 572);
            this.tasta970.Name = "tasta970";
            this.tasta970.Size = new System.Drawing.Size(13, 21);
            this.tasta970.TabIndex = 1150;
            // 
            // tasta971
            // 
            this.tasta971.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta971.Location = new System.Drawing.Point(688, 572);
            this.tasta971.Name = "tasta971";
            this.tasta971.Size = new System.Drawing.Size(13, 21);
            this.tasta971.TabIndex = 1149;
            // 
            // tasta972
            // 
            this.tasta972.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta972.Location = new System.Drawing.Point(669, 572);
            this.tasta972.Name = "tasta972";
            this.tasta972.Size = new System.Drawing.Size(13, 21);
            this.tasta972.TabIndex = 1148;
            // 
            // tasta973
            // 
            this.tasta973.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta973.Location = new System.Drawing.Point(650, 572);
            this.tasta973.Name = "tasta973";
            this.tasta973.Size = new System.Drawing.Size(13, 21);
            this.tasta973.TabIndex = 1147;
            // 
            // tasta974
            // 
            this.tasta974.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta974.Location = new System.Drawing.Point(631, 572);
            this.tasta974.Name = "tasta974";
            this.tasta974.Size = new System.Drawing.Size(13, 21);
            this.tasta974.TabIndex = 1146;
            // 
            // tasta975
            // 
            this.tasta975.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta975.Location = new System.Drawing.Point(612, 572);
            this.tasta975.Name = "tasta975";
            this.tasta975.Size = new System.Drawing.Size(13, 21);
            this.tasta975.TabIndex = 1145;
            // 
            // tasta976
            // 
            this.tasta976.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta976.Location = new System.Drawing.Point(593, 572);
            this.tasta976.Name = "tasta976";
            this.tasta976.Size = new System.Drawing.Size(13, 21);
            this.tasta976.TabIndex = 1144;
            // 
            // tasta977
            // 
            this.tasta977.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta977.Location = new System.Drawing.Point(574, 572);
            this.tasta977.Name = "tasta977";
            this.tasta977.Size = new System.Drawing.Size(13, 21);
            this.tasta977.TabIndex = 1143;
            // 
            // tasta978
            // 
            this.tasta978.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta978.Location = new System.Drawing.Point(555, 572);
            this.tasta978.Name = "tasta978";
            this.tasta978.Size = new System.Drawing.Size(13, 21);
            this.tasta978.TabIndex = 1142;
            // 
            // tasta979
            // 
            this.tasta979.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta979.Location = new System.Drawing.Point(536, 572);
            this.tasta979.Name = "tasta979";
            this.tasta979.Size = new System.Drawing.Size(13, 21);
            this.tasta979.TabIndex = 1141;
            // 
            // tasta980
            // 
            this.tasta980.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta980.Location = new System.Drawing.Point(517, 572);
            this.tasta980.Name = "tasta980";
            this.tasta980.Size = new System.Drawing.Size(13, 21);
            this.tasta980.TabIndex = 1140;
            // 
            // tasta981
            // 
            this.tasta981.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta981.Location = new System.Drawing.Point(498, 572);
            this.tasta981.Name = "tasta981";
            this.tasta981.Size = new System.Drawing.Size(13, 21);
            this.tasta981.TabIndex = 1139;
            // 
            // tasta982
            // 
            this.tasta982.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta982.Location = new System.Drawing.Point(479, 572);
            this.tasta982.Name = "tasta982";
            this.tasta982.Size = new System.Drawing.Size(13, 21);
            this.tasta982.TabIndex = 1138;
            // 
            // tasta983
            // 
            this.tasta983.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta983.Location = new System.Drawing.Point(460, 572);
            this.tasta983.Name = "tasta983";
            this.tasta983.Size = new System.Drawing.Size(13, 21);
            this.tasta983.TabIndex = 1137;
            // 
            // tasta984
            // 
            this.tasta984.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta984.Location = new System.Drawing.Point(441, 572);
            this.tasta984.Name = "tasta984";
            this.tasta984.Size = new System.Drawing.Size(13, 21);
            this.tasta984.TabIndex = 1136;
            // 
            // tasta985
            // 
            this.tasta985.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta985.Location = new System.Drawing.Point(422, 572);
            this.tasta985.Name = "tasta985";
            this.tasta985.Size = new System.Drawing.Size(13, 21);
            this.tasta985.TabIndex = 1135;
            // 
            // tasta986
            // 
            this.tasta986.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta986.Location = new System.Drawing.Point(403, 572);
            this.tasta986.Name = "tasta986";
            this.tasta986.Size = new System.Drawing.Size(13, 21);
            this.tasta986.TabIndex = 1134;
            // 
            // tasta987
            // 
            this.tasta987.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta987.Location = new System.Drawing.Point(384, 572);
            this.tasta987.Name = "tasta987";
            this.tasta987.Size = new System.Drawing.Size(13, 21);
            this.tasta987.TabIndex = 1133;
            // 
            // tasta988
            // 
            this.tasta988.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta988.Location = new System.Drawing.Point(365, 572);
            this.tasta988.Name = "tasta988";
            this.tasta988.Size = new System.Drawing.Size(13, 21);
            this.tasta988.TabIndex = 1132;
            // 
            // tasta989
            // 
            this.tasta989.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta989.Location = new System.Drawing.Point(346, 572);
            this.tasta989.Name = "tasta989";
            this.tasta989.Size = new System.Drawing.Size(13, 21);
            this.tasta989.TabIndex = 1131;
            // 
            // tasta990
            // 
            this.tasta990.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta990.Location = new System.Drawing.Point(327, 572);
            this.tasta990.Name = "tasta990";
            this.tasta990.Size = new System.Drawing.Size(13, 21);
            this.tasta990.TabIndex = 1130;
            // 
            // tasta991
            // 
            this.tasta991.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta991.Location = new System.Drawing.Point(308, 572);
            this.tasta991.Name = "tasta991";
            this.tasta991.Size = new System.Drawing.Size(13, 21);
            this.tasta991.TabIndex = 1129;
            // 
            // tasta992
            // 
            this.tasta992.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta992.Location = new System.Drawing.Point(289, 572);
            this.tasta992.Name = "tasta992";
            this.tasta992.Size = new System.Drawing.Size(13, 21);
            this.tasta992.TabIndex = 1128;
            // 
            // tasta993
            // 
            this.tasta993.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta993.Location = new System.Drawing.Point(270, 572);
            this.tasta993.Name = "tasta993";
            this.tasta993.Size = new System.Drawing.Size(13, 21);
            this.tasta993.TabIndex = 1127;
            // 
            // tasta994
            // 
            this.tasta994.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta994.Location = new System.Drawing.Point(251, 572);
            this.tasta994.Name = "tasta994";
            this.tasta994.Size = new System.Drawing.Size(13, 21);
            this.tasta994.TabIndex = 1126;
            // 
            // tasta995
            // 
            this.tasta995.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta995.Location = new System.Drawing.Point(232, 572);
            this.tasta995.Name = "tasta995";
            this.tasta995.Size = new System.Drawing.Size(13, 21);
            this.tasta995.TabIndex = 1125;
            // 
            // tasta996
            // 
            this.tasta996.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta996.Location = new System.Drawing.Point(213, 572);
            this.tasta996.Name = "tasta996";
            this.tasta996.Size = new System.Drawing.Size(13, 21);
            this.tasta996.TabIndex = 1124;
            // 
            // tasta997
            // 
            this.tasta997.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta997.Location = new System.Drawing.Point(194, 572);
            this.tasta997.Name = "tasta997";
            this.tasta997.Size = new System.Drawing.Size(13, 21);
            this.tasta997.TabIndex = 1123;
            // 
            // tasta998
            // 
            this.tasta998.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta998.Location = new System.Drawing.Point(175, 572);
            this.tasta998.Name = "tasta998";
            this.tasta998.Size = new System.Drawing.Size(13, 21);
            this.tasta998.TabIndex = 1122;
            // 
            // tasta999
            // 
            this.tasta999.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta999.Location = new System.Drawing.Point(156, 572);
            this.tasta999.Name = "tasta999";
            this.tasta999.Size = new System.Drawing.Size(13, 21);
            this.tasta999.TabIndex = 1121;
            // 
            // tasta1000
            // 
            this.tasta1000.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1000.Location = new System.Drawing.Point(137, 572);
            this.tasta1000.Name = "tasta1000";
            this.tasta1000.Size = new System.Drawing.Size(13, 21);
            this.tasta1000.TabIndex = 1120;
            // 
            // tasta1001
            // 
            this.tasta1001.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1001.Location = new System.Drawing.Point(118, 572);
            this.tasta1001.Name = "tasta1001";
            this.tasta1001.Size = new System.Drawing.Size(13, 21);
            this.tasta1001.TabIndex = 1119;
            // 
            // tasta1002
            // 
            this.tasta1002.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1002.Location = new System.Drawing.Point(99, 572);
            this.tasta1002.Name = "tasta1002";
            this.tasta1002.Size = new System.Drawing.Size(13, 21);
            this.tasta1002.TabIndex = 1118;
            // 
            // tasta1003
            // 
            this.tasta1003.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1003.Location = new System.Drawing.Point(80, 572);
            this.tasta1003.Name = "tasta1003";
            this.tasta1003.Size = new System.Drawing.Size(13, 21);
            this.tasta1003.TabIndex = 1117;
            // 
            // tasta1004
            // 
            this.tasta1004.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1004.Location = new System.Drawing.Point(61, 572);
            this.tasta1004.Name = "tasta1004";
            this.tasta1004.Size = new System.Drawing.Size(13, 21);
            this.tasta1004.TabIndex = 1116;
            // 
            // tasta1005
            // 
            this.tasta1005.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1005.Location = new System.Drawing.Point(42, 572);
            this.tasta1005.Name = "tasta1005";
            this.tasta1005.Size = new System.Drawing.Size(13, 21);
            this.tasta1005.TabIndex = 1115;
            // 
            // tasta1006
            // 
            this.tasta1006.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1006.Location = new System.Drawing.Point(23, 572);
            this.tasta1006.Name = "tasta1006";
            this.tasta1006.Size = new System.Drawing.Size(13, 21);
            this.tasta1006.TabIndex = 1114;
            // 
            // tasta1007
            // 
            this.tasta1007.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1007.Location = new System.Drawing.Point(4, 572);
            this.tasta1007.Name = "tasta1007";
            this.tasta1007.Size = new System.Drawing.Size(13, 21);
            this.tasta1007.TabIndex = 1113;
            // 
            // tasta1008
            // 
            this.tasta1008.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1008.Location = new System.Drawing.Point(993, 545);
            this.tasta1008.Name = "tasta1008";
            this.tasta1008.Size = new System.Drawing.Size(13, 21);
            this.tasta1008.TabIndex = 1112;
            // 
            // tasta1009
            // 
            this.tasta1009.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1009.Location = new System.Drawing.Point(974, 545);
            this.tasta1009.Name = "tasta1009";
            this.tasta1009.Size = new System.Drawing.Size(13, 21);
            this.tasta1009.TabIndex = 1111;
            // 
            // tasta1010
            // 
            this.tasta1010.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1010.Location = new System.Drawing.Point(955, 545);
            this.tasta1010.Name = "tasta1010";
            this.tasta1010.Size = new System.Drawing.Size(13, 21);
            this.tasta1010.TabIndex = 1110;
            // 
            // tasta1011
            // 
            this.tasta1011.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1011.Location = new System.Drawing.Point(936, 545);
            this.tasta1011.Name = "tasta1011";
            this.tasta1011.Size = new System.Drawing.Size(13, 21);
            this.tasta1011.TabIndex = 1109;
            // 
            // tasta1012
            // 
            this.tasta1012.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1012.Location = new System.Drawing.Point(917, 545);
            this.tasta1012.Name = "tasta1012";
            this.tasta1012.Size = new System.Drawing.Size(13, 21);
            this.tasta1012.TabIndex = 1108;
            // 
            // tasta1013
            // 
            this.tasta1013.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1013.Location = new System.Drawing.Point(897, 545);
            this.tasta1013.Name = "tasta1013";
            this.tasta1013.Size = new System.Drawing.Size(13, 21);
            this.tasta1013.TabIndex = 1107;
            // 
            // tasta1014
            // 
            this.tasta1014.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1014.Location = new System.Drawing.Point(878, 545);
            this.tasta1014.Name = "tasta1014";
            this.tasta1014.Size = new System.Drawing.Size(13, 21);
            this.tasta1014.TabIndex = 1106;
            // 
            // tasta1015
            // 
            this.tasta1015.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1015.Location = new System.Drawing.Point(859, 545);
            this.tasta1015.Name = "tasta1015";
            this.tasta1015.Size = new System.Drawing.Size(13, 21);
            this.tasta1015.TabIndex = 1105;
            // 
            // tasta1016
            // 
            this.tasta1016.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1016.Location = new System.Drawing.Point(840, 545);
            this.tasta1016.Name = "tasta1016";
            this.tasta1016.Size = new System.Drawing.Size(13, 21);
            this.tasta1016.TabIndex = 1104;
            // 
            // tasta1017
            // 
            this.tasta1017.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1017.Location = new System.Drawing.Point(821, 545);
            this.tasta1017.Name = "tasta1017";
            this.tasta1017.Size = new System.Drawing.Size(13, 21);
            this.tasta1017.TabIndex = 1103;
            // 
            // tasta1018
            // 
            this.tasta1018.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1018.Location = new System.Drawing.Point(802, 545);
            this.tasta1018.Name = "tasta1018";
            this.tasta1018.Size = new System.Drawing.Size(13, 21);
            this.tasta1018.TabIndex = 1102;
            // 
            // tasta1019
            // 
            this.tasta1019.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1019.Location = new System.Drawing.Point(783, 545);
            this.tasta1019.Name = "tasta1019";
            this.tasta1019.Size = new System.Drawing.Size(13, 21);
            this.tasta1019.TabIndex = 1101;
            // 
            // tasta1020
            // 
            this.tasta1020.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1020.Location = new System.Drawing.Point(764, 545);
            this.tasta1020.Name = "tasta1020";
            this.tasta1020.Size = new System.Drawing.Size(13, 21);
            this.tasta1020.TabIndex = 1100;
            // 
            // tasta1021
            // 
            this.tasta1021.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1021.Location = new System.Drawing.Point(745, 545);
            this.tasta1021.Name = "tasta1021";
            this.tasta1021.Size = new System.Drawing.Size(13, 21);
            this.tasta1021.TabIndex = 1099;
            // 
            // tasta1022
            // 
            this.tasta1022.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1022.Location = new System.Drawing.Point(726, 545);
            this.tasta1022.Name = "tasta1022";
            this.tasta1022.Size = new System.Drawing.Size(13, 21);
            this.tasta1022.TabIndex = 1098;
            // 
            // tasta1023
            // 
            this.tasta1023.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1023.Location = new System.Drawing.Point(707, 545);
            this.tasta1023.Name = "tasta1023";
            this.tasta1023.Size = new System.Drawing.Size(13, 21);
            this.tasta1023.TabIndex = 1097;
            // 
            // tasta1024
            // 
            this.tasta1024.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1024.Location = new System.Drawing.Point(688, 545);
            this.tasta1024.Name = "tasta1024";
            this.tasta1024.Size = new System.Drawing.Size(13, 21);
            this.tasta1024.TabIndex = 1096;
            // 
            // tasta1025
            // 
            this.tasta1025.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1025.Location = new System.Drawing.Point(669, 545);
            this.tasta1025.Name = "tasta1025";
            this.tasta1025.Size = new System.Drawing.Size(13, 21);
            this.tasta1025.TabIndex = 1095;
            // 
            // tasta1026
            // 
            this.tasta1026.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1026.Location = new System.Drawing.Point(650, 545);
            this.tasta1026.Name = "tasta1026";
            this.tasta1026.Size = new System.Drawing.Size(13, 21);
            this.tasta1026.TabIndex = 1094;
            // 
            // tasta1027
            // 
            this.tasta1027.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1027.Location = new System.Drawing.Point(631, 545);
            this.tasta1027.Name = "tasta1027";
            this.tasta1027.Size = new System.Drawing.Size(13, 21);
            this.tasta1027.TabIndex = 1093;
            // 
            // tasta1028
            // 
            this.tasta1028.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1028.Location = new System.Drawing.Point(612, 545);
            this.tasta1028.Name = "tasta1028";
            this.tasta1028.Size = new System.Drawing.Size(13, 21);
            this.tasta1028.TabIndex = 1092;
            // 
            // tasta1029
            // 
            this.tasta1029.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1029.Location = new System.Drawing.Point(593, 545);
            this.tasta1029.Name = "tasta1029";
            this.tasta1029.Size = new System.Drawing.Size(13, 21);
            this.tasta1029.TabIndex = 1091;
            // 
            // tasta1030
            // 
            this.tasta1030.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1030.Location = new System.Drawing.Point(574, 545);
            this.tasta1030.Name = "tasta1030";
            this.tasta1030.Size = new System.Drawing.Size(13, 21);
            this.tasta1030.TabIndex = 1090;
            // 
            // tasta1031
            // 
            this.tasta1031.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1031.Location = new System.Drawing.Point(555, 545);
            this.tasta1031.Name = "tasta1031";
            this.tasta1031.Size = new System.Drawing.Size(13, 21);
            this.tasta1031.TabIndex = 1089;
            // 
            // tasta1032
            // 
            this.tasta1032.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1032.Location = new System.Drawing.Point(536, 545);
            this.tasta1032.Name = "tasta1032";
            this.tasta1032.Size = new System.Drawing.Size(13, 21);
            this.tasta1032.TabIndex = 1088;
            // 
            // tasta1033
            // 
            this.tasta1033.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1033.Location = new System.Drawing.Point(517, 545);
            this.tasta1033.Name = "tasta1033";
            this.tasta1033.Size = new System.Drawing.Size(13, 21);
            this.tasta1033.TabIndex = 1087;
            // 
            // tasta1034
            // 
            this.tasta1034.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1034.Location = new System.Drawing.Point(498, 545);
            this.tasta1034.Name = "tasta1034";
            this.tasta1034.Size = new System.Drawing.Size(13, 21);
            this.tasta1034.TabIndex = 1086;
            // 
            // tasta1035
            // 
            this.tasta1035.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1035.Location = new System.Drawing.Point(479, 545);
            this.tasta1035.Name = "tasta1035";
            this.tasta1035.Size = new System.Drawing.Size(13, 21);
            this.tasta1035.TabIndex = 1085;
            // 
            // tasta1036
            // 
            this.tasta1036.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1036.Location = new System.Drawing.Point(460, 545);
            this.tasta1036.Name = "tasta1036";
            this.tasta1036.Size = new System.Drawing.Size(13, 21);
            this.tasta1036.TabIndex = 1084;
            // 
            // tasta1037
            // 
            this.tasta1037.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1037.Location = new System.Drawing.Point(441, 545);
            this.tasta1037.Name = "tasta1037";
            this.tasta1037.Size = new System.Drawing.Size(13, 21);
            this.tasta1037.TabIndex = 1083;
            // 
            // tasta1038
            // 
            this.tasta1038.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1038.Location = new System.Drawing.Point(422, 545);
            this.tasta1038.Name = "tasta1038";
            this.tasta1038.Size = new System.Drawing.Size(13, 21);
            this.tasta1038.TabIndex = 1082;
            // 
            // tasta1039
            // 
            this.tasta1039.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1039.Location = new System.Drawing.Point(403, 545);
            this.tasta1039.Name = "tasta1039";
            this.tasta1039.Size = new System.Drawing.Size(13, 21);
            this.tasta1039.TabIndex = 1081;
            // 
            // tasta1040
            // 
            this.tasta1040.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1040.Location = new System.Drawing.Point(384, 545);
            this.tasta1040.Name = "tasta1040";
            this.tasta1040.Size = new System.Drawing.Size(13, 21);
            this.tasta1040.TabIndex = 1080;
            // 
            // tasta1041
            // 
            this.tasta1041.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1041.Location = new System.Drawing.Point(365, 545);
            this.tasta1041.Name = "tasta1041";
            this.tasta1041.Size = new System.Drawing.Size(13, 21);
            this.tasta1041.TabIndex = 1079;
            // 
            // tasta1042
            // 
            this.tasta1042.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1042.Location = new System.Drawing.Point(346, 545);
            this.tasta1042.Name = "tasta1042";
            this.tasta1042.Size = new System.Drawing.Size(13, 21);
            this.tasta1042.TabIndex = 1078;
            // 
            // tasta1043
            // 
            this.tasta1043.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1043.Location = new System.Drawing.Point(327, 545);
            this.tasta1043.Name = "tasta1043";
            this.tasta1043.Size = new System.Drawing.Size(13, 21);
            this.tasta1043.TabIndex = 1077;
            // 
            // tasta1044
            // 
            this.tasta1044.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1044.Location = new System.Drawing.Point(308, 545);
            this.tasta1044.Name = "tasta1044";
            this.tasta1044.Size = new System.Drawing.Size(13, 21);
            this.tasta1044.TabIndex = 1076;
            // 
            // tasta1045
            // 
            this.tasta1045.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1045.Location = new System.Drawing.Point(289, 545);
            this.tasta1045.Name = "tasta1045";
            this.tasta1045.Size = new System.Drawing.Size(13, 21);
            this.tasta1045.TabIndex = 1075;
            // 
            // tasta1046
            // 
            this.tasta1046.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1046.Location = new System.Drawing.Point(270, 545);
            this.tasta1046.Name = "tasta1046";
            this.tasta1046.Size = new System.Drawing.Size(13, 21);
            this.tasta1046.TabIndex = 1074;
            // 
            // tasta1047
            // 
            this.tasta1047.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1047.Location = new System.Drawing.Point(251, 545);
            this.tasta1047.Name = "tasta1047";
            this.tasta1047.Size = new System.Drawing.Size(13, 21);
            this.tasta1047.TabIndex = 1073;
            // 
            // tasta1048
            // 
            this.tasta1048.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1048.Location = new System.Drawing.Point(232, 545);
            this.tasta1048.Name = "tasta1048";
            this.tasta1048.Size = new System.Drawing.Size(13, 21);
            this.tasta1048.TabIndex = 1072;
            // 
            // tasta1049
            // 
            this.tasta1049.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1049.Location = new System.Drawing.Point(213, 545);
            this.tasta1049.Name = "tasta1049";
            this.tasta1049.Size = new System.Drawing.Size(13, 21);
            this.tasta1049.TabIndex = 1071;
            // 
            // tasta1050
            // 
            this.tasta1050.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1050.Location = new System.Drawing.Point(194, 545);
            this.tasta1050.Name = "tasta1050";
            this.tasta1050.Size = new System.Drawing.Size(13, 21);
            this.tasta1050.TabIndex = 1070;
            // 
            // tasta1051
            // 
            this.tasta1051.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1051.Location = new System.Drawing.Point(175, 545);
            this.tasta1051.Name = "tasta1051";
            this.tasta1051.Size = new System.Drawing.Size(13, 21);
            this.tasta1051.TabIndex = 1069;
            // 
            // tasta1052
            // 
            this.tasta1052.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1052.Location = new System.Drawing.Point(156, 545);
            this.tasta1052.Name = "tasta1052";
            this.tasta1052.Size = new System.Drawing.Size(13, 21);
            this.tasta1052.TabIndex = 1068;
            // 
            // tasta1053
            // 
            this.tasta1053.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1053.Location = new System.Drawing.Point(137, 545);
            this.tasta1053.Name = "tasta1053";
            this.tasta1053.Size = new System.Drawing.Size(13, 21);
            this.tasta1053.TabIndex = 1067;
            // 
            // tasta1054
            // 
            this.tasta1054.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1054.Location = new System.Drawing.Point(118, 545);
            this.tasta1054.Name = "tasta1054";
            this.tasta1054.Size = new System.Drawing.Size(13, 21);
            this.tasta1054.TabIndex = 1066;
            // 
            // tasta1055
            // 
            this.tasta1055.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1055.Location = new System.Drawing.Point(99, 545);
            this.tasta1055.Name = "tasta1055";
            this.tasta1055.Size = new System.Drawing.Size(13, 21);
            this.tasta1055.TabIndex = 1065;
            // 
            // tasta1056
            // 
            this.tasta1056.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1056.Location = new System.Drawing.Point(80, 545);
            this.tasta1056.Name = "tasta1056";
            this.tasta1056.Size = new System.Drawing.Size(13, 21);
            this.tasta1056.TabIndex = 1064;
            // 
            // tasta1057
            // 
            this.tasta1057.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1057.Location = new System.Drawing.Point(61, 545);
            this.tasta1057.Name = "tasta1057";
            this.tasta1057.Size = new System.Drawing.Size(13, 21);
            this.tasta1057.TabIndex = 1063;
            // 
            // tasta1058
            // 
            this.tasta1058.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1058.Location = new System.Drawing.Point(42, 545);
            this.tasta1058.Name = "tasta1058";
            this.tasta1058.Size = new System.Drawing.Size(13, 21);
            this.tasta1058.TabIndex = 1062;
            // 
            // tasta1059
            // 
            this.tasta1059.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1059.Location = new System.Drawing.Point(23, 545);
            this.tasta1059.Name = "tasta1059";
            this.tasta1059.Size = new System.Drawing.Size(13, 21);
            this.tasta1059.TabIndex = 1061;
            // 
            // tasta1060
            // 
            this.tasta1060.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1060.Location = new System.Drawing.Point(4, 545);
            this.tasta1060.Name = "tasta1060";
            this.tasta1060.Size = new System.Drawing.Size(13, 21);
            this.tasta1060.TabIndex = 1060;
            // 
            // tasta1061
            // 
            this.tasta1061.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1061.Location = new System.Drawing.Point(993, 518);
            this.tasta1061.Name = "tasta1061";
            this.tasta1061.Size = new System.Drawing.Size(13, 21);
            this.tasta1061.TabIndex = 1059;
            // 
            // tasta1062
            // 
            this.tasta1062.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1062.Location = new System.Drawing.Point(974, 518);
            this.tasta1062.Name = "tasta1062";
            this.tasta1062.Size = new System.Drawing.Size(13, 21);
            this.tasta1062.TabIndex = 1058;
            // 
            // tasta1063
            // 
            this.tasta1063.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1063.Location = new System.Drawing.Point(955, 518);
            this.tasta1063.Name = "tasta1063";
            this.tasta1063.Size = new System.Drawing.Size(13, 21);
            this.tasta1063.TabIndex = 1057;
            // 
            // tasta1064
            // 
            this.tasta1064.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1064.Location = new System.Drawing.Point(936, 518);
            this.tasta1064.Name = "tasta1064";
            this.tasta1064.Size = new System.Drawing.Size(13, 21);
            this.tasta1064.TabIndex = 1056;
            // 
            // tasta1065
            // 
            this.tasta1065.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1065.Location = new System.Drawing.Point(917, 518);
            this.tasta1065.Name = "tasta1065";
            this.tasta1065.Size = new System.Drawing.Size(13, 21);
            this.tasta1065.TabIndex = 1055;
            // 
            // tasta1066
            // 
            this.tasta1066.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1066.Location = new System.Drawing.Point(897, 518);
            this.tasta1066.Name = "tasta1066";
            this.tasta1066.Size = new System.Drawing.Size(13, 21);
            this.tasta1066.TabIndex = 1054;
            // 
            // tasta1067
            // 
            this.tasta1067.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1067.Location = new System.Drawing.Point(878, 518);
            this.tasta1067.Name = "tasta1067";
            this.tasta1067.Size = new System.Drawing.Size(13, 21);
            this.tasta1067.TabIndex = 1053;
            // 
            // tasta1068
            // 
            this.tasta1068.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1068.Location = new System.Drawing.Point(859, 518);
            this.tasta1068.Name = "tasta1068";
            this.tasta1068.Size = new System.Drawing.Size(13, 21);
            this.tasta1068.TabIndex = 1052;
            // 
            // tasta1069
            // 
            this.tasta1069.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1069.Location = new System.Drawing.Point(840, 518);
            this.tasta1069.Name = "tasta1069";
            this.tasta1069.Size = new System.Drawing.Size(13, 21);
            this.tasta1069.TabIndex = 1051;
            // 
            // tasta1070
            // 
            this.tasta1070.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1070.Location = new System.Drawing.Point(821, 518);
            this.tasta1070.Name = "tasta1070";
            this.tasta1070.Size = new System.Drawing.Size(13, 21);
            this.tasta1070.TabIndex = 1050;
            // 
            // tasta1071
            // 
            this.tasta1071.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1071.Location = new System.Drawing.Point(802, 518);
            this.tasta1071.Name = "tasta1071";
            this.tasta1071.Size = new System.Drawing.Size(13, 21);
            this.tasta1071.TabIndex = 1049;
            // 
            // tasta1072
            // 
            this.tasta1072.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1072.Location = new System.Drawing.Point(783, 518);
            this.tasta1072.Name = "tasta1072";
            this.tasta1072.Size = new System.Drawing.Size(13, 21);
            this.tasta1072.TabIndex = 1048;
            // 
            // tasta1073
            // 
            this.tasta1073.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1073.Location = new System.Drawing.Point(764, 518);
            this.tasta1073.Name = "tasta1073";
            this.tasta1073.Size = new System.Drawing.Size(13, 21);
            this.tasta1073.TabIndex = 1047;
            // 
            // tasta1074
            // 
            this.tasta1074.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1074.Location = new System.Drawing.Point(745, 518);
            this.tasta1074.Name = "tasta1074";
            this.tasta1074.Size = new System.Drawing.Size(13, 21);
            this.tasta1074.TabIndex = 1046;
            // 
            // tasta1075
            // 
            this.tasta1075.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1075.Location = new System.Drawing.Point(726, 518);
            this.tasta1075.Name = "tasta1075";
            this.tasta1075.Size = new System.Drawing.Size(13, 21);
            this.tasta1075.TabIndex = 1045;
            // 
            // tasta1076
            // 
            this.tasta1076.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1076.Location = new System.Drawing.Point(707, 518);
            this.tasta1076.Name = "tasta1076";
            this.tasta1076.Size = new System.Drawing.Size(13, 21);
            this.tasta1076.TabIndex = 1044;
            // 
            // tasta1077
            // 
            this.tasta1077.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1077.Location = new System.Drawing.Point(688, 518);
            this.tasta1077.Name = "tasta1077";
            this.tasta1077.Size = new System.Drawing.Size(13, 21);
            this.tasta1077.TabIndex = 1043;
            // 
            // tasta1078
            // 
            this.tasta1078.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1078.Location = new System.Drawing.Point(669, 518);
            this.tasta1078.Name = "tasta1078";
            this.tasta1078.Size = new System.Drawing.Size(13, 21);
            this.tasta1078.TabIndex = 1042;
            // 
            // tasta1079
            // 
            this.tasta1079.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1079.Location = new System.Drawing.Point(650, 518);
            this.tasta1079.Name = "tasta1079";
            this.tasta1079.Size = new System.Drawing.Size(13, 21);
            this.tasta1079.TabIndex = 1041;
            // 
            // tasta1080
            // 
            this.tasta1080.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1080.Location = new System.Drawing.Point(631, 518);
            this.tasta1080.Name = "tasta1080";
            this.tasta1080.Size = new System.Drawing.Size(13, 21);
            this.tasta1080.TabIndex = 1040;
            // 
            // tasta1081
            // 
            this.tasta1081.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1081.Location = new System.Drawing.Point(612, 518);
            this.tasta1081.Name = "tasta1081";
            this.tasta1081.Size = new System.Drawing.Size(13, 21);
            this.tasta1081.TabIndex = 1039;
            // 
            // tasta1082
            // 
            this.tasta1082.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1082.Location = new System.Drawing.Point(593, 518);
            this.tasta1082.Name = "tasta1082";
            this.tasta1082.Size = new System.Drawing.Size(13, 21);
            this.tasta1082.TabIndex = 1038;
            // 
            // tasta1083
            // 
            this.tasta1083.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1083.Location = new System.Drawing.Point(574, 518);
            this.tasta1083.Name = "tasta1083";
            this.tasta1083.Size = new System.Drawing.Size(13, 21);
            this.tasta1083.TabIndex = 1037;
            // 
            // tasta1084
            // 
            this.tasta1084.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1084.Location = new System.Drawing.Point(555, 518);
            this.tasta1084.Name = "tasta1084";
            this.tasta1084.Size = new System.Drawing.Size(13, 21);
            this.tasta1084.TabIndex = 1036;
            // 
            // tasta1085
            // 
            this.tasta1085.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1085.Location = new System.Drawing.Point(536, 518);
            this.tasta1085.Name = "tasta1085";
            this.tasta1085.Size = new System.Drawing.Size(13, 21);
            this.tasta1085.TabIndex = 1035;
            // 
            // tasta1086
            // 
            this.tasta1086.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1086.Location = new System.Drawing.Point(517, 518);
            this.tasta1086.Name = "tasta1086";
            this.tasta1086.Size = new System.Drawing.Size(13, 21);
            this.tasta1086.TabIndex = 1034;
            // 
            // tasta1087
            // 
            this.tasta1087.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1087.Location = new System.Drawing.Point(498, 518);
            this.tasta1087.Name = "tasta1087";
            this.tasta1087.Size = new System.Drawing.Size(13, 21);
            this.tasta1087.TabIndex = 1033;
            // 
            // tasta1088
            // 
            this.tasta1088.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1088.Location = new System.Drawing.Point(479, 518);
            this.tasta1088.Name = "tasta1088";
            this.tasta1088.Size = new System.Drawing.Size(13, 21);
            this.tasta1088.TabIndex = 1032;
            // 
            // tasta1089
            // 
            this.tasta1089.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1089.Location = new System.Drawing.Point(460, 518);
            this.tasta1089.Name = "tasta1089";
            this.tasta1089.Size = new System.Drawing.Size(13, 21);
            this.tasta1089.TabIndex = 1031;
            // 
            // tasta1090
            // 
            this.tasta1090.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1090.Location = new System.Drawing.Point(441, 518);
            this.tasta1090.Name = "tasta1090";
            this.tasta1090.Size = new System.Drawing.Size(13, 21);
            this.tasta1090.TabIndex = 1030;
            // 
            // tasta1091
            // 
            this.tasta1091.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1091.Location = new System.Drawing.Point(422, 518);
            this.tasta1091.Name = "tasta1091";
            this.tasta1091.Size = new System.Drawing.Size(13, 21);
            this.tasta1091.TabIndex = 1029;
            // 
            // tasta1092
            // 
            this.tasta1092.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1092.Location = new System.Drawing.Point(403, 518);
            this.tasta1092.Name = "tasta1092";
            this.tasta1092.Size = new System.Drawing.Size(13, 21);
            this.tasta1092.TabIndex = 1028;
            // 
            // tasta1093
            // 
            this.tasta1093.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1093.Location = new System.Drawing.Point(384, 518);
            this.tasta1093.Name = "tasta1093";
            this.tasta1093.Size = new System.Drawing.Size(13, 21);
            this.tasta1093.TabIndex = 1027;
            // 
            // tasta1094
            // 
            this.tasta1094.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1094.Location = new System.Drawing.Point(365, 518);
            this.tasta1094.Name = "tasta1094";
            this.tasta1094.Size = new System.Drawing.Size(13, 21);
            this.tasta1094.TabIndex = 1026;
            // 
            // tasta1095
            // 
            this.tasta1095.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1095.Location = new System.Drawing.Point(346, 518);
            this.tasta1095.Name = "tasta1095";
            this.tasta1095.Size = new System.Drawing.Size(13, 21);
            this.tasta1095.TabIndex = 1025;
            // 
            // tasta1096
            // 
            this.tasta1096.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1096.Location = new System.Drawing.Point(327, 518);
            this.tasta1096.Name = "tasta1096";
            this.tasta1096.Size = new System.Drawing.Size(13, 21);
            this.tasta1096.TabIndex = 1024;
            // 
            // tasta1097
            // 
            this.tasta1097.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1097.Location = new System.Drawing.Point(308, 518);
            this.tasta1097.Name = "tasta1097";
            this.tasta1097.Size = new System.Drawing.Size(13, 21);
            this.tasta1097.TabIndex = 1023;
            // 
            // tasta1098
            // 
            this.tasta1098.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1098.Location = new System.Drawing.Point(289, 518);
            this.tasta1098.Name = "tasta1098";
            this.tasta1098.Size = new System.Drawing.Size(13, 21);
            this.tasta1098.TabIndex = 1022;
            // 
            // tasta1099
            // 
            this.tasta1099.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1099.Location = new System.Drawing.Point(270, 518);
            this.tasta1099.Name = "tasta1099";
            this.tasta1099.Size = new System.Drawing.Size(13, 21);
            this.tasta1099.TabIndex = 1021;
            // 
            // tasta1100
            // 
            this.tasta1100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1100.Location = new System.Drawing.Point(251, 518);
            this.tasta1100.Name = "tasta1100";
            this.tasta1100.Size = new System.Drawing.Size(13, 21);
            this.tasta1100.TabIndex = 1020;
            // 
            // tasta1101
            // 
            this.tasta1101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1101.Location = new System.Drawing.Point(232, 518);
            this.tasta1101.Name = "tasta1101";
            this.tasta1101.Size = new System.Drawing.Size(13, 21);
            this.tasta1101.TabIndex = 1019;
            // 
            // tasta1102
            // 
            this.tasta1102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1102.Location = new System.Drawing.Point(213, 518);
            this.tasta1102.Name = "tasta1102";
            this.tasta1102.Size = new System.Drawing.Size(13, 21);
            this.tasta1102.TabIndex = 1018;
            // 
            // tasta1103
            // 
            this.tasta1103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1103.Location = new System.Drawing.Point(194, 518);
            this.tasta1103.Name = "tasta1103";
            this.tasta1103.Size = new System.Drawing.Size(13, 21);
            this.tasta1103.TabIndex = 1017;
            // 
            // tasta1104
            // 
            this.tasta1104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1104.Location = new System.Drawing.Point(175, 518);
            this.tasta1104.Name = "tasta1104";
            this.tasta1104.Size = new System.Drawing.Size(13, 21);
            this.tasta1104.TabIndex = 1016;
            // 
            // tasta1105
            // 
            this.tasta1105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1105.Location = new System.Drawing.Point(156, 518);
            this.tasta1105.Name = "tasta1105";
            this.tasta1105.Size = new System.Drawing.Size(13, 21);
            this.tasta1105.TabIndex = 1015;
            // 
            // tasta1106
            // 
            this.tasta1106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1106.Location = new System.Drawing.Point(137, 518);
            this.tasta1106.Name = "tasta1106";
            this.tasta1106.Size = new System.Drawing.Size(13, 21);
            this.tasta1106.TabIndex = 1014;
            // 
            // tasta1107
            // 
            this.tasta1107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1107.Location = new System.Drawing.Point(118, 518);
            this.tasta1107.Name = "tasta1107";
            this.tasta1107.Size = new System.Drawing.Size(13, 21);
            this.tasta1107.TabIndex = 1013;
            // 
            // tasta1108
            // 
            this.tasta1108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1108.Location = new System.Drawing.Point(99, 518);
            this.tasta1108.Name = "tasta1108";
            this.tasta1108.Size = new System.Drawing.Size(13, 21);
            this.tasta1108.TabIndex = 1012;
            // 
            // tasta1109
            // 
            this.tasta1109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1109.Location = new System.Drawing.Point(80, 518);
            this.tasta1109.Name = "tasta1109";
            this.tasta1109.Size = new System.Drawing.Size(13, 21);
            this.tasta1109.TabIndex = 1011;
            // 
            // tasta1110
            // 
            this.tasta1110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1110.Location = new System.Drawing.Point(61, 518);
            this.tasta1110.Name = "tasta1110";
            this.tasta1110.Size = new System.Drawing.Size(13, 21);
            this.tasta1110.TabIndex = 1010;
            // 
            // tasta1111
            // 
            this.tasta1111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1111.Location = new System.Drawing.Point(42, 518);
            this.tasta1111.Name = "tasta1111";
            this.tasta1111.Size = new System.Drawing.Size(13, 21);
            this.tasta1111.TabIndex = 1009;
            // 
            // tasta1112
            // 
            this.tasta1112.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1112.Location = new System.Drawing.Point(23, 518);
            this.tasta1112.Name = "tasta1112";
            this.tasta1112.Size = new System.Drawing.Size(13, 21);
            this.tasta1112.TabIndex = 1008;
            // 
            // tasta1113
            // 
            this.tasta1113.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1113.Location = new System.Drawing.Point(4, 518);
            this.tasta1113.Name = "tasta1113";
            this.tasta1113.Size = new System.Drawing.Size(13, 21);
            this.tasta1113.TabIndex = 1007;
            // 
            // tasta1114
            // 
            this.tasta1114.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1114.Location = new System.Drawing.Point(993, 491);
            this.tasta1114.Name = "tasta1114";
            this.tasta1114.Size = new System.Drawing.Size(13, 21);
            this.tasta1114.TabIndex = 1006;
            // 
            // tasta1115
            // 
            this.tasta1115.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1115.Location = new System.Drawing.Point(974, 491);
            this.tasta1115.Name = "tasta1115";
            this.tasta1115.Size = new System.Drawing.Size(13, 21);
            this.tasta1115.TabIndex = 1005;
            // 
            // tasta1116
            // 
            this.tasta1116.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1116.Location = new System.Drawing.Point(955, 491);
            this.tasta1116.Name = "tasta1116";
            this.tasta1116.Size = new System.Drawing.Size(13, 21);
            this.tasta1116.TabIndex = 1004;
            // 
            // tasta1117
            // 
            this.tasta1117.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1117.Location = new System.Drawing.Point(936, 491);
            this.tasta1117.Name = "tasta1117";
            this.tasta1117.Size = new System.Drawing.Size(13, 21);
            this.tasta1117.TabIndex = 1003;
            // 
            // tasta1118
            // 
            this.tasta1118.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1118.Location = new System.Drawing.Point(917, 491);
            this.tasta1118.Name = "tasta1118";
            this.tasta1118.Size = new System.Drawing.Size(13, 21);
            this.tasta1118.TabIndex = 1002;
            // 
            // tasta1119
            // 
            this.tasta1119.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1119.Location = new System.Drawing.Point(897, 491);
            this.tasta1119.Name = "tasta1119";
            this.tasta1119.Size = new System.Drawing.Size(13, 21);
            this.tasta1119.TabIndex = 1001;
            // 
            // tasta1120
            // 
            this.tasta1120.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1120.Location = new System.Drawing.Point(878, 491);
            this.tasta1120.Name = "tasta1120";
            this.tasta1120.Size = new System.Drawing.Size(13, 21);
            this.tasta1120.TabIndex = 1000;
            // 
            // tasta1121
            // 
            this.tasta1121.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1121.Location = new System.Drawing.Point(859, 491);
            this.tasta1121.Name = "tasta1121";
            this.tasta1121.Size = new System.Drawing.Size(13, 21);
            this.tasta1121.TabIndex = 999;
            // 
            // tasta1122
            // 
            this.tasta1122.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1122.Location = new System.Drawing.Point(840, 491);
            this.tasta1122.Name = "tasta1122";
            this.tasta1122.Size = new System.Drawing.Size(13, 21);
            this.tasta1122.TabIndex = 998;
            // 
            // tasta1123
            // 
            this.tasta1123.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1123.Location = new System.Drawing.Point(821, 491);
            this.tasta1123.Name = "tasta1123";
            this.tasta1123.Size = new System.Drawing.Size(13, 21);
            this.tasta1123.TabIndex = 997;
            // 
            // tasta1124
            // 
            this.tasta1124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1124.Location = new System.Drawing.Point(802, 491);
            this.tasta1124.Name = "tasta1124";
            this.tasta1124.Size = new System.Drawing.Size(13, 21);
            this.tasta1124.TabIndex = 996;
            // 
            // tasta1125
            // 
            this.tasta1125.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1125.Location = new System.Drawing.Point(783, 491);
            this.tasta1125.Name = "tasta1125";
            this.tasta1125.Size = new System.Drawing.Size(13, 21);
            this.tasta1125.TabIndex = 995;
            // 
            // tasta1126
            // 
            this.tasta1126.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1126.Location = new System.Drawing.Point(764, 491);
            this.tasta1126.Name = "tasta1126";
            this.tasta1126.Size = new System.Drawing.Size(13, 21);
            this.tasta1126.TabIndex = 994;
            // 
            // tasta1127
            // 
            this.tasta1127.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1127.Location = new System.Drawing.Point(745, 491);
            this.tasta1127.Name = "tasta1127";
            this.tasta1127.Size = new System.Drawing.Size(13, 21);
            this.tasta1127.TabIndex = 993;
            // 
            // tasta1128
            // 
            this.tasta1128.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1128.Location = new System.Drawing.Point(726, 491);
            this.tasta1128.Name = "tasta1128";
            this.tasta1128.Size = new System.Drawing.Size(13, 21);
            this.tasta1128.TabIndex = 992;
            // 
            // tasta1129
            // 
            this.tasta1129.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1129.Location = new System.Drawing.Point(707, 491);
            this.tasta1129.Name = "tasta1129";
            this.tasta1129.Size = new System.Drawing.Size(13, 21);
            this.tasta1129.TabIndex = 991;
            // 
            // tasta1130
            // 
            this.tasta1130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1130.Location = new System.Drawing.Point(688, 491);
            this.tasta1130.Name = "tasta1130";
            this.tasta1130.Size = new System.Drawing.Size(13, 21);
            this.tasta1130.TabIndex = 990;
            // 
            // tasta1131
            // 
            this.tasta1131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1131.Location = new System.Drawing.Point(669, 491);
            this.tasta1131.Name = "tasta1131";
            this.tasta1131.Size = new System.Drawing.Size(13, 21);
            this.tasta1131.TabIndex = 989;
            // 
            // tasta1132
            // 
            this.tasta1132.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1132.Location = new System.Drawing.Point(650, 491);
            this.tasta1132.Name = "tasta1132";
            this.tasta1132.Size = new System.Drawing.Size(13, 21);
            this.tasta1132.TabIndex = 988;
            // 
            // tasta1133
            // 
            this.tasta1133.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1133.Location = new System.Drawing.Point(631, 491);
            this.tasta1133.Name = "tasta1133";
            this.tasta1133.Size = new System.Drawing.Size(13, 21);
            this.tasta1133.TabIndex = 987;
            // 
            // tasta1134
            // 
            this.tasta1134.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1134.Location = new System.Drawing.Point(612, 491);
            this.tasta1134.Name = "tasta1134";
            this.tasta1134.Size = new System.Drawing.Size(13, 21);
            this.tasta1134.TabIndex = 986;
            // 
            // tasta1135
            // 
            this.tasta1135.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1135.Location = new System.Drawing.Point(593, 491);
            this.tasta1135.Name = "tasta1135";
            this.tasta1135.Size = new System.Drawing.Size(13, 21);
            this.tasta1135.TabIndex = 985;
            // 
            // tasta1136
            // 
            this.tasta1136.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1136.Location = new System.Drawing.Point(574, 491);
            this.tasta1136.Name = "tasta1136";
            this.tasta1136.Size = new System.Drawing.Size(13, 21);
            this.tasta1136.TabIndex = 984;
            // 
            // tasta1137
            // 
            this.tasta1137.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1137.Location = new System.Drawing.Point(555, 491);
            this.tasta1137.Name = "tasta1137";
            this.tasta1137.Size = new System.Drawing.Size(13, 21);
            this.tasta1137.TabIndex = 983;
            // 
            // tasta1138
            // 
            this.tasta1138.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1138.Location = new System.Drawing.Point(536, 491);
            this.tasta1138.Name = "tasta1138";
            this.tasta1138.Size = new System.Drawing.Size(13, 21);
            this.tasta1138.TabIndex = 982;
            // 
            // tasta1139
            // 
            this.tasta1139.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1139.Location = new System.Drawing.Point(517, 491);
            this.tasta1139.Name = "tasta1139";
            this.tasta1139.Size = new System.Drawing.Size(13, 21);
            this.tasta1139.TabIndex = 981;
            // 
            // tasta1140
            // 
            this.tasta1140.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1140.Location = new System.Drawing.Point(498, 491);
            this.tasta1140.Name = "tasta1140";
            this.tasta1140.Size = new System.Drawing.Size(13, 21);
            this.tasta1140.TabIndex = 980;
            // 
            // tasta1141
            // 
            this.tasta1141.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1141.Location = new System.Drawing.Point(479, 491);
            this.tasta1141.Name = "tasta1141";
            this.tasta1141.Size = new System.Drawing.Size(13, 21);
            this.tasta1141.TabIndex = 979;
            // 
            // tasta1142
            // 
            this.tasta1142.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1142.Location = new System.Drawing.Point(460, 491);
            this.tasta1142.Name = "tasta1142";
            this.tasta1142.Size = new System.Drawing.Size(13, 21);
            this.tasta1142.TabIndex = 978;
            // 
            // tasta1143
            // 
            this.tasta1143.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1143.Location = new System.Drawing.Point(441, 491);
            this.tasta1143.Name = "tasta1143";
            this.tasta1143.Size = new System.Drawing.Size(13, 21);
            this.tasta1143.TabIndex = 977;
            // 
            // tasta1144
            // 
            this.tasta1144.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1144.Location = new System.Drawing.Point(422, 491);
            this.tasta1144.Name = "tasta1144";
            this.tasta1144.Size = new System.Drawing.Size(13, 21);
            this.tasta1144.TabIndex = 976;
            // 
            // tasta1145
            // 
            this.tasta1145.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1145.Location = new System.Drawing.Point(403, 491);
            this.tasta1145.Name = "tasta1145";
            this.tasta1145.Size = new System.Drawing.Size(13, 21);
            this.tasta1145.TabIndex = 975;
            // 
            // tasta1146
            // 
            this.tasta1146.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1146.Location = new System.Drawing.Point(384, 491);
            this.tasta1146.Name = "tasta1146";
            this.tasta1146.Size = new System.Drawing.Size(13, 21);
            this.tasta1146.TabIndex = 974;
            // 
            // tasta1147
            // 
            this.tasta1147.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1147.Location = new System.Drawing.Point(365, 491);
            this.tasta1147.Name = "tasta1147";
            this.tasta1147.Size = new System.Drawing.Size(13, 21);
            this.tasta1147.TabIndex = 973;
            // 
            // tasta1148
            // 
            this.tasta1148.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1148.Location = new System.Drawing.Point(346, 491);
            this.tasta1148.Name = "tasta1148";
            this.tasta1148.Size = new System.Drawing.Size(13, 21);
            this.tasta1148.TabIndex = 972;
            // 
            // tasta1149
            // 
            this.tasta1149.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1149.Location = new System.Drawing.Point(327, 491);
            this.tasta1149.Name = "tasta1149";
            this.tasta1149.Size = new System.Drawing.Size(13, 21);
            this.tasta1149.TabIndex = 971;
            // 
            // tasta1150
            // 
            this.tasta1150.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1150.Location = new System.Drawing.Point(308, 491);
            this.tasta1150.Name = "tasta1150";
            this.tasta1150.Size = new System.Drawing.Size(13, 21);
            this.tasta1150.TabIndex = 970;
            // 
            // tasta1151
            // 
            this.tasta1151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1151.Location = new System.Drawing.Point(289, 491);
            this.tasta1151.Name = "tasta1151";
            this.tasta1151.Size = new System.Drawing.Size(13, 21);
            this.tasta1151.TabIndex = 969;
            // 
            // tasta1152
            // 
            this.tasta1152.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1152.Location = new System.Drawing.Point(270, 491);
            this.tasta1152.Name = "tasta1152";
            this.tasta1152.Size = new System.Drawing.Size(13, 21);
            this.tasta1152.TabIndex = 968;
            // 
            // tasta1153
            // 
            this.tasta1153.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1153.Location = new System.Drawing.Point(251, 491);
            this.tasta1153.Name = "tasta1153";
            this.tasta1153.Size = new System.Drawing.Size(13, 21);
            this.tasta1153.TabIndex = 967;
            // 
            // tasta1154
            // 
            this.tasta1154.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1154.Location = new System.Drawing.Point(232, 491);
            this.tasta1154.Name = "tasta1154";
            this.tasta1154.Size = new System.Drawing.Size(13, 21);
            this.tasta1154.TabIndex = 966;
            // 
            // tasta1155
            // 
            this.tasta1155.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1155.Location = new System.Drawing.Point(213, 491);
            this.tasta1155.Name = "tasta1155";
            this.tasta1155.Size = new System.Drawing.Size(13, 21);
            this.tasta1155.TabIndex = 965;
            // 
            // tasta1156
            // 
            this.tasta1156.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1156.Location = new System.Drawing.Point(194, 491);
            this.tasta1156.Name = "tasta1156";
            this.tasta1156.Size = new System.Drawing.Size(13, 21);
            this.tasta1156.TabIndex = 964;
            // 
            // tasta1157
            // 
            this.tasta1157.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1157.Location = new System.Drawing.Point(175, 491);
            this.tasta1157.Name = "tasta1157";
            this.tasta1157.Size = new System.Drawing.Size(13, 21);
            this.tasta1157.TabIndex = 963;
            // 
            // tasta1158
            // 
            this.tasta1158.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1158.Location = new System.Drawing.Point(156, 491);
            this.tasta1158.Name = "tasta1158";
            this.tasta1158.Size = new System.Drawing.Size(13, 21);
            this.tasta1158.TabIndex = 962;
            // 
            // tasta1159
            // 
            this.tasta1159.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1159.Location = new System.Drawing.Point(137, 491);
            this.tasta1159.Name = "tasta1159";
            this.tasta1159.Size = new System.Drawing.Size(13, 21);
            this.tasta1159.TabIndex = 961;
            // 
            // tasta1160
            // 
            this.tasta1160.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1160.Location = new System.Drawing.Point(118, 491);
            this.tasta1160.Name = "tasta1160";
            this.tasta1160.Size = new System.Drawing.Size(13, 21);
            this.tasta1160.TabIndex = 960;
            // 
            // tasta1161
            // 
            this.tasta1161.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1161.Location = new System.Drawing.Point(99, 491);
            this.tasta1161.Name = "tasta1161";
            this.tasta1161.Size = new System.Drawing.Size(13, 21);
            this.tasta1161.TabIndex = 959;
            // 
            // tasta1162
            // 
            this.tasta1162.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1162.Location = new System.Drawing.Point(80, 491);
            this.tasta1162.Name = "tasta1162";
            this.tasta1162.Size = new System.Drawing.Size(13, 21);
            this.tasta1162.TabIndex = 958;
            // 
            // tasta1163
            // 
            this.tasta1163.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1163.Location = new System.Drawing.Point(61, 491);
            this.tasta1163.Name = "tasta1163";
            this.tasta1163.Size = new System.Drawing.Size(13, 21);
            this.tasta1163.TabIndex = 957;
            // 
            // tasta1164
            // 
            this.tasta1164.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1164.Location = new System.Drawing.Point(42, 491);
            this.tasta1164.Name = "tasta1164";
            this.tasta1164.Size = new System.Drawing.Size(13, 21);
            this.tasta1164.TabIndex = 956;
            // 
            // tasta1165
            // 
            this.tasta1165.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1165.Location = new System.Drawing.Point(23, 491);
            this.tasta1165.Name = "tasta1165";
            this.tasta1165.Size = new System.Drawing.Size(13, 21);
            this.tasta1165.TabIndex = 955;
            // 
            // tasta1166
            // 
            this.tasta1166.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1166.Location = new System.Drawing.Point(4, 491);
            this.tasta1166.Name = "tasta1166";
            this.tasta1166.Size = new System.Drawing.Size(13, 21);
            this.tasta1166.TabIndex = 954;
            // 
            // tasta1167
            // 
            this.tasta1167.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1167.Location = new System.Drawing.Point(993, 464);
            this.tasta1167.Name = "tasta1167";
            this.tasta1167.Size = new System.Drawing.Size(13, 21);
            this.tasta1167.TabIndex = 953;
            // 
            // tasta1168
            // 
            this.tasta1168.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1168.Location = new System.Drawing.Point(974, 464);
            this.tasta1168.Name = "tasta1168";
            this.tasta1168.Size = new System.Drawing.Size(13, 21);
            this.tasta1168.TabIndex = 952;
            // 
            // tasta1169
            // 
            this.tasta1169.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1169.Location = new System.Drawing.Point(955, 464);
            this.tasta1169.Name = "tasta1169";
            this.tasta1169.Size = new System.Drawing.Size(13, 21);
            this.tasta1169.TabIndex = 951;
            // 
            // tasta1170
            // 
            this.tasta1170.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1170.Location = new System.Drawing.Point(936, 464);
            this.tasta1170.Name = "tasta1170";
            this.tasta1170.Size = new System.Drawing.Size(13, 21);
            this.tasta1170.TabIndex = 950;
            // 
            // tasta1171
            // 
            this.tasta1171.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1171.Location = new System.Drawing.Point(917, 464);
            this.tasta1171.Name = "tasta1171";
            this.tasta1171.Size = new System.Drawing.Size(13, 21);
            this.tasta1171.TabIndex = 949;
            // 
            // tasta1172
            // 
            this.tasta1172.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1172.Location = new System.Drawing.Point(897, 464);
            this.tasta1172.Name = "tasta1172";
            this.tasta1172.Size = new System.Drawing.Size(13, 21);
            this.tasta1172.TabIndex = 948;
            // 
            // tasta1173
            // 
            this.tasta1173.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1173.Location = new System.Drawing.Point(878, 464);
            this.tasta1173.Name = "tasta1173";
            this.tasta1173.Size = new System.Drawing.Size(13, 21);
            this.tasta1173.TabIndex = 947;
            // 
            // tasta1174
            // 
            this.tasta1174.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1174.Location = new System.Drawing.Point(859, 464);
            this.tasta1174.Name = "tasta1174";
            this.tasta1174.Size = new System.Drawing.Size(13, 21);
            this.tasta1174.TabIndex = 946;
            // 
            // tasta1175
            // 
            this.tasta1175.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1175.Location = new System.Drawing.Point(840, 464);
            this.tasta1175.Name = "tasta1175";
            this.tasta1175.Size = new System.Drawing.Size(13, 21);
            this.tasta1175.TabIndex = 945;
            // 
            // tasta1176
            // 
            this.tasta1176.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1176.Location = new System.Drawing.Point(821, 464);
            this.tasta1176.Name = "tasta1176";
            this.tasta1176.Size = new System.Drawing.Size(13, 21);
            this.tasta1176.TabIndex = 944;
            // 
            // tasta1177
            // 
            this.tasta1177.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1177.Location = new System.Drawing.Point(802, 464);
            this.tasta1177.Name = "tasta1177";
            this.tasta1177.Size = new System.Drawing.Size(13, 21);
            this.tasta1177.TabIndex = 943;
            // 
            // tasta1178
            // 
            this.tasta1178.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1178.Location = new System.Drawing.Point(783, 464);
            this.tasta1178.Name = "tasta1178";
            this.tasta1178.Size = new System.Drawing.Size(13, 21);
            this.tasta1178.TabIndex = 942;
            // 
            // tasta1179
            // 
            this.tasta1179.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1179.Location = new System.Drawing.Point(764, 464);
            this.tasta1179.Name = "tasta1179";
            this.tasta1179.Size = new System.Drawing.Size(13, 21);
            this.tasta1179.TabIndex = 941;
            // 
            // tasta1180
            // 
            this.tasta1180.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1180.Location = new System.Drawing.Point(745, 464);
            this.tasta1180.Name = "tasta1180";
            this.tasta1180.Size = new System.Drawing.Size(13, 21);
            this.tasta1180.TabIndex = 940;
            // 
            // tasta1181
            // 
            this.tasta1181.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1181.Location = new System.Drawing.Point(726, 464);
            this.tasta1181.Name = "tasta1181";
            this.tasta1181.Size = new System.Drawing.Size(13, 21);
            this.tasta1181.TabIndex = 939;
            // 
            // tasta1182
            // 
            this.tasta1182.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1182.Location = new System.Drawing.Point(707, 464);
            this.tasta1182.Name = "tasta1182";
            this.tasta1182.Size = new System.Drawing.Size(13, 21);
            this.tasta1182.TabIndex = 938;
            // 
            // tasta1183
            // 
            this.tasta1183.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1183.Location = new System.Drawing.Point(688, 464);
            this.tasta1183.Name = "tasta1183";
            this.tasta1183.Size = new System.Drawing.Size(13, 21);
            this.tasta1183.TabIndex = 937;
            // 
            // tasta1184
            // 
            this.tasta1184.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1184.Location = new System.Drawing.Point(669, 464);
            this.tasta1184.Name = "tasta1184";
            this.tasta1184.Size = new System.Drawing.Size(13, 21);
            this.tasta1184.TabIndex = 936;
            // 
            // tasta1185
            // 
            this.tasta1185.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1185.Location = new System.Drawing.Point(650, 464);
            this.tasta1185.Name = "tasta1185";
            this.tasta1185.Size = new System.Drawing.Size(13, 21);
            this.tasta1185.TabIndex = 935;
            // 
            // tasta1186
            // 
            this.tasta1186.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1186.Location = new System.Drawing.Point(631, 464);
            this.tasta1186.Name = "tasta1186";
            this.tasta1186.Size = new System.Drawing.Size(13, 21);
            this.tasta1186.TabIndex = 934;
            // 
            // tasta1187
            // 
            this.tasta1187.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1187.Location = new System.Drawing.Point(612, 464);
            this.tasta1187.Name = "tasta1187";
            this.tasta1187.Size = new System.Drawing.Size(13, 21);
            this.tasta1187.TabIndex = 933;
            // 
            // tasta1188
            // 
            this.tasta1188.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1188.Location = new System.Drawing.Point(593, 464);
            this.tasta1188.Name = "tasta1188";
            this.tasta1188.Size = new System.Drawing.Size(13, 21);
            this.tasta1188.TabIndex = 932;
            // 
            // tasta1189
            // 
            this.tasta1189.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1189.Location = new System.Drawing.Point(574, 464);
            this.tasta1189.Name = "tasta1189";
            this.tasta1189.Size = new System.Drawing.Size(13, 21);
            this.tasta1189.TabIndex = 931;
            // 
            // tasta1190
            // 
            this.tasta1190.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1190.Location = new System.Drawing.Point(555, 464);
            this.tasta1190.Name = "tasta1190";
            this.tasta1190.Size = new System.Drawing.Size(13, 21);
            this.tasta1190.TabIndex = 930;
            // 
            // tasta1191
            // 
            this.tasta1191.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1191.Location = new System.Drawing.Point(536, 464);
            this.tasta1191.Name = "tasta1191";
            this.tasta1191.Size = new System.Drawing.Size(13, 21);
            this.tasta1191.TabIndex = 929;
            // 
            // tasta1192
            // 
            this.tasta1192.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1192.Location = new System.Drawing.Point(517, 464);
            this.tasta1192.Name = "tasta1192";
            this.tasta1192.Size = new System.Drawing.Size(13, 21);
            this.tasta1192.TabIndex = 928;
            // 
            // tasta1193
            // 
            this.tasta1193.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1193.Location = new System.Drawing.Point(498, 464);
            this.tasta1193.Name = "tasta1193";
            this.tasta1193.Size = new System.Drawing.Size(13, 21);
            this.tasta1193.TabIndex = 927;
            // 
            // tasta1194
            // 
            this.tasta1194.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1194.Location = new System.Drawing.Point(479, 464);
            this.tasta1194.Name = "tasta1194";
            this.tasta1194.Size = new System.Drawing.Size(13, 21);
            this.tasta1194.TabIndex = 926;
            // 
            // tasta1195
            // 
            this.tasta1195.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1195.Location = new System.Drawing.Point(460, 464);
            this.tasta1195.Name = "tasta1195";
            this.tasta1195.Size = new System.Drawing.Size(13, 21);
            this.tasta1195.TabIndex = 925;
            // 
            // tasta1196
            // 
            this.tasta1196.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1196.Location = new System.Drawing.Point(441, 464);
            this.tasta1196.Name = "tasta1196";
            this.tasta1196.Size = new System.Drawing.Size(13, 21);
            this.tasta1196.TabIndex = 924;
            // 
            // tasta1197
            // 
            this.tasta1197.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1197.Location = new System.Drawing.Point(422, 464);
            this.tasta1197.Name = "tasta1197";
            this.tasta1197.Size = new System.Drawing.Size(13, 21);
            this.tasta1197.TabIndex = 923;
            // 
            // tasta1198
            // 
            this.tasta1198.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1198.Location = new System.Drawing.Point(403, 464);
            this.tasta1198.Name = "tasta1198";
            this.tasta1198.Size = new System.Drawing.Size(13, 21);
            this.tasta1198.TabIndex = 922;
            // 
            // tasta1199
            // 
            this.tasta1199.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1199.Location = new System.Drawing.Point(384, 464);
            this.tasta1199.Name = "tasta1199";
            this.tasta1199.Size = new System.Drawing.Size(13, 21);
            this.tasta1199.TabIndex = 921;
            // 
            // tasta1200
            // 
            this.tasta1200.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1200.Location = new System.Drawing.Point(365, 464);
            this.tasta1200.Name = "tasta1200";
            this.tasta1200.Size = new System.Drawing.Size(13, 21);
            this.tasta1200.TabIndex = 920;
            // 
            // tasta1201
            // 
            this.tasta1201.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1201.Location = new System.Drawing.Point(346, 464);
            this.tasta1201.Name = "tasta1201";
            this.tasta1201.Size = new System.Drawing.Size(13, 21);
            this.tasta1201.TabIndex = 919;
            // 
            // tasta1202
            // 
            this.tasta1202.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1202.Location = new System.Drawing.Point(327, 464);
            this.tasta1202.Name = "tasta1202";
            this.tasta1202.Size = new System.Drawing.Size(13, 21);
            this.tasta1202.TabIndex = 918;
            // 
            // tasta1203
            // 
            this.tasta1203.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1203.Location = new System.Drawing.Point(308, 464);
            this.tasta1203.Name = "tasta1203";
            this.tasta1203.Size = new System.Drawing.Size(13, 21);
            this.tasta1203.TabIndex = 917;
            // 
            // tasta1204
            // 
            this.tasta1204.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1204.Location = new System.Drawing.Point(289, 464);
            this.tasta1204.Name = "tasta1204";
            this.tasta1204.Size = new System.Drawing.Size(13, 21);
            this.tasta1204.TabIndex = 916;
            // 
            // tasta1205
            // 
            this.tasta1205.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1205.Location = new System.Drawing.Point(270, 464);
            this.tasta1205.Name = "tasta1205";
            this.tasta1205.Size = new System.Drawing.Size(13, 21);
            this.tasta1205.TabIndex = 915;
            // 
            // tasta1206
            // 
            this.tasta1206.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1206.Location = new System.Drawing.Point(251, 464);
            this.tasta1206.Name = "tasta1206";
            this.tasta1206.Size = new System.Drawing.Size(13, 21);
            this.tasta1206.TabIndex = 914;
            // 
            // tasta1207
            // 
            this.tasta1207.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1207.Location = new System.Drawing.Point(232, 464);
            this.tasta1207.Name = "tasta1207";
            this.tasta1207.Size = new System.Drawing.Size(13, 21);
            this.tasta1207.TabIndex = 913;
            // 
            // tasta1208
            // 
            this.tasta1208.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1208.Location = new System.Drawing.Point(213, 464);
            this.tasta1208.Name = "tasta1208";
            this.tasta1208.Size = new System.Drawing.Size(13, 21);
            this.tasta1208.TabIndex = 912;
            // 
            // tasta1209
            // 
            this.tasta1209.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1209.Location = new System.Drawing.Point(194, 464);
            this.tasta1209.Name = "tasta1209";
            this.tasta1209.Size = new System.Drawing.Size(13, 21);
            this.tasta1209.TabIndex = 911;
            // 
            // tasta1210
            // 
            this.tasta1210.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1210.Location = new System.Drawing.Point(175, 464);
            this.tasta1210.Name = "tasta1210";
            this.tasta1210.Size = new System.Drawing.Size(13, 21);
            this.tasta1210.TabIndex = 910;
            // 
            // tasta1211
            // 
            this.tasta1211.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1211.Location = new System.Drawing.Point(156, 464);
            this.tasta1211.Name = "tasta1211";
            this.tasta1211.Size = new System.Drawing.Size(13, 21);
            this.tasta1211.TabIndex = 909;
            // 
            // tasta1212
            // 
            this.tasta1212.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1212.Location = new System.Drawing.Point(137, 464);
            this.tasta1212.Name = "tasta1212";
            this.tasta1212.Size = new System.Drawing.Size(13, 21);
            this.tasta1212.TabIndex = 908;
            // 
            // tasta1213
            // 
            this.tasta1213.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1213.Location = new System.Drawing.Point(118, 464);
            this.tasta1213.Name = "tasta1213";
            this.tasta1213.Size = new System.Drawing.Size(13, 21);
            this.tasta1213.TabIndex = 907;
            // 
            // tasta1214
            // 
            this.tasta1214.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1214.Location = new System.Drawing.Point(99, 464);
            this.tasta1214.Name = "tasta1214";
            this.tasta1214.Size = new System.Drawing.Size(13, 21);
            this.tasta1214.TabIndex = 906;
            // 
            // tasta1215
            // 
            this.tasta1215.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1215.Location = new System.Drawing.Point(80, 464);
            this.tasta1215.Name = "tasta1215";
            this.tasta1215.Size = new System.Drawing.Size(13, 21);
            this.tasta1215.TabIndex = 905;
            // 
            // tasta1216
            // 
            this.tasta1216.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1216.Location = new System.Drawing.Point(61, 464);
            this.tasta1216.Name = "tasta1216";
            this.tasta1216.Size = new System.Drawing.Size(13, 21);
            this.tasta1216.TabIndex = 904;
            // 
            // tasta1217
            // 
            this.tasta1217.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1217.Location = new System.Drawing.Point(42, 464);
            this.tasta1217.Name = "tasta1217";
            this.tasta1217.Size = new System.Drawing.Size(13, 21);
            this.tasta1217.TabIndex = 903;
            // 
            // tasta1218
            // 
            this.tasta1218.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1218.Location = new System.Drawing.Point(23, 464);
            this.tasta1218.Name = "tasta1218";
            this.tasta1218.Size = new System.Drawing.Size(13, 21);
            this.tasta1218.TabIndex = 902;
            // 
            // tasta1219
            // 
            this.tasta1219.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1219.Location = new System.Drawing.Point(4, 464);
            this.tasta1219.Name = "tasta1219";
            this.tasta1219.Size = new System.Drawing.Size(13, 21);
            this.tasta1219.TabIndex = 901;
            // 
            // tasta1220
            // 
            this.tasta1220.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1220.Location = new System.Drawing.Point(993, 437);
            this.tasta1220.Name = "tasta1220";
            this.tasta1220.Size = new System.Drawing.Size(13, 21);
            this.tasta1220.TabIndex = 900;
            // 
            // tasta1221
            // 
            this.tasta1221.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1221.Location = new System.Drawing.Point(974, 437);
            this.tasta1221.Name = "tasta1221";
            this.tasta1221.Size = new System.Drawing.Size(13, 21);
            this.tasta1221.TabIndex = 899;
            // 
            // tasta1222
            // 
            this.tasta1222.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1222.Location = new System.Drawing.Point(955, 437);
            this.tasta1222.Name = "tasta1222";
            this.tasta1222.Size = new System.Drawing.Size(13, 21);
            this.tasta1222.TabIndex = 898;
            // 
            // tasta1223
            // 
            this.tasta1223.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1223.Location = new System.Drawing.Point(936, 437);
            this.tasta1223.Name = "tasta1223";
            this.tasta1223.Size = new System.Drawing.Size(13, 21);
            this.tasta1223.TabIndex = 897;
            // 
            // tasta1224
            // 
            this.tasta1224.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1224.Location = new System.Drawing.Point(917, 437);
            this.tasta1224.Name = "tasta1224";
            this.tasta1224.Size = new System.Drawing.Size(13, 21);
            this.tasta1224.TabIndex = 896;
            // 
            // tasta1225
            // 
            this.tasta1225.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1225.Location = new System.Drawing.Point(897, 437);
            this.tasta1225.Name = "tasta1225";
            this.tasta1225.Size = new System.Drawing.Size(13, 21);
            this.tasta1225.TabIndex = 895;
            // 
            // tasta1226
            // 
            this.tasta1226.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1226.Location = new System.Drawing.Point(878, 437);
            this.tasta1226.Name = "tasta1226";
            this.tasta1226.Size = new System.Drawing.Size(13, 21);
            this.tasta1226.TabIndex = 894;
            // 
            // tasta1227
            // 
            this.tasta1227.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1227.Location = new System.Drawing.Point(859, 437);
            this.tasta1227.Name = "tasta1227";
            this.tasta1227.Size = new System.Drawing.Size(13, 21);
            this.tasta1227.TabIndex = 893;
            // 
            // tasta1228
            // 
            this.tasta1228.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1228.Location = new System.Drawing.Point(840, 437);
            this.tasta1228.Name = "tasta1228";
            this.tasta1228.Size = new System.Drawing.Size(13, 21);
            this.tasta1228.TabIndex = 892;
            // 
            // tasta1229
            // 
            this.tasta1229.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1229.Location = new System.Drawing.Point(821, 437);
            this.tasta1229.Name = "tasta1229";
            this.tasta1229.Size = new System.Drawing.Size(13, 21);
            this.tasta1229.TabIndex = 891;
            // 
            // tasta1230
            // 
            this.tasta1230.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1230.Location = new System.Drawing.Point(802, 437);
            this.tasta1230.Name = "tasta1230";
            this.tasta1230.Size = new System.Drawing.Size(13, 21);
            this.tasta1230.TabIndex = 890;
            // 
            // tasta1231
            // 
            this.tasta1231.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1231.Location = new System.Drawing.Point(783, 437);
            this.tasta1231.Name = "tasta1231";
            this.tasta1231.Size = new System.Drawing.Size(13, 21);
            this.tasta1231.TabIndex = 889;
            // 
            // tasta1232
            // 
            this.tasta1232.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1232.Location = new System.Drawing.Point(764, 437);
            this.tasta1232.Name = "tasta1232";
            this.tasta1232.Size = new System.Drawing.Size(13, 21);
            this.tasta1232.TabIndex = 888;
            // 
            // tasta1233
            // 
            this.tasta1233.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1233.Location = new System.Drawing.Point(745, 437);
            this.tasta1233.Name = "tasta1233";
            this.tasta1233.Size = new System.Drawing.Size(13, 21);
            this.tasta1233.TabIndex = 887;
            // 
            // tasta1234
            // 
            this.tasta1234.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1234.Location = new System.Drawing.Point(726, 437);
            this.tasta1234.Name = "tasta1234";
            this.tasta1234.Size = new System.Drawing.Size(13, 21);
            this.tasta1234.TabIndex = 886;
            // 
            // tasta1235
            // 
            this.tasta1235.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1235.Location = new System.Drawing.Point(707, 437);
            this.tasta1235.Name = "tasta1235";
            this.tasta1235.Size = new System.Drawing.Size(13, 21);
            this.tasta1235.TabIndex = 885;
            // 
            // tasta1236
            // 
            this.tasta1236.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1236.Location = new System.Drawing.Point(688, 437);
            this.tasta1236.Name = "tasta1236";
            this.tasta1236.Size = new System.Drawing.Size(13, 21);
            this.tasta1236.TabIndex = 884;
            // 
            // tasta1237
            // 
            this.tasta1237.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1237.Location = new System.Drawing.Point(669, 437);
            this.tasta1237.Name = "tasta1237";
            this.tasta1237.Size = new System.Drawing.Size(13, 21);
            this.tasta1237.TabIndex = 883;
            // 
            // tasta1238
            // 
            this.tasta1238.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1238.Location = new System.Drawing.Point(650, 437);
            this.tasta1238.Name = "tasta1238";
            this.tasta1238.Size = new System.Drawing.Size(13, 21);
            this.tasta1238.TabIndex = 882;
            // 
            // tasta1239
            // 
            this.tasta1239.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1239.Location = new System.Drawing.Point(631, 437);
            this.tasta1239.Name = "tasta1239";
            this.tasta1239.Size = new System.Drawing.Size(13, 21);
            this.tasta1239.TabIndex = 881;
            // 
            // tasta1240
            // 
            this.tasta1240.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1240.Location = new System.Drawing.Point(612, 437);
            this.tasta1240.Name = "tasta1240";
            this.tasta1240.Size = new System.Drawing.Size(13, 21);
            this.tasta1240.TabIndex = 880;
            // 
            // tasta1241
            // 
            this.tasta1241.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1241.Location = new System.Drawing.Point(593, 437);
            this.tasta1241.Name = "tasta1241";
            this.tasta1241.Size = new System.Drawing.Size(13, 21);
            this.tasta1241.TabIndex = 879;
            // 
            // tasta1242
            // 
            this.tasta1242.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1242.Location = new System.Drawing.Point(574, 437);
            this.tasta1242.Name = "tasta1242";
            this.tasta1242.Size = new System.Drawing.Size(13, 21);
            this.tasta1242.TabIndex = 878;
            // 
            // tasta1243
            // 
            this.tasta1243.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1243.Location = new System.Drawing.Point(555, 437);
            this.tasta1243.Name = "tasta1243";
            this.tasta1243.Size = new System.Drawing.Size(13, 21);
            this.tasta1243.TabIndex = 877;
            // 
            // tasta1244
            // 
            this.tasta1244.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1244.Location = new System.Drawing.Point(536, 437);
            this.tasta1244.Name = "tasta1244";
            this.tasta1244.Size = new System.Drawing.Size(13, 21);
            this.tasta1244.TabIndex = 876;
            // 
            // tasta1245
            // 
            this.tasta1245.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1245.Location = new System.Drawing.Point(517, 437);
            this.tasta1245.Name = "tasta1245";
            this.tasta1245.Size = new System.Drawing.Size(13, 21);
            this.tasta1245.TabIndex = 875;
            // 
            // tasta1246
            // 
            this.tasta1246.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1246.Location = new System.Drawing.Point(498, 437);
            this.tasta1246.Name = "tasta1246";
            this.tasta1246.Size = new System.Drawing.Size(13, 21);
            this.tasta1246.TabIndex = 874;
            // 
            // tasta1247
            // 
            this.tasta1247.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1247.Location = new System.Drawing.Point(479, 437);
            this.tasta1247.Name = "tasta1247";
            this.tasta1247.Size = new System.Drawing.Size(13, 21);
            this.tasta1247.TabIndex = 873;
            // 
            // tasta1248
            // 
            this.tasta1248.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1248.Location = new System.Drawing.Point(460, 437);
            this.tasta1248.Name = "tasta1248";
            this.tasta1248.Size = new System.Drawing.Size(13, 21);
            this.tasta1248.TabIndex = 872;
            // 
            // tasta1249
            // 
            this.tasta1249.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1249.Location = new System.Drawing.Point(441, 437);
            this.tasta1249.Name = "tasta1249";
            this.tasta1249.Size = new System.Drawing.Size(13, 21);
            this.tasta1249.TabIndex = 871;
            // 
            // tasta1250
            // 
            this.tasta1250.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1250.Location = new System.Drawing.Point(422, 437);
            this.tasta1250.Name = "tasta1250";
            this.tasta1250.Size = new System.Drawing.Size(13, 21);
            this.tasta1250.TabIndex = 870;
            // 
            // tasta1251
            // 
            this.tasta1251.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1251.Location = new System.Drawing.Point(403, 437);
            this.tasta1251.Name = "tasta1251";
            this.tasta1251.Size = new System.Drawing.Size(13, 21);
            this.tasta1251.TabIndex = 869;
            // 
            // tasta1252
            // 
            this.tasta1252.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1252.Location = new System.Drawing.Point(384, 437);
            this.tasta1252.Name = "tasta1252";
            this.tasta1252.Size = new System.Drawing.Size(13, 21);
            this.tasta1252.TabIndex = 868;
            // 
            // tasta1253
            // 
            this.tasta1253.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1253.Location = new System.Drawing.Point(365, 437);
            this.tasta1253.Name = "tasta1253";
            this.tasta1253.Size = new System.Drawing.Size(13, 21);
            this.tasta1253.TabIndex = 867;
            // 
            // tasta1254
            // 
            this.tasta1254.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1254.Location = new System.Drawing.Point(346, 437);
            this.tasta1254.Name = "tasta1254";
            this.tasta1254.Size = new System.Drawing.Size(13, 21);
            this.tasta1254.TabIndex = 866;
            // 
            // tasta1255
            // 
            this.tasta1255.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1255.Location = new System.Drawing.Point(327, 437);
            this.tasta1255.Name = "tasta1255";
            this.tasta1255.Size = new System.Drawing.Size(13, 21);
            this.tasta1255.TabIndex = 865;
            // 
            // tasta1256
            // 
            this.tasta1256.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1256.Location = new System.Drawing.Point(308, 437);
            this.tasta1256.Name = "tasta1256";
            this.tasta1256.Size = new System.Drawing.Size(13, 21);
            this.tasta1256.TabIndex = 864;
            // 
            // tasta1257
            // 
            this.tasta1257.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1257.Location = new System.Drawing.Point(289, 437);
            this.tasta1257.Name = "tasta1257";
            this.tasta1257.Size = new System.Drawing.Size(13, 21);
            this.tasta1257.TabIndex = 863;
            // 
            // tasta1258
            // 
            this.tasta1258.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1258.Location = new System.Drawing.Point(270, 437);
            this.tasta1258.Name = "tasta1258";
            this.tasta1258.Size = new System.Drawing.Size(13, 21);
            this.tasta1258.TabIndex = 862;
            // 
            // tasta1259
            // 
            this.tasta1259.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1259.Location = new System.Drawing.Point(251, 437);
            this.tasta1259.Name = "tasta1259";
            this.tasta1259.Size = new System.Drawing.Size(13, 21);
            this.tasta1259.TabIndex = 861;
            // 
            // tasta1260
            // 
            this.tasta1260.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1260.Location = new System.Drawing.Point(232, 437);
            this.tasta1260.Name = "tasta1260";
            this.tasta1260.Size = new System.Drawing.Size(13, 21);
            this.tasta1260.TabIndex = 860;
            // 
            // tasta1261
            // 
            this.tasta1261.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1261.Location = new System.Drawing.Point(213, 437);
            this.tasta1261.Name = "tasta1261";
            this.tasta1261.Size = new System.Drawing.Size(13, 21);
            this.tasta1261.TabIndex = 859;
            // 
            // tasta1262
            // 
            this.tasta1262.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1262.Location = new System.Drawing.Point(194, 437);
            this.tasta1262.Name = "tasta1262";
            this.tasta1262.Size = new System.Drawing.Size(13, 21);
            this.tasta1262.TabIndex = 858;
            // 
            // tasta1263
            // 
            this.tasta1263.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1263.Location = new System.Drawing.Point(175, 437);
            this.tasta1263.Name = "tasta1263";
            this.tasta1263.Size = new System.Drawing.Size(13, 21);
            this.tasta1263.TabIndex = 857;
            // 
            // tasta1264
            // 
            this.tasta1264.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1264.Location = new System.Drawing.Point(156, 437);
            this.tasta1264.Name = "tasta1264";
            this.tasta1264.Size = new System.Drawing.Size(13, 21);
            this.tasta1264.TabIndex = 856;
            // 
            // tasta1265
            // 
            this.tasta1265.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1265.Location = new System.Drawing.Point(137, 437);
            this.tasta1265.Name = "tasta1265";
            this.tasta1265.Size = new System.Drawing.Size(13, 21);
            this.tasta1265.TabIndex = 855;
            // 
            // tasta1266
            // 
            this.tasta1266.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1266.Location = new System.Drawing.Point(118, 437);
            this.tasta1266.Name = "tasta1266";
            this.tasta1266.Size = new System.Drawing.Size(13, 21);
            this.tasta1266.TabIndex = 854;
            // 
            // tasta1267
            // 
            this.tasta1267.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1267.Location = new System.Drawing.Point(99, 437);
            this.tasta1267.Name = "tasta1267";
            this.tasta1267.Size = new System.Drawing.Size(13, 21);
            this.tasta1267.TabIndex = 853;
            // 
            // tasta1268
            // 
            this.tasta1268.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1268.Location = new System.Drawing.Point(80, 437);
            this.tasta1268.Name = "tasta1268";
            this.tasta1268.Size = new System.Drawing.Size(13, 21);
            this.tasta1268.TabIndex = 852;
            // 
            // tasta1269
            // 
            this.tasta1269.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1269.Location = new System.Drawing.Point(61, 437);
            this.tasta1269.Name = "tasta1269";
            this.tasta1269.Size = new System.Drawing.Size(13, 21);
            this.tasta1269.TabIndex = 851;
            // 
            // tasta1270
            // 
            this.tasta1270.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1270.Location = new System.Drawing.Point(42, 437);
            this.tasta1270.Name = "tasta1270";
            this.tasta1270.Size = new System.Drawing.Size(13, 21);
            this.tasta1270.TabIndex = 850;
            // 
            // tasta1271
            // 
            this.tasta1271.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1271.Location = new System.Drawing.Point(23, 437);
            this.tasta1271.Name = "tasta1271";
            this.tasta1271.Size = new System.Drawing.Size(13, 21);
            this.tasta1271.TabIndex = 849;
            // 
            // tasta1272
            // 
            this.tasta1272.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.tasta1272.Location = new System.Drawing.Point(4, 437);
            this.tasta1272.Name = "tasta1272";
            this.tasta1272.Size = new System.Drawing.Size(13, 21);
            this.tasta1272.TabIndex = 848;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 741);
            this.Controls.Add(this.tasta849);
            this.Controls.Add(this.tasta850);
            this.Controls.Add(this.tasta851);
            this.Controls.Add(this.tasta852);
            this.Controls.Add(this.tasta853);
            this.Controls.Add(this.tasta854);
            this.Controls.Add(this.tasta855);
            this.Controls.Add(this.tasta856);
            this.Controls.Add(this.tasta857);
            this.Controls.Add(this.tasta858);
            this.Controls.Add(this.tasta859);
            this.Controls.Add(this.tasta860);
            this.Controls.Add(this.tasta861);
            this.Controls.Add(this.tasta862);
            this.Controls.Add(this.tasta863);
            this.Controls.Add(this.tasta864);
            this.Controls.Add(this.tasta865);
            this.Controls.Add(this.tasta866);
            this.Controls.Add(this.tasta867);
            this.Controls.Add(this.tasta868);
            this.Controls.Add(this.tasta869);
            this.Controls.Add(this.tasta870);
            this.Controls.Add(this.tasta871);
            this.Controls.Add(this.tasta872);
            this.Controls.Add(this.tasta873);
            this.Controls.Add(this.tasta874);
            this.Controls.Add(this.tasta875);
            this.Controls.Add(this.tasta876);
            this.Controls.Add(this.tasta877);
            this.Controls.Add(this.tasta878);
            this.Controls.Add(this.tasta879);
            this.Controls.Add(this.tasta880);
            this.Controls.Add(this.tasta881);
            this.Controls.Add(this.tasta882);
            this.Controls.Add(this.tasta883);
            this.Controls.Add(this.tasta884);
            this.Controls.Add(this.tasta885);
            this.Controls.Add(this.tasta886);
            this.Controls.Add(this.tasta887);
            this.Controls.Add(this.tasta888);
            this.Controls.Add(this.tasta889);
            this.Controls.Add(this.tasta890);
            this.Controls.Add(this.tasta891);
            this.Controls.Add(this.tasta892);
            this.Controls.Add(this.tasta893);
            this.Controls.Add(this.tasta894);
            this.Controls.Add(this.tasta895);
            this.Controls.Add(this.tasta896);
            this.Controls.Add(this.tasta897);
            this.Controls.Add(this.tasta898);
            this.Controls.Add(this.tasta899);
            this.Controls.Add(this.tasta900);
            this.Controls.Add(this.tasta901);
            this.Controls.Add(this.tasta902);
            this.Controls.Add(this.tasta903);
            this.Controls.Add(this.tasta904);
            this.Controls.Add(this.tasta905);
            this.Controls.Add(this.tasta906);
            this.Controls.Add(this.tasta907);
            this.Controls.Add(this.tasta908);
            this.Controls.Add(this.tasta909);
            this.Controls.Add(this.tasta910);
            this.Controls.Add(this.tasta911);
            this.Controls.Add(this.tasta912);
            this.Controls.Add(this.tasta913);
            this.Controls.Add(this.tasta914);
            this.Controls.Add(this.tasta915);
            this.Controls.Add(this.tasta916);
            this.Controls.Add(this.tasta917);
            this.Controls.Add(this.tasta918);
            this.Controls.Add(this.tasta919);
            this.Controls.Add(this.tasta920);
            this.Controls.Add(this.tasta921);
            this.Controls.Add(this.tasta922);
            this.Controls.Add(this.tasta923);
            this.Controls.Add(this.tasta924);
            this.Controls.Add(this.tasta925);
            this.Controls.Add(this.tasta926);
            this.Controls.Add(this.tasta927);
            this.Controls.Add(this.tasta928);
            this.Controls.Add(this.tasta929);
            this.Controls.Add(this.tasta930);
            this.Controls.Add(this.tasta931);
            this.Controls.Add(this.tasta932);
            this.Controls.Add(this.tasta933);
            this.Controls.Add(this.tasta934);
            this.Controls.Add(this.tasta935);
            this.Controls.Add(this.tasta936);
            this.Controls.Add(this.tasta937);
            this.Controls.Add(this.tasta938);
            this.Controls.Add(this.tasta939);
            this.Controls.Add(this.tasta940);
            this.Controls.Add(this.tasta941);
            this.Controls.Add(this.tasta942);
            this.Controls.Add(this.tasta943);
            this.Controls.Add(this.tasta944);
            this.Controls.Add(this.tasta945);
            this.Controls.Add(this.tasta946);
            this.Controls.Add(this.tasta947);
            this.Controls.Add(this.tasta948);
            this.Controls.Add(this.tasta949);
            this.Controls.Add(this.tasta950);
            this.Controls.Add(this.tasta951);
            this.Controls.Add(this.tasta952);
            this.Controls.Add(this.tasta953);
            this.Controls.Add(this.tasta954);
            this.Controls.Add(this.tasta955);
            this.Controls.Add(this.tasta956);
            this.Controls.Add(this.tasta957);
            this.Controls.Add(this.tasta958);
            this.Controls.Add(this.tasta959);
            this.Controls.Add(this.tasta960);
            this.Controls.Add(this.tasta961);
            this.Controls.Add(this.tasta962);
            this.Controls.Add(this.tasta963);
            this.Controls.Add(this.tasta964);
            this.Controls.Add(this.tasta965);
            this.Controls.Add(this.tasta966);
            this.Controls.Add(this.tasta967);
            this.Controls.Add(this.tasta968);
            this.Controls.Add(this.tasta969);
            this.Controls.Add(this.tasta970);
            this.Controls.Add(this.tasta971);
            this.Controls.Add(this.tasta972);
            this.Controls.Add(this.tasta973);
            this.Controls.Add(this.tasta974);
            this.Controls.Add(this.tasta975);
            this.Controls.Add(this.tasta976);
            this.Controls.Add(this.tasta977);
            this.Controls.Add(this.tasta978);
            this.Controls.Add(this.tasta979);
            this.Controls.Add(this.tasta980);
            this.Controls.Add(this.tasta981);
            this.Controls.Add(this.tasta982);
            this.Controls.Add(this.tasta983);
            this.Controls.Add(this.tasta984);
            this.Controls.Add(this.tasta985);
            this.Controls.Add(this.tasta986);
            this.Controls.Add(this.tasta987);
            this.Controls.Add(this.tasta988);
            this.Controls.Add(this.tasta989);
            this.Controls.Add(this.tasta990);
            this.Controls.Add(this.tasta991);
            this.Controls.Add(this.tasta992);
            this.Controls.Add(this.tasta993);
            this.Controls.Add(this.tasta994);
            this.Controls.Add(this.tasta995);
            this.Controls.Add(this.tasta996);
            this.Controls.Add(this.tasta997);
            this.Controls.Add(this.tasta998);
            this.Controls.Add(this.tasta999);
            this.Controls.Add(this.tasta1000);
            this.Controls.Add(this.tasta1001);
            this.Controls.Add(this.tasta1002);
            this.Controls.Add(this.tasta1003);
            this.Controls.Add(this.tasta1004);
            this.Controls.Add(this.tasta1005);
            this.Controls.Add(this.tasta1006);
            this.Controls.Add(this.tasta1007);
            this.Controls.Add(this.tasta1008);
            this.Controls.Add(this.tasta1009);
            this.Controls.Add(this.tasta1010);
            this.Controls.Add(this.tasta1011);
            this.Controls.Add(this.tasta1012);
            this.Controls.Add(this.tasta1013);
            this.Controls.Add(this.tasta1014);
            this.Controls.Add(this.tasta1015);
            this.Controls.Add(this.tasta1016);
            this.Controls.Add(this.tasta1017);
            this.Controls.Add(this.tasta1018);
            this.Controls.Add(this.tasta1019);
            this.Controls.Add(this.tasta1020);
            this.Controls.Add(this.tasta1021);
            this.Controls.Add(this.tasta1022);
            this.Controls.Add(this.tasta1023);
            this.Controls.Add(this.tasta1024);
            this.Controls.Add(this.tasta1025);
            this.Controls.Add(this.tasta1026);
            this.Controls.Add(this.tasta1027);
            this.Controls.Add(this.tasta1028);
            this.Controls.Add(this.tasta1029);
            this.Controls.Add(this.tasta1030);
            this.Controls.Add(this.tasta1031);
            this.Controls.Add(this.tasta1032);
            this.Controls.Add(this.tasta1033);
            this.Controls.Add(this.tasta1034);
            this.Controls.Add(this.tasta1035);
            this.Controls.Add(this.tasta1036);
            this.Controls.Add(this.tasta1037);
            this.Controls.Add(this.tasta1038);
            this.Controls.Add(this.tasta1039);
            this.Controls.Add(this.tasta1040);
            this.Controls.Add(this.tasta1041);
            this.Controls.Add(this.tasta1042);
            this.Controls.Add(this.tasta1043);
            this.Controls.Add(this.tasta1044);
            this.Controls.Add(this.tasta1045);
            this.Controls.Add(this.tasta1046);
            this.Controls.Add(this.tasta1047);
            this.Controls.Add(this.tasta1048);
            this.Controls.Add(this.tasta1049);
            this.Controls.Add(this.tasta1050);
            this.Controls.Add(this.tasta1051);
            this.Controls.Add(this.tasta1052);
            this.Controls.Add(this.tasta1053);
            this.Controls.Add(this.tasta1054);
            this.Controls.Add(this.tasta1055);
            this.Controls.Add(this.tasta1056);
            this.Controls.Add(this.tasta1057);
            this.Controls.Add(this.tasta1058);
            this.Controls.Add(this.tasta1059);
            this.Controls.Add(this.tasta1060);
            this.Controls.Add(this.tasta1061);
            this.Controls.Add(this.tasta1062);
            this.Controls.Add(this.tasta1063);
            this.Controls.Add(this.tasta1064);
            this.Controls.Add(this.tasta1065);
            this.Controls.Add(this.tasta1066);
            this.Controls.Add(this.tasta1067);
            this.Controls.Add(this.tasta1068);
            this.Controls.Add(this.tasta1069);
            this.Controls.Add(this.tasta1070);
            this.Controls.Add(this.tasta1071);
            this.Controls.Add(this.tasta1072);
            this.Controls.Add(this.tasta1073);
            this.Controls.Add(this.tasta1074);
            this.Controls.Add(this.tasta1075);
            this.Controls.Add(this.tasta1076);
            this.Controls.Add(this.tasta1077);
            this.Controls.Add(this.tasta1078);
            this.Controls.Add(this.tasta1079);
            this.Controls.Add(this.tasta1080);
            this.Controls.Add(this.tasta1081);
            this.Controls.Add(this.tasta1082);
            this.Controls.Add(this.tasta1083);
            this.Controls.Add(this.tasta1084);
            this.Controls.Add(this.tasta1085);
            this.Controls.Add(this.tasta1086);
            this.Controls.Add(this.tasta1087);
            this.Controls.Add(this.tasta1088);
            this.Controls.Add(this.tasta1089);
            this.Controls.Add(this.tasta1090);
            this.Controls.Add(this.tasta1091);
            this.Controls.Add(this.tasta1092);
            this.Controls.Add(this.tasta1093);
            this.Controls.Add(this.tasta1094);
            this.Controls.Add(this.tasta1095);
            this.Controls.Add(this.tasta1096);
            this.Controls.Add(this.tasta1097);
            this.Controls.Add(this.tasta1098);
            this.Controls.Add(this.tasta1099);
            this.Controls.Add(this.tasta1100);
            this.Controls.Add(this.tasta1101);
            this.Controls.Add(this.tasta1102);
            this.Controls.Add(this.tasta1103);
            this.Controls.Add(this.tasta1104);
            this.Controls.Add(this.tasta1105);
            this.Controls.Add(this.tasta1106);
            this.Controls.Add(this.tasta1107);
            this.Controls.Add(this.tasta1108);
            this.Controls.Add(this.tasta1109);
            this.Controls.Add(this.tasta1110);
            this.Controls.Add(this.tasta1111);
            this.Controls.Add(this.tasta1112);
            this.Controls.Add(this.tasta1113);
            this.Controls.Add(this.tasta1114);
            this.Controls.Add(this.tasta1115);
            this.Controls.Add(this.tasta1116);
            this.Controls.Add(this.tasta1117);
            this.Controls.Add(this.tasta1118);
            this.Controls.Add(this.tasta1119);
            this.Controls.Add(this.tasta1120);
            this.Controls.Add(this.tasta1121);
            this.Controls.Add(this.tasta1122);
            this.Controls.Add(this.tasta1123);
            this.Controls.Add(this.tasta1124);
            this.Controls.Add(this.tasta1125);
            this.Controls.Add(this.tasta1126);
            this.Controls.Add(this.tasta1127);
            this.Controls.Add(this.tasta1128);
            this.Controls.Add(this.tasta1129);
            this.Controls.Add(this.tasta1130);
            this.Controls.Add(this.tasta1131);
            this.Controls.Add(this.tasta1132);
            this.Controls.Add(this.tasta1133);
            this.Controls.Add(this.tasta1134);
            this.Controls.Add(this.tasta1135);
            this.Controls.Add(this.tasta1136);
            this.Controls.Add(this.tasta1137);
            this.Controls.Add(this.tasta1138);
            this.Controls.Add(this.tasta1139);
            this.Controls.Add(this.tasta1140);
            this.Controls.Add(this.tasta1141);
            this.Controls.Add(this.tasta1142);
            this.Controls.Add(this.tasta1143);
            this.Controls.Add(this.tasta1144);
            this.Controls.Add(this.tasta1145);
            this.Controls.Add(this.tasta1146);
            this.Controls.Add(this.tasta1147);
            this.Controls.Add(this.tasta1148);
            this.Controls.Add(this.tasta1149);
            this.Controls.Add(this.tasta1150);
            this.Controls.Add(this.tasta1151);
            this.Controls.Add(this.tasta1152);
            this.Controls.Add(this.tasta1153);
            this.Controls.Add(this.tasta1154);
            this.Controls.Add(this.tasta1155);
            this.Controls.Add(this.tasta1156);
            this.Controls.Add(this.tasta1157);
            this.Controls.Add(this.tasta1158);
            this.Controls.Add(this.tasta1159);
            this.Controls.Add(this.tasta1160);
            this.Controls.Add(this.tasta1161);
            this.Controls.Add(this.tasta1162);
            this.Controls.Add(this.tasta1163);
            this.Controls.Add(this.tasta1164);
            this.Controls.Add(this.tasta1165);
            this.Controls.Add(this.tasta1166);
            this.Controls.Add(this.tasta1167);
            this.Controls.Add(this.tasta1168);
            this.Controls.Add(this.tasta1169);
            this.Controls.Add(this.tasta1170);
            this.Controls.Add(this.tasta1171);
            this.Controls.Add(this.tasta1172);
            this.Controls.Add(this.tasta1173);
            this.Controls.Add(this.tasta1174);
            this.Controls.Add(this.tasta1175);
            this.Controls.Add(this.tasta1176);
            this.Controls.Add(this.tasta1177);
            this.Controls.Add(this.tasta1178);
            this.Controls.Add(this.tasta1179);
            this.Controls.Add(this.tasta1180);
            this.Controls.Add(this.tasta1181);
            this.Controls.Add(this.tasta1182);
            this.Controls.Add(this.tasta1183);
            this.Controls.Add(this.tasta1184);
            this.Controls.Add(this.tasta1185);
            this.Controls.Add(this.tasta1186);
            this.Controls.Add(this.tasta1187);
            this.Controls.Add(this.tasta1188);
            this.Controls.Add(this.tasta1189);
            this.Controls.Add(this.tasta1190);
            this.Controls.Add(this.tasta1191);
            this.Controls.Add(this.tasta1192);
            this.Controls.Add(this.tasta1193);
            this.Controls.Add(this.tasta1194);
            this.Controls.Add(this.tasta1195);
            this.Controls.Add(this.tasta1196);
            this.Controls.Add(this.tasta1197);
            this.Controls.Add(this.tasta1198);
            this.Controls.Add(this.tasta1199);
            this.Controls.Add(this.tasta1200);
            this.Controls.Add(this.tasta1201);
            this.Controls.Add(this.tasta1202);
            this.Controls.Add(this.tasta1203);
            this.Controls.Add(this.tasta1204);
            this.Controls.Add(this.tasta1205);
            this.Controls.Add(this.tasta1206);
            this.Controls.Add(this.tasta1207);
            this.Controls.Add(this.tasta1208);
            this.Controls.Add(this.tasta1209);
            this.Controls.Add(this.tasta1210);
            this.Controls.Add(this.tasta1211);
            this.Controls.Add(this.tasta1212);
            this.Controls.Add(this.tasta1213);
            this.Controls.Add(this.tasta1214);
            this.Controls.Add(this.tasta1215);
            this.Controls.Add(this.tasta1216);
            this.Controls.Add(this.tasta1217);
            this.Controls.Add(this.tasta1218);
            this.Controls.Add(this.tasta1219);
            this.Controls.Add(this.tasta1220);
            this.Controls.Add(this.tasta1221);
            this.Controls.Add(this.tasta1222);
            this.Controls.Add(this.tasta1223);
            this.Controls.Add(this.tasta1224);
            this.Controls.Add(this.tasta1225);
            this.Controls.Add(this.tasta1226);
            this.Controls.Add(this.tasta1227);
            this.Controls.Add(this.tasta1228);
            this.Controls.Add(this.tasta1229);
            this.Controls.Add(this.tasta1230);
            this.Controls.Add(this.tasta1231);
            this.Controls.Add(this.tasta1232);
            this.Controls.Add(this.tasta1233);
            this.Controls.Add(this.tasta1234);
            this.Controls.Add(this.tasta1235);
            this.Controls.Add(this.tasta1236);
            this.Controls.Add(this.tasta1237);
            this.Controls.Add(this.tasta1238);
            this.Controls.Add(this.tasta1239);
            this.Controls.Add(this.tasta1240);
            this.Controls.Add(this.tasta1241);
            this.Controls.Add(this.tasta1242);
            this.Controls.Add(this.tasta1243);
            this.Controls.Add(this.tasta1244);
            this.Controls.Add(this.tasta1245);
            this.Controls.Add(this.tasta1246);
            this.Controls.Add(this.tasta1247);
            this.Controls.Add(this.tasta1248);
            this.Controls.Add(this.tasta1249);
            this.Controls.Add(this.tasta1250);
            this.Controls.Add(this.tasta1251);
            this.Controls.Add(this.tasta1252);
            this.Controls.Add(this.tasta1253);
            this.Controls.Add(this.tasta1254);
            this.Controls.Add(this.tasta1255);
            this.Controls.Add(this.tasta1256);
            this.Controls.Add(this.tasta1257);
            this.Controls.Add(this.tasta1258);
            this.Controls.Add(this.tasta1259);
            this.Controls.Add(this.tasta1260);
            this.Controls.Add(this.tasta1261);
            this.Controls.Add(this.tasta1262);
            this.Controls.Add(this.tasta1263);
            this.Controls.Add(this.tasta1264);
            this.Controls.Add(this.tasta1265);
            this.Controls.Add(this.tasta1266);
            this.Controls.Add(this.tasta1267);
            this.Controls.Add(this.tasta1268);
            this.Controls.Add(this.tasta1269);
            this.Controls.Add(this.tasta1270);
            this.Controls.Add(this.tasta1271);
            this.Controls.Add(this.tasta1272);
            this.Controls.Add(this.tasta425);
            this.Controls.Add(this.tasta426);
            this.Controls.Add(this.tasta427);
            this.Controls.Add(this.tasta428);
            this.Controls.Add(this.tasta429);
            this.Controls.Add(this.tasta430);
            this.Controls.Add(this.tasta431);
            this.Controls.Add(this.tasta432);
            this.Controls.Add(this.tasta433);
            this.Controls.Add(this.tasta434);
            this.Controls.Add(this.tasta435);
            this.Controls.Add(this.tasta436);
            this.Controls.Add(this.tasta437);
            this.Controls.Add(this.tasta438);
            this.Controls.Add(this.tasta439);
            this.Controls.Add(this.tasta440);
            this.Controls.Add(this.tasta441);
            this.Controls.Add(this.tasta442);
            this.Controls.Add(this.tasta443);
            this.Controls.Add(this.tasta444);
            this.Controls.Add(this.tasta445);
            this.Controls.Add(this.tasta446);
            this.Controls.Add(this.tasta447);
            this.Controls.Add(this.tasta448);
            this.Controls.Add(this.tasta449);
            this.Controls.Add(this.tasta450);
            this.Controls.Add(this.tasta451);
            this.Controls.Add(this.tasta452);
            this.Controls.Add(this.tasta453);
            this.Controls.Add(this.tasta454);
            this.Controls.Add(this.tasta455);
            this.Controls.Add(this.tasta456);
            this.Controls.Add(this.tasta457);
            this.Controls.Add(this.tasta458);
            this.Controls.Add(this.tasta459);
            this.Controls.Add(this.tasta460);
            this.Controls.Add(this.tasta461);
            this.Controls.Add(this.tasta462);
            this.Controls.Add(this.tasta463);
            this.Controls.Add(this.tasta464);
            this.Controls.Add(this.tasta465);
            this.Controls.Add(this.tasta466);
            this.Controls.Add(this.tasta467);
            this.Controls.Add(this.tasta468);
            this.Controls.Add(this.tasta469);
            this.Controls.Add(this.tasta470);
            this.Controls.Add(this.tasta471);
            this.Controls.Add(this.tasta472);
            this.Controls.Add(this.tasta473);
            this.Controls.Add(this.tasta474);
            this.Controls.Add(this.tasta475);
            this.Controls.Add(this.tasta476);
            this.Controls.Add(this.tasta477);
            this.Controls.Add(this.tasta478);
            this.Controls.Add(this.tasta479);
            this.Controls.Add(this.tasta480);
            this.Controls.Add(this.tasta481);
            this.Controls.Add(this.tasta482);
            this.Controls.Add(this.tasta483);
            this.Controls.Add(this.tasta484);
            this.Controls.Add(this.tasta485);
            this.Controls.Add(this.tasta486);
            this.Controls.Add(this.tasta487);
            this.Controls.Add(this.tasta488);
            this.Controls.Add(this.tasta489);
            this.Controls.Add(this.tasta490);
            this.Controls.Add(this.tasta491);
            this.Controls.Add(this.tasta492);
            this.Controls.Add(this.tasta493);
            this.Controls.Add(this.tasta494);
            this.Controls.Add(this.tasta495);
            this.Controls.Add(this.tasta496);
            this.Controls.Add(this.tasta497);
            this.Controls.Add(this.tasta498);
            this.Controls.Add(this.tasta499);
            this.Controls.Add(this.tasta500);
            this.Controls.Add(this.tasta501);
            this.Controls.Add(this.tasta502);
            this.Controls.Add(this.tasta503);
            this.Controls.Add(this.tasta504);
            this.Controls.Add(this.tasta505);
            this.Controls.Add(this.tasta506);
            this.Controls.Add(this.tasta507);
            this.Controls.Add(this.tasta508);
            this.Controls.Add(this.tasta509);
            this.Controls.Add(this.tasta510);
            this.Controls.Add(this.tasta511);
            this.Controls.Add(this.tasta512);
            this.Controls.Add(this.tasta513);
            this.Controls.Add(this.tasta514);
            this.Controls.Add(this.tasta515);
            this.Controls.Add(this.tasta516);
            this.Controls.Add(this.tasta517);
            this.Controls.Add(this.tasta518);
            this.Controls.Add(this.tasta519);
            this.Controls.Add(this.tasta520);
            this.Controls.Add(this.tasta521);
            this.Controls.Add(this.tasta522);
            this.Controls.Add(this.tasta523);
            this.Controls.Add(this.tasta524);
            this.Controls.Add(this.tasta525);
            this.Controls.Add(this.tasta526);
            this.Controls.Add(this.tasta527);
            this.Controls.Add(this.tasta528);
            this.Controls.Add(this.tasta529);
            this.Controls.Add(this.tasta530);
            this.Controls.Add(this.tasta531);
            this.Controls.Add(this.tasta532);
            this.Controls.Add(this.tasta533);
            this.Controls.Add(this.tasta534);
            this.Controls.Add(this.tasta535);
            this.Controls.Add(this.tasta536);
            this.Controls.Add(this.tasta537);
            this.Controls.Add(this.tasta538);
            this.Controls.Add(this.tasta539);
            this.Controls.Add(this.tasta540);
            this.Controls.Add(this.tasta541);
            this.Controls.Add(this.tasta542);
            this.Controls.Add(this.tasta543);
            this.Controls.Add(this.tasta544);
            this.Controls.Add(this.tasta545);
            this.Controls.Add(this.tasta546);
            this.Controls.Add(this.tasta547);
            this.Controls.Add(this.tasta548);
            this.Controls.Add(this.tasta549);
            this.Controls.Add(this.tasta550);
            this.Controls.Add(this.tasta551);
            this.Controls.Add(this.tasta552);
            this.Controls.Add(this.tasta553);
            this.Controls.Add(this.tasta554);
            this.Controls.Add(this.tasta555);
            this.Controls.Add(this.tasta556);
            this.Controls.Add(this.tasta557);
            this.Controls.Add(this.tasta558);
            this.Controls.Add(this.tasta559);
            this.Controls.Add(this.tasta560);
            this.Controls.Add(this.tasta561);
            this.Controls.Add(this.tasta562);
            this.Controls.Add(this.tasta563);
            this.Controls.Add(this.tasta564);
            this.Controls.Add(this.tasta565);
            this.Controls.Add(this.tasta566);
            this.Controls.Add(this.tasta567);
            this.Controls.Add(this.tasta568);
            this.Controls.Add(this.tasta569);
            this.Controls.Add(this.tasta570);
            this.Controls.Add(this.tasta571);
            this.Controls.Add(this.tasta572);
            this.Controls.Add(this.tasta573);
            this.Controls.Add(this.tasta574);
            this.Controls.Add(this.tasta575);
            this.Controls.Add(this.tasta576);
            this.Controls.Add(this.tasta577);
            this.Controls.Add(this.tasta578);
            this.Controls.Add(this.tasta579);
            this.Controls.Add(this.tasta580);
            this.Controls.Add(this.tasta581);
            this.Controls.Add(this.tasta582);
            this.Controls.Add(this.tasta583);
            this.Controls.Add(this.tasta584);
            this.Controls.Add(this.tasta585);
            this.Controls.Add(this.tasta586);
            this.Controls.Add(this.tasta587);
            this.Controls.Add(this.tasta588);
            this.Controls.Add(this.tasta589);
            this.Controls.Add(this.tasta590);
            this.Controls.Add(this.tasta591);
            this.Controls.Add(this.tasta592);
            this.Controls.Add(this.tasta593);
            this.Controls.Add(this.tasta594);
            this.Controls.Add(this.tasta595);
            this.Controls.Add(this.tasta596);
            this.Controls.Add(this.tasta597);
            this.Controls.Add(this.tasta598);
            this.Controls.Add(this.tasta599);
            this.Controls.Add(this.tasta600);
            this.Controls.Add(this.tasta601);
            this.Controls.Add(this.tasta602);
            this.Controls.Add(this.tasta603);
            this.Controls.Add(this.tasta604);
            this.Controls.Add(this.tasta605);
            this.Controls.Add(this.tasta606);
            this.Controls.Add(this.tasta607);
            this.Controls.Add(this.tasta608);
            this.Controls.Add(this.tasta609);
            this.Controls.Add(this.tasta610);
            this.Controls.Add(this.tasta611);
            this.Controls.Add(this.tasta612);
            this.Controls.Add(this.tasta613);
            this.Controls.Add(this.tasta614);
            this.Controls.Add(this.tasta615);
            this.Controls.Add(this.tasta616);
            this.Controls.Add(this.tasta617);
            this.Controls.Add(this.tasta618);
            this.Controls.Add(this.tasta619);
            this.Controls.Add(this.tasta620);
            this.Controls.Add(this.tasta621);
            this.Controls.Add(this.tasta622);
            this.Controls.Add(this.tasta623);
            this.Controls.Add(this.tasta624);
            this.Controls.Add(this.tasta625);
            this.Controls.Add(this.tasta626);
            this.Controls.Add(this.tasta627);
            this.Controls.Add(this.tasta628);
            this.Controls.Add(this.tasta629);
            this.Controls.Add(this.tasta630);
            this.Controls.Add(this.tasta631);
            this.Controls.Add(this.tasta632);
            this.Controls.Add(this.tasta633);
            this.Controls.Add(this.tasta634);
            this.Controls.Add(this.tasta635);
            this.Controls.Add(this.tasta636);
            this.Controls.Add(this.tasta637);
            this.Controls.Add(this.tasta638);
            this.Controls.Add(this.tasta639);
            this.Controls.Add(this.tasta640);
            this.Controls.Add(this.tasta641);
            this.Controls.Add(this.tasta642);
            this.Controls.Add(this.tasta643);
            this.Controls.Add(this.tasta644);
            this.Controls.Add(this.tasta645);
            this.Controls.Add(this.tasta646);
            this.Controls.Add(this.tasta647);
            this.Controls.Add(this.tasta648);
            this.Controls.Add(this.tasta649);
            this.Controls.Add(this.tasta650);
            this.Controls.Add(this.tasta651);
            this.Controls.Add(this.tasta652);
            this.Controls.Add(this.tasta653);
            this.Controls.Add(this.tasta654);
            this.Controls.Add(this.tasta655);
            this.Controls.Add(this.tasta656);
            this.Controls.Add(this.tasta657);
            this.Controls.Add(this.tasta658);
            this.Controls.Add(this.tasta659);
            this.Controls.Add(this.tasta660);
            this.Controls.Add(this.tasta661);
            this.Controls.Add(this.tasta662);
            this.Controls.Add(this.tasta663);
            this.Controls.Add(this.tasta664);
            this.Controls.Add(this.tasta665);
            this.Controls.Add(this.tasta666);
            this.Controls.Add(this.tasta667);
            this.Controls.Add(this.tasta668);
            this.Controls.Add(this.tasta669);
            this.Controls.Add(this.tasta670);
            this.Controls.Add(this.tasta671);
            this.Controls.Add(this.tasta672);
            this.Controls.Add(this.tasta673);
            this.Controls.Add(this.tasta674);
            this.Controls.Add(this.tasta675);
            this.Controls.Add(this.tasta676);
            this.Controls.Add(this.tasta677);
            this.Controls.Add(this.tasta678);
            this.Controls.Add(this.tasta679);
            this.Controls.Add(this.tasta680);
            this.Controls.Add(this.tasta681);
            this.Controls.Add(this.tasta682);
            this.Controls.Add(this.tasta683);
            this.Controls.Add(this.tasta684);
            this.Controls.Add(this.tasta685);
            this.Controls.Add(this.tasta686);
            this.Controls.Add(this.tasta687);
            this.Controls.Add(this.tasta688);
            this.Controls.Add(this.tasta689);
            this.Controls.Add(this.tasta690);
            this.Controls.Add(this.tasta691);
            this.Controls.Add(this.tasta692);
            this.Controls.Add(this.tasta693);
            this.Controls.Add(this.tasta694);
            this.Controls.Add(this.tasta695);
            this.Controls.Add(this.tasta696);
            this.Controls.Add(this.tasta697);
            this.Controls.Add(this.tasta698);
            this.Controls.Add(this.tasta699);
            this.Controls.Add(this.tasta700);
            this.Controls.Add(this.tasta701);
            this.Controls.Add(this.tasta702);
            this.Controls.Add(this.tasta703);
            this.Controls.Add(this.tasta704);
            this.Controls.Add(this.tasta705);
            this.Controls.Add(this.tasta706);
            this.Controls.Add(this.tasta707);
            this.Controls.Add(this.tasta708);
            this.Controls.Add(this.tasta709);
            this.Controls.Add(this.tasta710);
            this.Controls.Add(this.tasta711);
            this.Controls.Add(this.tasta712);
            this.Controls.Add(this.tasta713);
            this.Controls.Add(this.tasta714);
            this.Controls.Add(this.tasta715);
            this.Controls.Add(this.tasta716);
            this.Controls.Add(this.tasta717);
            this.Controls.Add(this.tasta718);
            this.Controls.Add(this.tasta719);
            this.Controls.Add(this.tasta720);
            this.Controls.Add(this.tasta721);
            this.Controls.Add(this.tasta722);
            this.Controls.Add(this.tasta723);
            this.Controls.Add(this.tasta724);
            this.Controls.Add(this.tasta725);
            this.Controls.Add(this.tasta726);
            this.Controls.Add(this.tasta727);
            this.Controls.Add(this.tasta728);
            this.Controls.Add(this.tasta729);
            this.Controls.Add(this.tasta730);
            this.Controls.Add(this.tasta731);
            this.Controls.Add(this.tasta732);
            this.Controls.Add(this.tasta733);
            this.Controls.Add(this.tasta734);
            this.Controls.Add(this.tasta735);
            this.Controls.Add(this.tasta736);
            this.Controls.Add(this.tasta737);
            this.Controls.Add(this.tasta738);
            this.Controls.Add(this.tasta739);
            this.Controls.Add(this.tasta740);
            this.Controls.Add(this.tasta741);
            this.Controls.Add(this.tasta742);
            this.Controls.Add(this.tasta743);
            this.Controls.Add(this.tasta744);
            this.Controls.Add(this.tasta745);
            this.Controls.Add(this.tasta746);
            this.Controls.Add(this.tasta747);
            this.Controls.Add(this.tasta748);
            this.Controls.Add(this.tasta749);
            this.Controls.Add(this.tasta750);
            this.Controls.Add(this.tasta751);
            this.Controls.Add(this.tasta752);
            this.Controls.Add(this.tasta753);
            this.Controls.Add(this.tasta754);
            this.Controls.Add(this.tasta755);
            this.Controls.Add(this.tasta756);
            this.Controls.Add(this.tasta757);
            this.Controls.Add(this.tasta758);
            this.Controls.Add(this.tasta759);
            this.Controls.Add(this.tasta760);
            this.Controls.Add(this.tasta761);
            this.Controls.Add(this.tasta762);
            this.Controls.Add(this.tasta763);
            this.Controls.Add(this.tasta764);
            this.Controls.Add(this.tasta765);
            this.Controls.Add(this.tasta766);
            this.Controls.Add(this.tasta767);
            this.Controls.Add(this.tasta768);
            this.Controls.Add(this.tasta769);
            this.Controls.Add(this.tasta770);
            this.Controls.Add(this.tasta771);
            this.Controls.Add(this.tasta772);
            this.Controls.Add(this.tasta773);
            this.Controls.Add(this.tasta774);
            this.Controls.Add(this.tasta775);
            this.Controls.Add(this.tasta776);
            this.Controls.Add(this.tasta777);
            this.Controls.Add(this.tasta778);
            this.Controls.Add(this.tasta779);
            this.Controls.Add(this.tasta780);
            this.Controls.Add(this.tasta781);
            this.Controls.Add(this.tasta782);
            this.Controls.Add(this.tasta783);
            this.Controls.Add(this.tasta784);
            this.Controls.Add(this.tasta785);
            this.Controls.Add(this.tasta786);
            this.Controls.Add(this.tasta787);
            this.Controls.Add(this.tasta788);
            this.Controls.Add(this.tasta789);
            this.Controls.Add(this.tasta790);
            this.Controls.Add(this.tasta791);
            this.Controls.Add(this.tasta792);
            this.Controls.Add(this.tasta793);
            this.Controls.Add(this.tasta794);
            this.Controls.Add(this.tasta795);
            this.Controls.Add(this.tasta796);
            this.Controls.Add(this.tasta797);
            this.Controls.Add(this.tasta798);
            this.Controls.Add(this.tasta799);
            this.Controls.Add(this.tasta800);
            this.Controls.Add(this.tasta801);
            this.Controls.Add(this.tasta802);
            this.Controls.Add(this.tasta803);
            this.Controls.Add(this.tasta804);
            this.Controls.Add(this.tasta805);
            this.Controls.Add(this.tasta806);
            this.Controls.Add(this.tasta807);
            this.Controls.Add(this.tasta808);
            this.Controls.Add(this.tasta809);
            this.Controls.Add(this.tasta810);
            this.Controls.Add(this.tasta811);
            this.Controls.Add(this.tasta812);
            this.Controls.Add(this.tasta813);
            this.Controls.Add(this.tasta814);
            this.Controls.Add(this.tasta815);
            this.Controls.Add(this.tasta816);
            this.Controls.Add(this.tasta817);
            this.Controls.Add(this.tasta818);
            this.Controls.Add(this.tasta819);
            this.Controls.Add(this.tasta820);
            this.Controls.Add(this.tasta821);
            this.Controls.Add(this.tasta822);
            this.Controls.Add(this.tasta823);
            this.Controls.Add(this.tasta824);
            this.Controls.Add(this.tasta825);
            this.Controls.Add(this.tasta826);
            this.Controls.Add(this.tasta827);
            this.Controls.Add(this.tasta828);
            this.Controls.Add(this.tasta829);
            this.Controls.Add(this.tasta830);
            this.Controls.Add(this.tasta831);
            this.Controls.Add(this.tasta832);
            this.Controls.Add(this.tasta833);
            this.Controls.Add(this.tasta834);
            this.Controls.Add(this.tasta835);
            this.Controls.Add(this.tasta836);
            this.Controls.Add(this.tasta837);
            this.Controls.Add(this.tasta838);
            this.Controls.Add(this.tasta839);
            this.Controls.Add(this.tasta840);
            this.Controls.Add(this.tasta841);
            this.Controls.Add(this.tasta842);
            this.Controls.Add(this.tasta843);
            this.Controls.Add(this.tasta844);
            this.Controls.Add(this.tasta845);
            this.Controls.Add(this.tasta846);
            this.Controls.Add(this.tasta847);
            this.Controls.Add(this.tasta848);
            this.Controls.Add(this.tasta213);
            this.Controls.Add(this.tasta214);
            this.Controls.Add(this.tasta215);
            this.Controls.Add(this.tasta216);
            this.Controls.Add(this.tasta217);
            this.Controls.Add(this.tasta218);
            this.Controls.Add(this.tasta219);
            this.Controls.Add(this.tasta220);
            this.Controls.Add(this.tasta221);
            this.Controls.Add(this.tasta222);
            this.Controls.Add(this.tasta223);
            this.Controls.Add(this.tasta224);
            this.Controls.Add(this.tasta225);
            this.Controls.Add(this.tasta226);
            this.Controls.Add(this.tasta227);
            this.Controls.Add(this.tasta228);
            this.Controls.Add(this.tasta229);
            this.Controls.Add(this.tasta230);
            this.Controls.Add(this.tasta231);
            this.Controls.Add(this.tasta232);
            this.Controls.Add(this.tasta233);
            this.Controls.Add(this.tasta234);
            this.Controls.Add(this.tasta235);
            this.Controls.Add(this.tasta236);
            this.Controls.Add(this.tasta237);
            this.Controls.Add(this.tasta238);
            this.Controls.Add(this.tasta239);
            this.Controls.Add(this.tasta240);
            this.Controls.Add(this.tasta241);
            this.Controls.Add(this.tasta242);
            this.Controls.Add(this.tasta243);
            this.Controls.Add(this.tasta244);
            this.Controls.Add(this.tasta245);
            this.Controls.Add(this.tasta246);
            this.Controls.Add(this.tasta247);
            this.Controls.Add(this.tasta248);
            this.Controls.Add(this.tasta249);
            this.Controls.Add(this.tasta250);
            this.Controls.Add(this.tasta251);
            this.Controls.Add(this.tasta252);
            this.Controls.Add(this.tasta253);
            this.Controls.Add(this.tasta254);
            this.Controls.Add(this.tasta255);
            this.Controls.Add(this.tasta256);
            this.Controls.Add(this.tasta257);
            this.Controls.Add(this.tasta258);
            this.Controls.Add(this.tasta259);
            this.Controls.Add(this.tasta260);
            this.Controls.Add(this.tasta261);
            this.Controls.Add(this.tasta262);
            this.Controls.Add(this.tasta263);
            this.Controls.Add(this.tasta264);
            this.Controls.Add(this.tasta265);
            this.Controls.Add(this.tasta266);
            this.Controls.Add(this.tasta267);
            this.Controls.Add(this.tasta268);
            this.Controls.Add(this.tasta269);
            this.Controls.Add(this.tasta270);
            this.Controls.Add(this.tasta271);
            this.Controls.Add(this.tasta272);
            this.Controls.Add(this.tasta273);
            this.Controls.Add(this.tasta274);
            this.Controls.Add(this.tasta275);
            this.Controls.Add(this.tasta276);
            this.Controls.Add(this.tasta277);
            this.Controls.Add(this.tasta278);
            this.Controls.Add(this.tasta279);
            this.Controls.Add(this.tasta280);
            this.Controls.Add(this.tasta281);
            this.Controls.Add(this.tasta282);
            this.Controls.Add(this.tasta283);
            this.Controls.Add(this.tasta284);
            this.Controls.Add(this.tasta285);
            this.Controls.Add(this.tasta286);
            this.Controls.Add(this.tasta287);
            this.Controls.Add(this.tasta288);
            this.Controls.Add(this.tasta289);
            this.Controls.Add(this.tasta290);
            this.Controls.Add(this.tasta291);
            this.Controls.Add(this.tasta292);
            this.Controls.Add(this.tasta293);
            this.Controls.Add(this.tasta294);
            this.Controls.Add(this.tasta295);
            this.Controls.Add(this.tasta296);
            this.Controls.Add(this.tasta297);
            this.Controls.Add(this.tasta298);
            this.Controls.Add(this.tasta299);
            this.Controls.Add(this.tasta300);
            this.Controls.Add(this.tasta301);
            this.Controls.Add(this.tasta302);
            this.Controls.Add(this.tasta303);
            this.Controls.Add(this.tasta304);
            this.Controls.Add(this.tasta305);
            this.Controls.Add(this.tasta306);
            this.Controls.Add(this.tasta307);
            this.Controls.Add(this.tasta308);
            this.Controls.Add(this.tasta309);
            this.Controls.Add(this.tasta310);
            this.Controls.Add(this.tasta311);
            this.Controls.Add(this.tasta312);
            this.Controls.Add(this.tasta313);
            this.Controls.Add(this.tasta314);
            this.Controls.Add(this.tasta315);
            this.Controls.Add(this.tasta316);
            this.Controls.Add(this.tasta317);
            this.Controls.Add(this.tasta318);
            this.Controls.Add(this.tasta319);
            this.Controls.Add(this.tasta320);
            this.Controls.Add(this.tasta321);
            this.Controls.Add(this.tasta322);
            this.Controls.Add(this.tasta323);
            this.Controls.Add(this.tasta324);
            this.Controls.Add(this.tasta325);
            this.Controls.Add(this.tasta326);
            this.Controls.Add(this.tasta327);
            this.Controls.Add(this.tasta328);
            this.Controls.Add(this.tasta329);
            this.Controls.Add(this.tasta330);
            this.Controls.Add(this.tasta331);
            this.Controls.Add(this.tasta332);
            this.Controls.Add(this.tasta333);
            this.Controls.Add(this.tasta334);
            this.Controls.Add(this.tasta335);
            this.Controls.Add(this.tasta336);
            this.Controls.Add(this.tasta337);
            this.Controls.Add(this.tasta338);
            this.Controls.Add(this.tasta339);
            this.Controls.Add(this.tasta340);
            this.Controls.Add(this.tasta341);
            this.Controls.Add(this.tasta342);
            this.Controls.Add(this.tasta343);
            this.Controls.Add(this.tasta344);
            this.Controls.Add(this.tasta345);
            this.Controls.Add(this.tasta346);
            this.Controls.Add(this.tasta347);
            this.Controls.Add(this.tasta348);
            this.Controls.Add(this.tasta349);
            this.Controls.Add(this.tasta350);
            this.Controls.Add(this.tasta351);
            this.Controls.Add(this.tasta352);
            this.Controls.Add(this.tasta353);
            this.Controls.Add(this.tasta354);
            this.Controls.Add(this.tasta355);
            this.Controls.Add(this.tasta356);
            this.Controls.Add(this.tasta357);
            this.Controls.Add(this.tasta358);
            this.Controls.Add(this.tasta359);
            this.Controls.Add(this.tasta360);
            this.Controls.Add(this.tasta361);
            this.Controls.Add(this.tasta362);
            this.Controls.Add(this.tasta363);
            this.Controls.Add(this.tasta364);
            this.Controls.Add(this.tasta365);
            this.Controls.Add(this.tasta366);
            this.Controls.Add(this.tasta367);
            this.Controls.Add(this.tasta368);
            this.Controls.Add(this.tasta369);
            this.Controls.Add(this.tasta370);
            this.Controls.Add(this.tasta371);
            this.Controls.Add(this.tasta372);
            this.Controls.Add(this.tasta373);
            this.Controls.Add(this.tasta374);
            this.Controls.Add(this.tasta375);
            this.Controls.Add(this.tasta376);
            this.Controls.Add(this.tasta377);
            this.Controls.Add(this.tasta378);
            this.Controls.Add(this.tasta379);
            this.Controls.Add(this.tasta380);
            this.Controls.Add(this.tasta381);
            this.Controls.Add(this.tasta382);
            this.Controls.Add(this.tasta383);
            this.Controls.Add(this.tasta384);
            this.Controls.Add(this.tasta385);
            this.Controls.Add(this.tasta386);
            this.Controls.Add(this.tasta387);
            this.Controls.Add(this.tasta388);
            this.Controls.Add(this.tasta389);
            this.Controls.Add(this.tasta390);
            this.Controls.Add(this.tasta391);
            this.Controls.Add(this.tasta392);
            this.Controls.Add(this.tasta393);
            this.Controls.Add(this.tasta394);
            this.Controls.Add(this.tasta395);
            this.Controls.Add(this.tasta396);
            this.Controls.Add(this.tasta397);
            this.Controls.Add(this.tasta398);
            this.Controls.Add(this.tasta399);
            this.Controls.Add(this.tasta400);
            this.Controls.Add(this.tasta401);
            this.Controls.Add(this.tasta402);
            this.Controls.Add(this.tasta403);
            this.Controls.Add(this.tasta404);
            this.Controls.Add(this.tasta405);
            this.Controls.Add(this.tasta406);
            this.Controls.Add(this.tasta407);
            this.Controls.Add(this.tasta408);
            this.Controls.Add(this.tasta409);
            this.Controls.Add(this.tasta410);
            this.Controls.Add(this.tasta411);
            this.Controls.Add(this.tasta412);
            this.Controls.Add(this.tasta413);
            this.Controls.Add(this.tasta414);
            this.Controls.Add(this.tasta415);
            this.Controls.Add(this.tasta416);
            this.Controls.Add(this.tasta417);
            this.Controls.Add(this.tasta418);
            this.Controls.Add(this.tasta419);
            this.Controls.Add(this.tasta420);
            this.Controls.Add(this.tasta421);
            this.Controls.Add(this.tasta422);
            this.Controls.Add(this.tasta423);
            this.Controls.Add(this.tasta424);
            this.Controls.Add(this.tasta107);
            this.Controls.Add(this.tasta108);
            this.Controls.Add(this.tasta109);
            this.Controls.Add(this.tasta110);
            this.Controls.Add(this.tasta111);
            this.Controls.Add(this.tasta112);
            this.Controls.Add(this.tasta113);
            this.Controls.Add(this.tasta114);
            this.Controls.Add(this.tasta115);
            this.Controls.Add(this.tasta116);
            this.Controls.Add(this.tasta117);
            this.Controls.Add(this.tasta118);
            this.Controls.Add(this.tasta119);
            this.Controls.Add(this.tasta120);
            this.Controls.Add(this.tasta121);
            this.Controls.Add(this.tasta122);
            this.Controls.Add(this.tasta123);
            this.Controls.Add(this.tasta124);
            this.Controls.Add(this.tasta125);
            this.Controls.Add(this.tasta126);
            this.Controls.Add(this.tasta127);
            this.Controls.Add(this.tasta128);
            this.Controls.Add(this.tasta129);
            this.Controls.Add(this.tasta130);
            this.Controls.Add(this.tasta131);
            this.Controls.Add(this.tasta132);
            this.Controls.Add(this.tasta133);
            this.Controls.Add(this.tasta134);
            this.Controls.Add(this.tasta135);
            this.Controls.Add(this.tasta136);
            this.Controls.Add(this.tasta137);
            this.Controls.Add(this.tasta138);
            this.Controls.Add(this.tasta139);
            this.Controls.Add(this.tasta140);
            this.Controls.Add(this.tasta141);
            this.Controls.Add(this.tasta142);
            this.Controls.Add(this.tasta143);
            this.Controls.Add(this.tasta144);
            this.Controls.Add(this.tasta145);
            this.Controls.Add(this.tasta146);
            this.Controls.Add(this.tasta147);
            this.Controls.Add(this.tasta148);
            this.Controls.Add(this.tasta149);
            this.Controls.Add(this.tasta150);
            this.Controls.Add(this.tasta151);
            this.Controls.Add(this.tasta152);
            this.Controls.Add(this.tasta153);
            this.Controls.Add(this.tasta154);
            this.Controls.Add(this.tasta155);
            this.Controls.Add(this.tasta156);
            this.Controls.Add(this.tasta157);
            this.Controls.Add(this.tasta158);
            this.Controls.Add(this.tasta159);
            this.Controls.Add(this.tasta160);
            this.Controls.Add(this.tasta161);
            this.Controls.Add(this.tasta162);
            this.Controls.Add(this.tasta163);
            this.Controls.Add(this.tasta164);
            this.Controls.Add(this.tasta165);
            this.Controls.Add(this.tasta166);
            this.Controls.Add(this.tasta167);
            this.Controls.Add(this.tasta168);
            this.Controls.Add(this.tasta169);
            this.Controls.Add(this.tasta170);
            this.Controls.Add(this.tasta171);
            this.Controls.Add(this.tasta172);
            this.Controls.Add(this.tasta173);
            this.Controls.Add(this.tasta174);
            this.Controls.Add(this.tasta175);
            this.Controls.Add(this.tasta176);
            this.Controls.Add(this.tasta177);
            this.Controls.Add(this.tasta178);
            this.Controls.Add(this.tasta179);
            this.Controls.Add(this.tasta180);
            this.Controls.Add(this.tasta181);
            this.Controls.Add(this.tasta182);
            this.Controls.Add(this.tasta183);
            this.Controls.Add(this.tasta184);
            this.Controls.Add(this.tasta185);
            this.Controls.Add(this.tasta186);
            this.Controls.Add(this.tasta187);
            this.Controls.Add(this.tasta188);
            this.Controls.Add(this.tasta189);
            this.Controls.Add(this.tasta190);
            this.Controls.Add(this.tasta191);
            this.Controls.Add(this.tasta192);
            this.Controls.Add(this.tasta193);
            this.Controls.Add(this.tasta194);
            this.Controls.Add(this.tasta195);
            this.Controls.Add(this.tasta196);
            this.Controls.Add(this.tasta197);
            this.Controls.Add(this.tasta198);
            this.Controls.Add(this.tasta199);
            this.Controls.Add(this.tasta200);
            this.Controls.Add(this.tasta201);
            this.Controls.Add(this.tasta202);
            this.Controls.Add(this.tasta203);
            this.Controls.Add(this.tasta204);
            this.Controls.Add(this.tasta205);
            this.Controls.Add(this.tasta206);
            this.Controls.Add(this.tasta207);
            this.Controls.Add(this.tasta208);
            this.Controls.Add(this.tasta209);
            this.Controls.Add(this.tasta210);
            this.Controls.Add(this.tasta211);
            this.Controls.Add(this.tasta212);
            this.Controls.Add(this.tasta54);
            this.Controls.Add(this.tasta55);
            this.Controls.Add(this.tasta56);
            this.Controls.Add(this.tasta57);
            this.Controls.Add(this.tasta58);
            this.Controls.Add(this.tasta59);
            this.Controls.Add(this.tasta60);
            this.Controls.Add(this.tasta61);
            this.Controls.Add(this.tasta62);
            this.Controls.Add(this.tasta63);
            this.Controls.Add(this.tasta64);
            this.Controls.Add(this.tasta65);
            this.Controls.Add(this.tasta66);
            this.Controls.Add(this.tasta67);
            this.Controls.Add(this.tasta68);
            this.Controls.Add(this.tasta69);
            this.Controls.Add(this.tasta70);
            this.Controls.Add(this.tasta71);
            this.Controls.Add(this.tasta72);
            this.Controls.Add(this.tasta73);
            this.Controls.Add(this.tasta74);
            this.Controls.Add(this.tasta75);
            this.Controls.Add(this.tasta76);
            this.Controls.Add(this.tasta77);
            this.Controls.Add(this.tasta78);
            this.Controls.Add(this.tasta79);
            this.Controls.Add(this.tasta80);
            this.Controls.Add(this.tasta81);
            this.Controls.Add(this.tasta82);
            this.Controls.Add(this.tasta83);
            this.Controls.Add(this.tasta84);
            this.Controls.Add(this.tasta85);
            this.Controls.Add(this.tasta86);
            this.Controls.Add(this.tasta87);
            this.Controls.Add(this.tasta88);
            this.Controls.Add(this.tasta89);
            this.Controls.Add(this.tasta90);
            this.Controls.Add(this.tasta91);
            this.Controls.Add(this.tasta92);
            this.Controls.Add(this.tasta93);
            this.Controls.Add(this.tasta94);
            this.Controls.Add(this.tasta95);
            this.Controls.Add(this.tasta96);
            this.Controls.Add(this.tasta97);
            this.Controls.Add(this.tasta98);
            this.Controls.Add(this.tasta99);
            this.Controls.Add(this.tasta100);
            this.Controls.Add(this.tasta101);
            this.Controls.Add(this.tasta102);
            this.Controls.Add(this.tasta103);
            this.Controls.Add(this.tasta104);
            this.Controls.Add(this.tasta105);
            this.Controls.Add(this.tasta106);
            this.Controls.Add(this.tasta49);
            this.Controls.Add(this.tasta50);
            this.Controls.Add(this.tasta51);
            this.Controls.Add(this.tasta52);
            this.Controls.Add(this.tasta53);
            this.Controls.Add(this.tasta25);
            this.Controls.Add(this.tasta26);
            this.Controls.Add(this.tasta27);
            this.Controls.Add(this.tasta28);
            this.Controls.Add(this.tasta29);
            this.Controls.Add(this.tasta30);
            this.Controls.Add(this.tasta31);
            this.Controls.Add(this.tasta32);
            this.Controls.Add(this.tasta33);
            this.Controls.Add(this.tasta34);
            this.Controls.Add(this.tasta35);
            this.Controls.Add(this.tasta36);
            this.Controls.Add(this.tasta37);
            this.Controls.Add(this.tasta38);
            this.Controls.Add(this.tasta39);
            this.Controls.Add(this.tasta40);
            this.Controls.Add(this.tasta41);
            this.Controls.Add(this.tasta42);
            this.Controls.Add(this.tasta43);
            this.Controls.Add(this.tasta44);
            this.Controls.Add(this.tasta45);
            this.Controls.Add(this.tasta46);
            this.Controls.Add(this.tasta47);
            this.Controls.Add(this.tasta48);
            this.Controls.Add(this.tasta13);
            this.Controls.Add(this.tasta14);
            this.Controls.Add(this.tasta15);
            this.Controls.Add(this.tasta16);
            this.Controls.Add(this.tasta17);
            this.Controls.Add(this.tasta18);
            this.Controls.Add(this.tasta19);
            this.Controls.Add(this.tasta20);
            this.Controls.Add(this.tasta21);
            this.Controls.Add(this.tasta22);
            this.Controls.Add(this.tasta23);
            this.Controls.Add(this.tasta24);
            this.Controls.Add(this.tasta7);
            this.Controls.Add(this.tasta8);
            this.Controls.Add(this.tasta9);
            this.Controls.Add(this.tasta10);
            this.Controls.Add(this.tasta11);
            this.Controls.Add(this.tasta12);
            this.Controls.Add(this.tasta4);
            this.Controls.Add(this.tasta5);
            this.Controls.Add(this.tasta6);
            this.Controls.Add(this.tasta3);
            this.Controls.Add(this.tasta2);
            this.Controls.Add(this.tasta1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private tasta tasta1;
        private tasta tasta2;
        private tasta tasta3;
        private tasta tasta4;
        private tasta tasta5;
        private tasta tasta6;
        private tasta tasta7;
        private tasta tasta8;
        private tasta tasta9;
        private tasta tasta10;
        private tasta tasta11;
        private tasta tasta12;
        private tasta tasta13;
        private tasta tasta14;
        private tasta tasta15;
        private tasta tasta16;
        private tasta tasta17;
        private tasta tasta18;
        private tasta tasta19;
        private tasta tasta20;
        private tasta tasta21;
        private tasta tasta22;
        private tasta tasta23;
        private tasta tasta24;
        private tasta tasta25;
        private tasta tasta26;
        private tasta tasta27;
        private tasta tasta28;
        private tasta tasta29;
        private tasta tasta30;
        private tasta tasta31;
        private tasta tasta32;
        private tasta tasta33;
        private tasta tasta34;
        private tasta tasta35;
        private tasta tasta36;
        private tasta tasta37;
        private tasta tasta38;
        private tasta tasta39;
        private tasta tasta40;
        private tasta tasta41;
        private tasta tasta42;
        private tasta tasta43;
        private tasta tasta44;
        private tasta tasta45;
        private tasta tasta46;
        private tasta tasta47;
        private tasta tasta48;
        private tasta tasta49;
        private tasta tasta50;
        private tasta tasta51;
        private tasta tasta52;
        private tasta tasta53;
        private tasta tasta54;
        private tasta tasta55;
        private tasta tasta56;
        private tasta tasta57;
        private tasta tasta58;
        private tasta tasta59;
        private tasta tasta60;
        private tasta tasta61;
        private tasta tasta62;
        private tasta tasta63;
        private tasta tasta64;
        private tasta tasta65;
        private tasta tasta66;
        private tasta tasta67;
        private tasta tasta68;
        private tasta tasta69;
        private tasta tasta70;
        private tasta tasta71;
        private tasta tasta72;
        private tasta tasta73;
        private tasta tasta74;
        private tasta tasta75;
        private tasta tasta76;
        private tasta tasta77;
        private tasta tasta78;
        private tasta tasta79;
        private tasta tasta80;
        private tasta tasta81;
        private tasta tasta82;
        private tasta tasta83;
        private tasta tasta84;
        private tasta tasta85;
        private tasta tasta86;
        private tasta tasta87;
        private tasta tasta88;
        private tasta tasta89;
        private tasta tasta90;
        private tasta tasta91;
        private tasta tasta92;
        private tasta tasta93;
        private tasta tasta94;
        private tasta tasta95;
        private tasta tasta96;
        private tasta tasta97;
        private tasta tasta98;
        private tasta tasta99;
        private tasta tasta100;
        private tasta tasta101;
        private tasta tasta102;
        private tasta tasta103;
        private tasta tasta104;
        private tasta tasta105;
        private tasta tasta106;
        private tasta tasta107;
        private tasta tasta108;
        private tasta tasta109;
        private tasta tasta110;
        private tasta tasta111;
        private tasta tasta112;
        private tasta tasta113;
        private tasta tasta114;
        private tasta tasta115;
        private tasta tasta116;
        private tasta tasta117;
        private tasta tasta118;
        private tasta tasta119;
        private tasta tasta120;
        private tasta tasta121;
        private tasta tasta122;
        private tasta tasta123;
        private tasta tasta124;
        private tasta tasta125;
        private tasta tasta126;
        private tasta tasta127;
        private tasta tasta128;
        private tasta tasta129;
        private tasta tasta130;
        private tasta tasta131;
        private tasta tasta132;
        private tasta tasta133;
        private tasta tasta134;
        private tasta tasta135;
        private tasta tasta136;
        private tasta tasta137;
        private tasta tasta138;
        private tasta tasta139;
        private tasta tasta140;
        private tasta tasta141;
        private tasta tasta142;
        private tasta tasta143;
        private tasta tasta144;
        private tasta tasta145;
        private tasta tasta146;
        private tasta tasta147;
        private tasta tasta148;
        private tasta tasta149;
        private tasta tasta150;
        private tasta tasta151;
        private tasta tasta152;
        private tasta tasta153;
        private tasta tasta154;
        private tasta tasta155;
        private tasta tasta156;
        private tasta tasta157;
        private tasta tasta158;
        private tasta tasta159;
        private tasta tasta160;
        private tasta tasta161;
        private tasta tasta162;
        private tasta tasta163;
        private tasta tasta164;
        private tasta tasta165;
        private tasta tasta166;
        private tasta tasta167;
        private tasta tasta168;
        private tasta tasta169;
        private tasta tasta170;
        private tasta tasta171;
        private tasta tasta172;
        private tasta tasta173;
        private tasta tasta174;
        private tasta tasta175;
        private tasta tasta176;
        private tasta tasta177;
        private tasta tasta178;
        private tasta tasta179;
        private tasta tasta180;
        private tasta tasta181;
        private tasta tasta182;
        private tasta tasta183;
        private tasta tasta184;
        private tasta tasta185;
        private tasta tasta186;
        private tasta tasta187;
        private tasta tasta188;
        private tasta tasta189;
        private tasta tasta190;
        private tasta tasta191;
        private tasta tasta192;
        private tasta tasta193;
        private tasta tasta194;
        private tasta tasta195;
        private tasta tasta196;
        private tasta tasta197;
        private tasta tasta198;
        private tasta tasta199;
        private tasta tasta200;
        private tasta tasta201;
        private tasta tasta202;
        private tasta tasta203;
        private tasta tasta204;
        private tasta tasta205;
        private tasta tasta206;
        private tasta tasta207;
        private tasta tasta208;
        private tasta tasta209;
        private tasta tasta210;
        private tasta tasta211;
        private tasta tasta212;
        private tasta tasta213;
        private tasta tasta214;
        private tasta tasta215;
        private tasta tasta216;
        private tasta tasta217;
        private tasta tasta218;
        private tasta tasta219;
        private tasta tasta220;
        private tasta tasta221;
        private tasta tasta222;
        private tasta tasta223;
        private tasta tasta224;
        private tasta tasta225;
        private tasta tasta226;
        private tasta tasta227;
        private tasta tasta228;
        private tasta tasta229;
        private tasta tasta230;
        private tasta tasta231;
        private tasta tasta232;
        private tasta tasta233;
        private tasta tasta234;
        private tasta tasta235;
        private tasta tasta236;
        private tasta tasta237;
        private tasta tasta238;
        private tasta tasta239;
        private tasta tasta240;
        private tasta tasta241;
        private tasta tasta242;
        private tasta tasta243;
        private tasta tasta244;
        private tasta tasta245;
        private tasta tasta246;
        private tasta tasta247;
        private tasta tasta248;
        private tasta tasta249;
        private tasta tasta250;
        private tasta tasta251;
        private tasta tasta252;
        private tasta tasta253;
        private tasta tasta254;
        private tasta tasta255;
        private tasta tasta256;
        private tasta tasta257;
        private tasta tasta258;
        private tasta tasta259;
        private tasta tasta260;
        private tasta tasta261;
        private tasta tasta262;
        private tasta tasta263;
        private tasta tasta264;
        private tasta tasta265;
        private tasta tasta266;
        private tasta tasta267;
        private tasta tasta268;
        private tasta tasta269;
        private tasta tasta270;
        private tasta tasta271;
        private tasta tasta272;
        private tasta tasta273;
        private tasta tasta274;
        private tasta tasta275;
        private tasta tasta276;
        private tasta tasta277;
        private tasta tasta278;
        private tasta tasta279;
        private tasta tasta280;
        private tasta tasta281;
        private tasta tasta282;
        private tasta tasta283;
        private tasta tasta284;
        private tasta tasta285;
        private tasta tasta286;
        private tasta tasta287;
        private tasta tasta288;
        private tasta tasta289;
        private tasta tasta290;
        private tasta tasta291;
        private tasta tasta292;
        private tasta tasta293;
        private tasta tasta294;
        private tasta tasta295;
        private tasta tasta296;
        private tasta tasta297;
        private tasta tasta298;
        private tasta tasta299;
        private tasta tasta300;
        private tasta tasta301;
        private tasta tasta302;
        private tasta tasta303;
        private tasta tasta304;
        private tasta tasta305;
        private tasta tasta306;
        private tasta tasta307;
        private tasta tasta308;
        private tasta tasta309;
        private tasta tasta310;
        private tasta tasta311;
        private tasta tasta312;
        private tasta tasta313;
        private tasta tasta314;
        private tasta tasta315;
        private tasta tasta316;
        private tasta tasta317;
        private tasta tasta318;
        private tasta tasta319;
        private tasta tasta320;
        private tasta tasta321;
        private tasta tasta322;
        private tasta tasta323;
        private tasta tasta324;
        private tasta tasta325;
        private tasta tasta326;
        private tasta tasta327;
        private tasta tasta328;
        private tasta tasta329;
        private tasta tasta330;
        private tasta tasta331;
        private tasta tasta332;
        private tasta tasta333;
        private tasta tasta334;
        private tasta tasta335;
        private tasta tasta336;
        private tasta tasta337;
        private tasta tasta338;
        private tasta tasta339;
        private tasta tasta340;
        private tasta tasta341;
        private tasta tasta342;
        private tasta tasta343;
        private tasta tasta344;
        private tasta tasta345;
        private tasta tasta346;
        private tasta tasta347;
        private tasta tasta348;
        private tasta tasta349;
        private tasta tasta350;
        private tasta tasta351;
        private tasta tasta352;
        private tasta tasta353;
        private tasta tasta354;
        private tasta tasta355;
        private tasta tasta356;
        private tasta tasta357;
        private tasta tasta358;
        private tasta tasta359;
        private tasta tasta360;
        private tasta tasta361;
        private tasta tasta362;
        private tasta tasta363;
        private tasta tasta364;
        private tasta tasta365;
        private tasta tasta366;
        private tasta tasta367;
        private tasta tasta368;
        private tasta tasta369;
        private tasta tasta370;
        private tasta tasta371;
        private tasta tasta372;
        private tasta tasta373;
        private tasta tasta374;
        private tasta tasta375;
        private tasta tasta376;
        private tasta tasta377;
        private tasta tasta378;
        private tasta tasta379;
        private tasta tasta380;
        private tasta tasta381;
        private tasta tasta382;
        private tasta tasta383;
        private tasta tasta384;
        private tasta tasta385;
        private tasta tasta386;
        private tasta tasta387;
        private tasta tasta388;
        private tasta tasta389;
        private tasta tasta390;
        private tasta tasta391;
        private tasta tasta392;
        private tasta tasta393;
        private tasta tasta394;
        private tasta tasta395;
        private tasta tasta396;
        private tasta tasta397;
        private tasta tasta398;
        private tasta tasta399;
        private tasta tasta400;
        private tasta tasta401;
        private tasta tasta402;
        private tasta tasta403;
        private tasta tasta404;
        private tasta tasta405;
        private tasta tasta406;
        private tasta tasta407;
        private tasta tasta408;
        private tasta tasta409;
        private tasta tasta410;
        private tasta tasta411;
        private tasta tasta412;
        private tasta tasta413;
        private tasta tasta414;
        private tasta tasta415;
        private tasta tasta416;
        private tasta tasta417;
        private tasta tasta418;
        private tasta tasta419;
        private tasta tasta420;
        private tasta tasta421;
        private tasta tasta422;
        private tasta tasta423;
        private tasta tasta424;
        private tasta tasta425;
        private tasta tasta426;
        private tasta tasta427;
        private tasta tasta428;
        private tasta tasta429;
        private tasta tasta430;
        private tasta tasta431;
        private tasta tasta432;
        private tasta tasta433;
        private tasta tasta434;
        private tasta tasta435;
        private tasta tasta436;
        private tasta tasta437;
        private tasta tasta438;
        private tasta tasta439;
        private tasta tasta440;
        private tasta tasta441;
        private tasta tasta442;
        private tasta tasta443;
        private tasta tasta444;
        private tasta tasta445;
        private tasta tasta446;
        private tasta tasta447;
        private tasta tasta448;
        private tasta tasta449;
        private tasta tasta450;
        private tasta tasta451;
        private tasta tasta452;
        private tasta tasta453;
        private tasta tasta454;
        private tasta tasta455;
        private tasta tasta456;
        private tasta tasta457;
        private tasta tasta458;
        private tasta tasta459;
        private tasta tasta460;
        private tasta tasta461;
        private tasta tasta462;
        private tasta tasta463;
        private tasta tasta464;
        private tasta tasta465;
        private tasta tasta466;
        private tasta tasta467;
        private tasta tasta468;
        private tasta tasta469;
        private tasta tasta470;
        private tasta tasta471;
        private tasta tasta472;
        private tasta tasta473;
        private tasta tasta474;
        private tasta tasta475;
        private tasta tasta476;
        private tasta tasta477;
        private tasta tasta478;
        private tasta tasta479;
        private tasta tasta480;
        private tasta tasta481;
        private tasta tasta482;
        private tasta tasta483;
        private tasta tasta484;
        private tasta tasta485;
        private tasta tasta486;
        private tasta tasta487;
        private tasta tasta488;
        private tasta tasta489;
        private tasta tasta490;
        private tasta tasta491;
        private tasta tasta492;
        private tasta tasta493;
        private tasta tasta494;
        private tasta tasta495;
        private tasta tasta496;
        private tasta tasta497;
        private tasta tasta498;
        private tasta tasta499;
        private tasta tasta500;
        private tasta tasta501;
        private tasta tasta502;
        private tasta tasta503;
        private tasta tasta504;
        private tasta tasta505;
        private tasta tasta506;
        private tasta tasta507;
        private tasta tasta508;
        private tasta tasta509;
        private tasta tasta510;
        private tasta tasta511;
        private tasta tasta512;
        private tasta tasta513;
        private tasta tasta514;
        private tasta tasta515;
        private tasta tasta516;
        private tasta tasta517;
        private tasta tasta518;
        private tasta tasta519;
        private tasta tasta520;
        private tasta tasta521;
        private tasta tasta522;
        private tasta tasta523;
        private tasta tasta524;
        private tasta tasta525;
        private tasta tasta526;
        private tasta tasta527;
        private tasta tasta528;
        private tasta tasta529;
        private tasta tasta530;
        private tasta tasta531;
        private tasta tasta532;
        private tasta tasta533;
        private tasta tasta534;
        private tasta tasta535;
        private tasta tasta536;
        private tasta tasta537;
        private tasta tasta538;
        private tasta tasta539;
        private tasta tasta540;
        private tasta tasta541;
        private tasta tasta542;
        private tasta tasta543;
        private tasta tasta544;
        private tasta tasta545;
        private tasta tasta546;
        private tasta tasta547;
        private tasta tasta548;
        private tasta tasta549;
        private tasta tasta550;
        private tasta tasta551;
        private tasta tasta552;
        private tasta tasta553;
        private tasta tasta554;
        private tasta tasta555;
        private tasta tasta556;
        private tasta tasta557;
        private tasta tasta558;
        private tasta tasta559;
        private tasta tasta560;
        private tasta tasta561;
        private tasta tasta562;
        private tasta tasta563;
        private tasta tasta564;
        private tasta tasta565;
        private tasta tasta566;
        private tasta tasta567;
        private tasta tasta568;
        private tasta tasta569;
        private tasta tasta570;
        private tasta tasta571;
        private tasta tasta572;
        private tasta tasta573;
        private tasta tasta574;
        private tasta tasta575;
        private tasta tasta576;
        private tasta tasta577;
        private tasta tasta578;
        private tasta tasta579;
        private tasta tasta580;
        private tasta tasta581;
        private tasta tasta582;
        private tasta tasta583;
        private tasta tasta584;
        private tasta tasta585;
        private tasta tasta586;
        private tasta tasta587;
        private tasta tasta588;
        private tasta tasta589;
        private tasta tasta590;
        private tasta tasta591;
        private tasta tasta592;
        private tasta tasta593;
        private tasta tasta594;
        private tasta tasta595;
        private tasta tasta596;
        private tasta tasta597;
        private tasta tasta598;
        private tasta tasta599;
        private tasta tasta600;
        private tasta tasta601;
        private tasta tasta602;
        private tasta tasta603;
        private tasta tasta604;
        private tasta tasta605;
        private tasta tasta606;
        private tasta tasta607;
        private tasta tasta608;
        private tasta tasta609;
        private tasta tasta610;
        private tasta tasta611;
        private tasta tasta612;
        private tasta tasta613;
        private tasta tasta614;
        private tasta tasta615;
        private tasta tasta616;
        private tasta tasta617;
        private tasta tasta618;
        private tasta tasta619;
        private tasta tasta620;
        private tasta tasta621;
        private tasta tasta622;
        private tasta tasta623;
        private tasta tasta624;
        private tasta tasta625;
        private tasta tasta626;
        private tasta tasta627;
        private tasta tasta628;
        private tasta tasta629;
        private tasta tasta630;
        private tasta tasta631;
        private tasta tasta632;
        private tasta tasta633;
        private tasta tasta634;
        private tasta tasta635;
        private tasta tasta636;
        private tasta tasta637;
        private tasta tasta638;
        private tasta tasta639;
        private tasta tasta640;
        private tasta tasta641;
        private tasta tasta642;
        private tasta tasta643;
        private tasta tasta644;
        private tasta tasta645;
        private tasta tasta646;
        private tasta tasta647;
        private tasta tasta648;
        private tasta tasta649;
        private tasta tasta650;
        private tasta tasta651;
        private tasta tasta652;
        private tasta tasta653;
        private tasta tasta654;
        private tasta tasta655;
        private tasta tasta656;
        private tasta tasta657;
        private tasta tasta658;
        private tasta tasta659;
        private tasta tasta660;
        private tasta tasta661;
        private tasta tasta662;
        private tasta tasta663;
        private tasta tasta664;
        private tasta tasta665;
        private tasta tasta666;
        private tasta tasta667;
        private tasta tasta668;
        private tasta tasta669;
        private tasta tasta670;
        private tasta tasta671;
        private tasta tasta672;
        private tasta tasta673;
        private tasta tasta674;
        private tasta tasta675;
        private tasta tasta676;
        private tasta tasta677;
        private tasta tasta678;
        private tasta tasta679;
        private tasta tasta680;
        private tasta tasta681;
        private tasta tasta682;
        private tasta tasta683;
        private tasta tasta684;
        private tasta tasta685;
        private tasta tasta686;
        private tasta tasta687;
        private tasta tasta688;
        private tasta tasta689;
        private tasta tasta690;
        private tasta tasta691;
        private tasta tasta692;
        private tasta tasta693;
        private tasta tasta694;
        private tasta tasta695;
        private tasta tasta696;
        private tasta tasta697;
        private tasta tasta698;
        private tasta tasta699;
        private tasta tasta700;
        private tasta tasta701;
        private tasta tasta702;
        private tasta tasta703;
        private tasta tasta704;
        private tasta tasta705;
        private tasta tasta706;
        private tasta tasta707;
        private tasta tasta708;
        private tasta tasta709;
        private tasta tasta710;
        private tasta tasta711;
        private tasta tasta712;
        private tasta tasta713;
        private tasta tasta714;
        private tasta tasta715;
        private tasta tasta716;
        private tasta tasta717;
        private tasta tasta718;
        private tasta tasta719;
        private tasta tasta720;
        private tasta tasta721;
        private tasta tasta722;
        private tasta tasta723;
        private tasta tasta724;
        private tasta tasta725;
        private tasta tasta726;
        private tasta tasta727;
        private tasta tasta728;
        private tasta tasta729;
        private tasta tasta730;
        private tasta tasta731;
        private tasta tasta732;
        private tasta tasta733;
        private tasta tasta734;
        private tasta tasta735;
        private tasta tasta736;
        private tasta tasta737;
        private tasta tasta738;
        private tasta tasta739;
        private tasta tasta740;
        private tasta tasta741;
        private tasta tasta742;
        private tasta tasta743;
        private tasta tasta744;
        private tasta tasta745;
        private tasta tasta746;
        private tasta tasta747;
        private tasta tasta748;
        private tasta tasta749;
        private tasta tasta750;
        private tasta tasta751;
        private tasta tasta752;
        private tasta tasta753;
        private tasta tasta754;
        private tasta tasta755;
        private tasta tasta756;
        private tasta tasta757;
        private tasta tasta758;
        private tasta tasta759;
        private tasta tasta760;
        private tasta tasta761;
        private tasta tasta762;
        private tasta tasta763;
        private tasta tasta764;
        private tasta tasta765;
        private tasta tasta766;
        private tasta tasta767;
        private tasta tasta768;
        private tasta tasta769;
        private tasta tasta770;
        private tasta tasta771;
        private tasta tasta772;
        private tasta tasta773;
        private tasta tasta774;
        private tasta tasta775;
        private tasta tasta776;
        private tasta tasta777;
        private tasta tasta778;
        private tasta tasta779;
        private tasta tasta780;
        private tasta tasta781;
        private tasta tasta782;
        private tasta tasta783;
        private tasta tasta784;
        private tasta tasta785;
        private tasta tasta786;
        private tasta tasta787;
        private tasta tasta788;
        private tasta tasta789;
        private tasta tasta790;
        private tasta tasta791;
        private tasta tasta792;
        private tasta tasta793;
        private tasta tasta794;
        private tasta tasta795;
        private tasta tasta796;
        private tasta tasta797;
        private tasta tasta798;
        private tasta tasta799;
        private tasta tasta800;
        private tasta tasta801;
        private tasta tasta802;
        private tasta tasta803;
        private tasta tasta804;
        private tasta tasta805;
        private tasta tasta806;
        private tasta tasta807;
        private tasta tasta808;
        private tasta tasta809;
        private tasta tasta810;
        private tasta tasta811;
        private tasta tasta812;
        private tasta tasta813;
        private tasta tasta814;
        private tasta tasta815;
        private tasta tasta816;
        private tasta tasta817;
        private tasta tasta818;
        private tasta tasta819;
        private tasta tasta820;
        private tasta tasta821;
        private tasta tasta822;
        private tasta tasta823;
        private tasta tasta824;
        private tasta tasta825;
        private tasta tasta826;
        private tasta tasta827;
        private tasta tasta828;
        private tasta tasta829;
        private tasta tasta830;
        private tasta tasta831;
        private tasta tasta832;
        private tasta tasta833;
        private tasta tasta834;
        private tasta tasta835;
        private tasta tasta836;
        private tasta tasta837;
        private tasta tasta838;
        private tasta tasta839;
        private tasta tasta840;
        private tasta tasta841;
        private tasta tasta842;
        private tasta tasta843;
        private tasta tasta844;
        private tasta tasta845;
        private tasta tasta846;
        private tasta tasta847;
        private tasta tasta848;
        private tasta tasta849;
        private tasta tasta850;
        private tasta tasta851;
        private tasta tasta852;
        private tasta tasta853;
        private tasta tasta854;
        private tasta tasta855;
        private tasta tasta856;
        private tasta tasta857;
        private tasta tasta858;
        private tasta tasta859;
        private tasta tasta860;
        private tasta tasta861;
        private tasta tasta862;
        private tasta tasta863;
        private tasta tasta864;
        private tasta tasta865;
        private tasta tasta866;
        private tasta tasta867;
        private tasta tasta868;
        private tasta tasta869;
        private tasta tasta870;
        private tasta tasta871;
        private tasta tasta872;
        private tasta tasta873;
        private tasta tasta874;
        private tasta tasta875;
        private tasta tasta876;
        private tasta tasta877;
        private tasta tasta878;
        private tasta tasta879;
        private tasta tasta880;
        private tasta tasta881;
        private tasta tasta882;
        private tasta tasta883;
        private tasta tasta884;
        private tasta tasta885;
        private tasta tasta886;
        private tasta tasta887;
        private tasta tasta888;
        private tasta tasta889;
        private tasta tasta890;
        private tasta tasta891;
        private tasta tasta892;
        private tasta tasta893;
        private tasta tasta894;
        private tasta tasta895;
        private tasta tasta896;
        private tasta tasta897;
        private tasta tasta898;
        private tasta tasta899;
        private tasta tasta900;
        private tasta tasta901;
        private tasta tasta902;
        private tasta tasta903;
        private tasta tasta904;
        private tasta tasta905;
        private tasta tasta906;
        private tasta tasta907;
        private tasta tasta908;
        private tasta tasta909;
        private tasta tasta910;
        private tasta tasta911;
        private tasta tasta912;
        private tasta tasta913;
        private tasta tasta914;
        private tasta tasta915;
        private tasta tasta916;
        private tasta tasta917;
        private tasta tasta918;
        private tasta tasta919;
        private tasta tasta920;
        private tasta tasta921;
        private tasta tasta922;
        private tasta tasta923;
        private tasta tasta924;
        private tasta tasta925;
        private tasta tasta926;
        private tasta tasta927;
        private tasta tasta928;
        private tasta tasta929;
        private tasta tasta930;
        private tasta tasta931;
        private tasta tasta932;
        private tasta tasta933;
        private tasta tasta934;
        private tasta tasta935;
        private tasta tasta936;
        private tasta tasta937;
        private tasta tasta938;
        private tasta tasta939;
        private tasta tasta940;
        private tasta tasta941;
        private tasta tasta942;
        private tasta tasta943;
        private tasta tasta944;
        private tasta tasta945;
        private tasta tasta946;
        private tasta tasta947;
        private tasta tasta948;
        private tasta tasta949;
        private tasta tasta950;
        private tasta tasta951;
        private tasta tasta952;
        private tasta tasta953;
        private tasta tasta954;
        private tasta tasta955;
        private tasta tasta956;
        private tasta tasta957;
        private tasta tasta958;
        private tasta tasta959;
        private tasta tasta960;
        private tasta tasta961;
        private tasta tasta962;
        private tasta tasta963;
        private tasta tasta964;
        private tasta tasta965;
        private tasta tasta966;
        private tasta tasta967;
        private tasta tasta968;
        private tasta tasta969;
        private tasta tasta970;
        private tasta tasta971;
        private tasta tasta972;
        private tasta tasta973;
        private tasta tasta974;
        private tasta tasta975;
        private tasta tasta976;
        private tasta tasta977;
        private tasta tasta978;
        private tasta tasta979;
        private tasta tasta980;
        private tasta tasta981;
        private tasta tasta982;
        private tasta tasta983;
        private tasta tasta984;
        private tasta tasta985;
        private tasta tasta986;
        private tasta tasta987;
        private tasta tasta988;
        private tasta tasta989;
        private tasta tasta990;
        private tasta tasta991;
        private tasta tasta992;
        private tasta tasta993;
        private tasta tasta994;
        private tasta tasta995;
        private tasta tasta996;
        private tasta tasta997;
        private tasta tasta998;
        private tasta tasta999;
        private tasta tasta1000;
        private tasta tasta1001;
        private tasta tasta1002;
        private tasta tasta1003;
        private tasta tasta1004;
        private tasta tasta1005;
        private tasta tasta1006;
        private tasta tasta1007;
        private tasta tasta1008;
        private tasta tasta1009;
        private tasta tasta1010;
        private tasta tasta1011;
        private tasta tasta1012;
        private tasta tasta1013;
        private tasta tasta1014;
        private tasta tasta1015;
        private tasta tasta1016;
        private tasta tasta1017;
        private tasta tasta1018;
        private tasta tasta1019;
        private tasta tasta1020;
        private tasta tasta1021;
        private tasta tasta1022;
        private tasta tasta1023;
        private tasta tasta1024;
        private tasta tasta1025;
        private tasta tasta1026;
        private tasta tasta1027;
        private tasta tasta1028;
        private tasta tasta1029;
        private tasta tasta1030;
        private tasta tasta1031;
        private tasta tasta1032;
        private tasta tasta1033;
        private tasta tasta1034;
        private tasta tasta1035;
        private tasta tasta1036;
        private tasta tasta1037;
        private tasta tasta1038;
        private tasta tasta1039;
        private tasta tasta1040;
        private tasta tasta1041;
        private tasta tasta1042;
        private tasta tasta1043;
        private tasta tasta1044;
        private tasta tasta1045;
        private tasta tasta1046;
        private tasta tasta1047;
        private tasta tasta1048;
        private tasta tasta1049;
        private tasta tasta1050;
        private tasta tasta1051;
        private tasta tasta1052;
        private tasta tasta1053;
        private tasta tasta1054;
        private tasta tasta1055;
        private tasta tasta1056;
        private tasta tasta1057;
        private tasta tasta1058;
        private tasta tasta1059;
        private tasta tasta1060;
        private tasta tasta1061;
        private tasta tasta1062;
        private tasta tasta1063;
        private tasta tasta1064;
        private tasta tasta1065;
        private tasta tasta1066;
        private tasta tasta1067;
        private tasta tasta1068;
        private tasta tasta1069;
        private tasta tasta1070;
        private tasta tasta1071;
        private tasta tasta1072;
        private tasta tasta1073;
        private tasta tasta1074;
        private tasta tasta1075;
        private tasta tasta1076;
        private tasta tasta1077;
        private tasta tasta1078;
        private tasta tasta1079;
        private tasta tasta1080;
        private tasta tasta1081;
        private tasta tasta1082;
        private tasta tasta1083;
        private tasta tasta1084;
        private tasta tasta1085;
        private tasta tasta1086;
        private tasta tasta1087;
        private tasta tasta1088;
        private tasta tasta1089;
        private tasta tasta1090;
        private tasta tasta1091;
        private tasta tasta1092;
        private tasta tasta1093;
        private tasta tasta1094;
        private tasta tasta1095;
        private tasta tasta1096;
        private tasta tasta1097;
        private tasta tasta1098;
        private tasta tasta1099;
        private tasta tasta1100;
        private tasta tasta1101;
        private tasta tasta1102;
        private tasta tasta1103;
        private tasta tasta1104;
        private tasta tasta1105;
        private tasta tasta1106;
        private tasta tasta1107;
        private tasta tasta1108;
        private tasta tasta1109;
        private tasta tasta1110;
        private tasta tasta1111;
        private tasta tasta1112;
        private tasta tasta1113;
        private tasta tasta1114;
        private tasta tasta1115;
        private tasta tasta1116;
        private tasta tasta1117;
        private tasta tasta1118;
        private tasta tasta1119;
        private tasta tasta1120;
        private tasta tasta1121;
        private tasta tasta1122;
        private tasta tasta1123;
        private tasta tasta1124;
        private tasta tasta1125;
        private tasta tasta1126;
        private tasta tasta1127;
        private tasta tasta1128;
        private tasta tasta1129;
        private tasta tasta1130;
        private tasta tasta1131;
        private tasta tasta1132;
        private tasta tasta1133;
        private tasta tasta1134;
        private tasta tasta1135;
        private tasta tasta1136;
        private tasta tasta1137;
        private tasta tasta1138;
        private tasta tasta1139;
        private tasta tasta1140;
        private tasta tasta1141;
        private tasta tasta1142;
        private tasta tasta1143;
        private tasta tasta1144;
        private tasta tasta1145;
        private tasta tasta1146;
        private tasta tasta1147;
        private tasta tasta1148;
        private tasta tasta1149;
        private tasta tasta1150;
        private tasta tasta1151;
        private tasta tasta1152;
        private tasta tasta1153;
        private tasta tasta1154;
        private tasta tasta1155;
        private tasta tasta1156;
        private tasta tasta1157;
        private tasta tasta1158;
        private tasta tasta1159;
        private tasta tasta1160;
        private tasta tasta1161;
        private tasta tasta1162;
        private tasta tasta1163;
        private tasta tasta1164;
        private tasta tasta1165;
        private tasta tasta1166;
        private tasta tasta1167;
        private tasta tasta1168;
        private tasta tasta1169;
        private tasta tasta1170;
        private tasta tasta1171;
        private tasta tasta1172;
        private tasta tasta1173;
        private tasta tasta1174;
        private tasta tasta1175;
        private tasta tasta1176;
        private tasta tasta1177;
        private tasta tasta1178;
        private tasta tasta1179;
        private tasta tasta1180;
        private tasta tasta1181;
        private tasta tasta1182;
        private tasta tasta1183;
        private tasta tasta1184;
        private tasta tasta1185;
        private tasta tasta1186;
        private tasta tasta1187;
        private tasta tasta1188;
        private tasta tasta1189;
        private tasta tasta1190;
        private tasta tasta1191;
        private tasta tasta1192;
        private tasta tasta1193;
        private tasta tasta1194;
        private tasta tasta1195;
        private tasta tasta1196;
        private tasta tasta1197;
        private tasta tasta1198;
        private tasta tasta1199;
        private tasta tasta1200;
        private tasta tasta1201;
        private tasta tasta1202;
        private tasta tasta1203;
        private tasta tasta1204;
        private tasta tasta1205;
        private tasta tasta1206;
        private tasta tasta1207;
        private tasta tasta1208;
        private tasta tasta1209;
        private tasta tasta1210;
        private tasta tasta1211;
        private tasta tasta1212;
        private tasta tasta1213;
        private tasta tasta1214;
        private tasta tasta1215;
        private tasta tasta1216;
        private tasta tasta1217;
        private tasta tasta1218;
        private tasta tasta1219;
        private tasta tasta1220;
        private tasta tasta1221;
        private tasta tasta1222;
        private tasta tasta1223;
        private tasta tasta1224;
        private tasta tasta1225;
        private tasta tasta1226;
        private tasta tasta1227;
        private tasta tasta1228;
        private tasta tasta1229;
        private tasta tasta1230;
        private tasta tasta1231;
        private tasta tasta1232;
        private tasta tasta1233;
        private tasta tasta1234;
        private tasta tasta1235;
        private tasta tasta1236;
        private tasta tasta1237;
        private tasta tasta1238;
        private tasta tasta1239;
        private tasta tasta1240;
        private tasta tasta1241;
        private tasta tasta1242;
        private tasta tasta1243;
        private tasta tasta1244;
        private tasta tasta1245;
        private tasta tasta1246;
        private tasta tasta1247;
        private tasta tasta1248;
        private tasta tasta1249;
        private tasta tasta1250;
        private tasta tasta1251;
        private tasta tasta1252;
        private tasta tasta1253;
        private tasta tasta1254;
        private tasta tasta1255;
        private tasta tasta1256;
        private tasta tasta1257;
        private tasta tasta1258;
        private tasta tasta1259;
        private tasta tasta1260;
        private tasta tasta1261;
        private tasta tasta1262;
        private tasta tasta1263;
        private tasta tasta1264;
        private tasta tasta1265;
        private tasta tasta1266;
        private tasta tasta1267;
        private tasta tasta1268;
        private tasta tasta1269;
        private tasta tasta1270;
        private tasta tasta1271;
        private tasta tasta1272;

    }
}

